Class name rule:
osm table type    : ways, nodes, relations,
statisticed type  : this field always exist in tags, 'type' => 'xxx'
other information : used to descripe this class.
like:
NodesNodeBarrier this class is used to statistic the 'nodes' table, tags type is 'node'
barrier is other information, this indicate it which is used to statistic some items about barrier