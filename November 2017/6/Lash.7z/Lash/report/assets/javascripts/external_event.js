/**
 * external event JS v1.0.0 (2013-03-05)
 * need jquery support
 * (c) 2013 Qianfei Ding
 *
 */

$(document).ready(function() {
    $("table.index_list").addClass("tablesorter");
    $("table.index_list").tablesorter({});
});
