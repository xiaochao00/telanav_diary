var feature_mapping = {
    "Routing": [
        "nodes:node_id",
        "relations:construction",
        "relations:dir_slope",
        "relations:traffic_signals",
        "relations:amenity",
        "relations:restriction",
        "ways:nav_link",
        "ways:tollcost_id",
        "ways:fc"
    ],
    "Guidance": [
        "relations:lane_connectivity",
        "relations:signpost",
        "relations:traffic_sign",
        "relations:natural",
        "ways:nav_link",
        "ways:spd_id:f",
        "ways:spd_id:t"
    ],
    "Display": [
        "relations:junction_view",
        "relations:multipolygon",
        "relations:aeroway",
        "relations:boundary",
        "relations:building",
        "relations:landuse",
        "relations:leisure",
        "relations:tourism",
        "ways:nav_link",
        "ways:fc"
    ],
    "NGX": [],
    "Search": [
        "nodes:address_point"
    ],
    "Addas": [
        "ways:tmcid"
    ]
};