# -*- coding: utf-8 -*-
"""
choose the need tablespace
"""
import optparse
import sys

from check_utils import find_required_db_size_in_local
from tablespace_util import find_tablespace_stat_info_dict
from util.common_utils import pretty_size

DB_DIFFERENT_RATE = 1.5
DB_INCREMENTAL_SIZE = 100 * 1024 * 1024 * 1024

RESPONSE_LINE_FORMAT = "tablespace:{tablespace}"


def get_tablespace_name_size_dict(host):
    """Get all the tablespace left size from host.
    return  {name1:left_size1,name2:left_size2}
    """
    tablespace_stat_info_dict = find_tablespace_stat_info_dict(host=host)
    if not tablespace_stat_info_dict:
        return None
    tablespace_name_left_size_dict = {}
    for name, tablespace_stat_info in tablespace_stat_info_dict.iteritems():
        tablespace_name_left_size_dict[name] = tablespace_stat_info.disk_left_size
    return tablespace_name_left_size_dict


def get_required_database_size(host, database, default_size):
    db_required_size = find_required_db_size_in_local(host=host, specified_database_name=database)
    if not db_required_size:
        sys.stderr.write("can not find this type database[%s] in %s. Will used default required size[%s]." % (
            database, host, pretty_size(default_size)))
        db_required_size = default_size
    return db_required_size


def get_selected_tablespace(tablespace_name_size_dict, required_database_size):
    if not required_database_size:
        return None
    if not tablespace_name_size_dict:
        return None

    sys.stderr.write("Tablespace name size dict is : %s .\n" % [(name, pretty_size(size)) for name, size in
                                                                tablespace_name_size_dict.items()])
    tablespaces_tuple_by_order = sorted(tablespace_name_size_dict.items(), key=lambda d: d[1], reverse=True)
    tablespace_name, tablespace_size = tablespaces_tuple_by_order[0]

    min_required_size = min(required_database_size * DB_DIFFERENT_RATE, required_database_size + DB_INCREMENTAL_SIZE)
    sys.stdout.write("The required database size from history is %s; And the evaluative required size is %s.\n" % (
        pretty_size(required_database_size), pretty_size(min_required_size)))

    if tablespace_size >= min_required_size:
        return tablespace_name

    sys.stderr.write("Error: Left Space Size is not enough in all tablespace.")
    return None


def choose_tablespace(database, default_size):
    # 1. get all tablespace and size information
    tablespace_name_size_dict = get_tablespace_name_size_dict(host="localhost")
    # 2. get the history required size of this type database
    required_database_size = get_required_database_size(host="localhost", database=database, default_size=default_size)
    # 3. selected the tablespace
    selected_tablespace = get_selected_tablespace(tablespace_name_size_dict, required_database_size)
    return selected_tablespace


def check_options(options):
    if not options.default_size or not options.database_name:
        return False
    return True


def main():
    parser = optparse.OptionParser()
    parser.add_option("-N", "--database-name", help="database name", dest="database_name")
    parser.add_option("-S", "--size", help="default required size", dest="default_size", type=int)

    options, args = parser.parse_args()
    if not check_options(options):
        parser.print_help()
        sys.exit(-1)

    tablespace_name = choose_tablespace(database=options.database_name,
                                        default_size=options.default_size * 1024 * 1024 * 1024)
    if not tablespace_name:
        sys.stderr.write("Error: Failed in get the need tablespace.\n")
        sys.exit(-1)

    sys.stdout.flush()
    sys.stdout.write(RESPONSE_LINE_FORMAT.format(tablespace=tablespace_name) + "\n")
    sys.stdout.flush()


if __name__ == '__main__':
    main()
