# -*- coding: utf-8 -*-
"""
space statistic data and importer
"""
import optparse
import os
import sys

from elasticsearch_importer import ElasticSearchImporter
from space_statistic_data import builds_statistic, pbf_list_statistic, vendor_data_statistic

stat_data_index_name = "data_stat_index"
stat_data_doc_type = "data_stat_type"


def generate_dist_data_name(data):
    return "_".join([data["category"], data["name"], data["region"], data["version"], data["vendor"]])


def do_importer(host, user, password, port, index_name, doc_type, data_list):
    """Import data"""
    es_importer = ElasticSearchImporter(host=host, password=password, port=port, username=user)
    old_id_data_list = es_importer.search_data(index_name=index_name, doc_type=doc_type)

    new_builds_data_name_data_dic = dict([(generate_dist_data_name(data), data) for data in data_list])
    new_category_set = set([data["category"] for data in data_list])

    old_builds_data_name_list = []
    update_data_id_data_dict = {}

    for id_index, old_data in old_id_data_list:
        if not id_index or not old_data:
            continue
        data_name = generate_dist_data_name(old_data)
        old_builds_data_name_list.append(data_name)
        if data_name in new_builds_data_name_data_dic:
            # 1.if exist path, update data
            new_data = new_builds_data_name_data_dic[data_name]
            update_data_id_data_dict[id_index] = new_data
        elif old_data["category"] in new_category_set:
            # 2.if not exist, and is this category. Add remove field
            old_data["is_remove"] = True
            update_data_id_data_dict[id_index] = old_data
    # 3.if new path, insert
    insert_data_list = [data for data in data_list if generate_dist_data_name(data) not in old_builds_data_name_list]
    # 4. update and insert
    es_importer.update_data_list(index_name=index_name, doc_type=doc_type, id_data_dict=update_data_id_data_dict)
    es_importer.insert_data_list(index_name=index_name, doc_type=doc_type, data_list=insert_data_list)


def do_data_statistic_import(options):
    data_list = []
    if options.raw_data_path:
        data_list.extend(vendor_data_statistic(options.raw_data_path))
    if options.build_data_path:
        data_list.extend(builds_statistic(options.build_data_path))
    if options.pbf_data_paths:
        data_list.extend(pbf_list_statistic(options.pbf_data_paths))
    # importer
    do_importer(host=options.es_host, index_name=stat_data_index_name, doc_type=stat_data_doc_type,
                data_list=data_list, user=options.es_username, password=options.es_password, port=options.es_port)


def check_parameters(options):
    # check elasticsearch
    if not options.es_host:
        sys.stderr.write("host for ElasticSearch should not none./n")
        return False
    # check raw data path availability if have this path
    if options.raw_data_path and not os.path.exists(options.raw_data_path):
        sys.stderr.write("raw data path[%s] does not exist.\n" % options.raw_data_path)
        return False
    # check build path availability if have this path
    if options.build_data_path and not os.path.exists(options.build_data_path):
        sys.stderr.write("build data path[%s] does not exist.\n" % options.build_data_path)
        return False

    # check pbf path list availability if have this paths
    if options.pbf_data_paths:
        for pbf_path in [pbf_path.strip() for pbf_path in options.pbf_data_paths.split("|")]:
            if os.path.exists(pbf_path):
                continue
            sys.stderr.write("pbf data path[%s] does not exist.\n" % pbf_path)
            return False
    return True


def main():
    parse = optparse.OptionParser()

    parse.add_option("-R", "--raw-data-path", help="raw data path", dest="raw_data_path")
    parse.add_option("-P", "--pbf-data-paths", help="pbf data paths", dest="pbf_data_paths")
    parse.add_option("-B", "--build-data-path", help="builds data path", dest="build_data_path")

    parse.add_option("-e", "--elasticsearch-hostname", help="elasticsearch hostname", dest="es_host")
    parse.add_option("-u", "--username", help="username for ElasticSearch", dest="es_username")
    parse.add_option("-p", "--password", help="password for ElasticSearch", dest="es_password")
    parse.add_option("-n", "--port-number", help="port for Elasticsearch", dest="es_port", default=9200)

    options, args = parse.parse_args()

    if not check_parameters(options):
        sys.stderr.write("%s\n" % parse.print_help())
        sys.exit(-1)

    do_data_statistic_import(options)


if __name__ == '__main__':
    main()
