# encoding=utf8
import json
import os
import sys
from collections import namedtuple

from data_type_statistic.data_types import RawData, BuildData
from util.common_utils import dic_list2json, get_vendor_name, parse_build_type_name
from util.common_utils import filter_raw_raw_data_name, pretty_size, parse_pbf_data_data_name, filter_pbf_data_data_name
from util.common_utils import print_error, parse_vendor_raw_data_name

Disk_Usage = namedtuple("usage", "total used free percent")
ROOT_PATH = os.path.dirname(os.path.abspath(__file__))
OUTPUT_STATISTIC_DIR = os.path.join(ROOT_PATH, "output_statistic")
"""
output directory structure                
    output_statistic/
        └── statistic_type(global_cn,global_other,kor,autonavi)/
            ├── data
            │   ├── pbf_data
            │   │   └── pbf_statistic.json
            │   └── raw_data
            │       └── raw_data_statistic.json
            └── db
                ├── host name.json(temp)
                ├── raw_db
                │   └── raw_db_statistic.json
                └── unidb_db
                    └── unidb_db_statistic.json             
"""

OUTPUT_STATISTIC_DATA_DIR = "data"
OUTPUT_STATISTIC_RAW_DATA_DIR = os.path.join(OUTPUT_STATISTIC_DATA_DIR, "raw_data")
OUTPUT_STATISTIC_PBF_DATA_DIR = os.path.join(OUTPUT_STATISTIC_DATA_DIR, "pbf_data")

RAW_DATA_STATISTIC_FILE_NAME_PREFIX = "raw_data_statistic"
RAW_DATA_STATISTIC_FILE_NAME = RAW_DATA_STATISTIC_FILE_NAME_PREFIX + ".json"

BUILD_DATA_STATISTIC_FILE_NAME = "builds_statistic.json"
PBF_DATA_STATISTIC_FILE_NAME_PREFIX = "pbf_statistic"
PBF_DATA_STATISTIC_FILE_NAME = PBF_DATA_STATISTIC_FILE_NAME_PREFIX + ".json"


class DiskSpaceUtil(object):
    @staticmethod
    def get_dir_list_size(dir_path_list):
        import multiprocessing
        pool = multiprocessing.Pool(processes=8)
        result_list = []
        for dir_path in dir_path_list:
            result_list.append(pool.apply_async(dir_size_proxy, (DiskSpaceUtil, dir_path)))
        pool.close()
        pool.join()

        size_list = [result.get() for result in result_list]
        return size_list

    @staticmethod
    def get_dir_size(dir_path):
        """unit byte"""
        size = 0l
        if isinstance(dir_path, unicode):
            dir_path = dir_path.encode("utf8")
        for root, dirs, file_names in os.walk(dir_path):
            size += sum([os.path.getsize(os.path.join(root, file_name)) for file_name in file_names])
        return size

    @staticmethod
    def get_dir_usage(dir_path):
        """The usage of this dir_path`s mount path
        Return disk usage associated with path."""
        st = os.statvfs(dir_path)
        free = (st.f_bavail * st.f_frsize)
        total = (st.f_blocks * st.f_frsize)
        used = (st.f_blocks - st.f_bfree) * st.f_frsize
        try:
            percent = ret = (float(used) / total) * 100
        except ZeroDivisionError:
            percent = 0

        return Disk_Usage(total, used, free, round(percent, 1))


# match the config components file, field name
ConfigComponents = namedtuple("component", "name path regions")
components_conf_file_path = os.path.join(ROOT_PATH, "vendor_data_components.json")


class StatData(object):
    def __init__(self, name, path):
        self.name = name
        self.path = path

        self.size = 0l
        self._init_check()

    def _init_check(self):
        if not os.path.exists(self.path):
            sys.stderr.write("Data path<%s> is not exist.\n" % self.path)
            sys.exit(-1)

    def statistic(self):
        self.size = DiskSpaceUtil.get_dir_size(self.path)
        print self.name, self.size, pretty_size(self.size)


class StatDataList(object):
    def __init__(self, name, data_path):
        self.name = name
        self.data_path = data_path

        self.size = 0
        self.data_list = []
        self.vendor_pretty_size = ""

        self._init_check()

        vendor, self.region, self.version = parse_vendor_raw_data_name(self.name)
        self.vendor = get_vendor_name(vendor)

    def _init_check(self):
        if not os.path.exists(self.data_path):
            print_error("Data path<%s> is not exist.\n" % self.data_path)
            sys.exit(-1)

    def statistic_data_list(self):
        data_size_list = DiskSpaceUtil.get_dir_list_size([data.path for data in self.data_list])
        self.size = sum(data_size_list)
        self.vendor_pretty_size = pretty_size(self.size)
        for data, data_size in zip(self.data_list, data_size_list):
            data.size = data_size
            print self.name, data.name, pretty_size(data_size)


class VendorStat(StatDataList):
    conf_component_list = []

    @staticmethod
    def get_vendor_data_list(base_dir):
        """traverse this base path, list all vendor data directory. And filter"""
        vendor_list = []
        all_data_name = os.listdir(base_dir)
        selected_data_name = filter(filter_raw_raw_data_name, all_data_name)
        for data_name in selected_data_name:
            data_path = os.path.join(base_dir, data_name)
            if not os.path.isdir(data_path):
                continue
            vendor_list.append(VendorStat(data_name, data_path))

        vendor_list.sort(key=lambda d: d.name)
        return vendor_list

    @staticmethod
    def load_components_conf():
        """There are specified components for one region. Base on conf file."""
        if VendorStat.conf_component_list:
            return VendorStat.conf_component_list

        with open(components_conf_file_path, "r") as f:
            component_json_list = json.load(f)
            conf_component_list = [ConfigComponents(c["name"], c["path"], c["regions"].split("|"))
                                   for c in component_json_list]
            if not conf_component_list:
                print_error("components from config should not empty")
                sys.exit(-1)

            return conf_component_list

    def __init__(self, name, data_path):
        StatDataList.__init__(self, name=name, data_path=data_path)
        self._init_component_list()

    def _init_component_list(self):
        VendorStat.conf_component_list = VendorStat.load_components_conf()
        component_list = []
        # load and check component
        for conf_component in self.conf_component_list:
            if self.region not in conf_component.regions:
                continue
            component_path = os.path.join(self.data_path, conf_component.path)
            if not os.path.exists(component_path):
                continue
            component_list.append(StatData(name=conf_component.name, path=component_path))
        self.data_list = component_list

    def get_data_dic_list(self):
        raw_data_dic_list = []
        for component in self.data_list:
            raw_data = RawData(name=component.name, region=self.region, vendor=self.vendor,
                               version=self.version, size=component.size, size_pretty=pretty_size(component.size),
                               data_path=component.path)
            raw_data_dic_list.append(raw_data.__dict__)
        return raw_data_dic_list


def dir_size_proxy(cls_instance, i):
    return cls_instance.get_dir_size(i)


class BuildsStat(StatDataList):
    @staticmethod
    def get_build_list(base_dir):
        if not os.path.exists(base_dir):
            sys.stderr.write("PBF base dir is not exist.[%s]\n" % base_dir)
            sys.exit(-1)

        all_pbf_name = os.listdir(base_dir)
        selected_pbf_name = filter(filter_raw_raw_data_name, all_pbf_name)

        build_list = []
        for pbf_name in selected_pbf_name:
            pbf_path = os.path.join(base_dir, pbf_name)
            if not os.path.isdir(pbf_path):
                sys.stderr.write("data [%s] is not a directory. cannot statistic\n" % pbf_path)
                continue

            build_type_name = os.path.basename(base_dir)
            build_list.append(BuildsStat(pbf_name, pbf_path, build_type_name))

            build_list.sort(key=lambda d: d.name)
        return build_list

    def __init__(self, name, data_path, build_type_name):
        StatDataList.__init__(self, name=name, data_path=data_path)
        self.build_type = build_type_name
        self._init_data_list()

    def _init_data_list(self):
        """get all build data list"""
        data_list = []
        data_name_list = os.listdir(self.data_path)
        # TODO filter pbf data version name If need
        data_name_list = filter(filter_pbf_data_data_name, data_name_list)
        # Initialization pbf data list
        for data_name in data_name_list:
            data_path = os.path.join(self.data_path, data_name)
            if not os.path.isdir(data_path):
                sys.stderr.write("path<%s> is not a directory.\n" % data_path)
                continue
            data_list.append(StatData(name=data_name, path=data_path))

        self.data_list = data_list

    def get_build_data_dic_list(self):
        data_dic_list = []
        build_project, build_data_type = parse_build_type_name(build_type_name=self.build_type)
        for stat_data in self.data_list:
            data_name = stat_data.name
            create_time, release_type = parse_pbf_data_data_name(data_name)
            build_data = BuildData(name=data_name, region=self.region, vendor=self.vendor, version=self.version,
                                   size=stat_data.size, size_pretty=pretty_size(stat_data.size),
                                   project=build_project, build_type=self.build_type,
                                   data_type=build_data_type, data_path=stat_data.path,
                                   create_time=create_time, release_type=release_type)
            data_dic_list.append(build_data.__dict__)
        return data_dic_list


def vendor_data_statistic(base_path):
    vendor_data_list = VendorStat.get_vendor_data_list(base_dir=base_path)
    vendor_data_dic_list = []
    for vendor_data in vendor_data_list:
        vendor_data.statistic_data_list()
        vendor_data_dic_list.extend(vendor_data.get_data_dic_list())
    return vendor_data_dic_list


def pbf_statistic(base_path):
    pbf_list = BuildsStat.get_build_list(base_dir=base_path)
    pbf_dic_list = []
    for pbf in pbf_list:
        pbf.statistic_data_list()
        pbf_dic_list.extend(pbf.get_build_data_dic_list())
    return pbf_dic_list


def pbf_list_statistic(base_path_list):
    data_dic_list = []
    for base_path in base_path_list:
        pbf_list = BuildsStat.get_build_list(base_dir=base_path)
        for pbf in pbf_list:
            pbf.statistic_data_list()
            data_dic_list.extend(pbf.get_build_data_dic_list())
    return data_dic_list


def builds_statistic(build_base_path):
    build_path_list = os.listdir(build_base_path)
    build_path_list = [os.path.join(build_base_path, path) for path in build_path_list]
    build_path_list = filter(lambda build_path: os.path.isdir(build_path), build_path_list)
    data_list = pbf_list_statistic(build_path_list)
    return data_list


def do_raw_data_statistic(base_path, out_dir):
    result_file = os.path.join(out_dir, OUTPUT_STATISTIC_RAW_DATA_DIR, RAW_DATA_STATISTIC_FILE_NAME)
    data_list = vendor_data_statistic(base_path)
    dic_list2json(dic_list=data_list, dump_json_file_path=result_file)


def do_pbf_statistic(base_path, out_dir):
    result_file_path = os.path.join(out_dir, OUTPUT_STATISTIC_PBF_DATA_DIR, PBF_DATA_STATISTIC_FILE_NAME)
    data_list = pbf_statistic(base_path=base_path)
    dic_list2json(dic_list=data_list, dump_json_file_path=result_file_path)


def do_pbf_list_statistic(base_path_list, out_dir):
    """There are more pbf base directory, such DENALI_PBG, GEN3_PBF"""
    data_dic_list = pbf_list_statistic(base_path_list)
    result_file_path = os.path.join(out_dir, OUTPUT_STATISTIC_PBF_DATA_DIR, PBF_DATA_STATISTIC_FILE_NAME)
    dic_list2json(dic_list=data_dic_list, dump_json_file_path=result_file_path)


def do_ec_builds_statistic(build_base_path, out_dir):
    data_list = builds_statistic(build_base_path)
    result_file_path = os.path.join(out_dir, OUTPUT_STATISTIC_PBF_DATA_DIR, BUILD_DATA_STATISTIC_FILE_NAME)
    dic_list2json(dic_list=data_list, dump_json_file_path=result_file_path)
