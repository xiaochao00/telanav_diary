# -*- coding: utf-8 -*-
"""
create the database in local, and choose the max tablespace
"""
import sys

from tablespace_selector import choose_tablespace
from tablespace_util import create_database


def do_create(database, default_size):
    selected_database = choose_tablespace(database, default_size)
    if create_database(host="localhost", database=database, tablespace_name=selected_database):
        sys.stdout.write("create database[%s] in tablespace[%s] success.\n" % (database, selected_database))
        return True
    sys.stderr.write("database[%s] create in selected tablespace[%s] failed;" % (database, selected_database))
    return False


def main():
    import optparse
    parser = optparse.OptionParser()
    parser.add_option("-N", "--database-name", help="database name", dest="database_name")
    parser.add_option("-S", "--size", help="default required size", dest="default_size", type=int)
    options, args = parser.parse_args()
    #
    if not options.database_name or not options.default_size:
        parser.print_help()
        sys.exit(-1)
    #
    if not do_create(database=options.database_name, default_size=options.default_size):
        sys.exit(-1)
