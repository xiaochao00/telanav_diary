# -*- coding: utf-8 -*-
import optparse
import sys

from check_utils import get_min_required_size, find_required_db_size_in_local
from tablespace_util import find_tablespace_stat_info_dict
from util.common_utils import print_standout, print_error, pretty_size

DEFAULT_SIZE = 200 * 1024 * 1024 * 1024

SPECIFIED_TABLESPACE_NAMES_DICT = {"default": "pg_default"}


def check_tablespace(host, specified_database_name, tablespace_name, default_required_size=0l):
    """Tablespace checker

    is or not enough for use
    :param host:
    :param specified_database_name:
    :param tablespace_name:
    :param default_required_size:
    :return: True or False
    """
    # 1. Get the required size by this type name, from this machine or config directory
    required_size = find_required_db_size_in_local(host=host, specified_database_name=specified_database_name)
    # if none give the default size
    if not required_size:
        required_size = default_required_size

    if not required_size:
        print_error("Error: Do not have this type database name[%s] in [%s]." % (specified_database_name, host))
        print_error("Error: Please input a required size if You want to check.")
        return False

    # 2. get tablespace information
    tablespace_name_stat_info_dict = find_tablespace_stat_info_dict(host)
    tablespace_name = SPECIFIED_TABLESPACE_NAMES_DICT.get(tablespace_name, tablespace_name)
    # special handling for special tablespace name
    if tablespace_name not in tablespace_name_stat_info_dict:
        print_error("Error: can not find tablespace[%s] in host[%s]" % (tablespace_name, host))
        print_error("Info: all the tablespaces in host[%s] are %s" % (host, tablespace_name_stat_info_dict.keys()))
        return False
    # 3. do compare
    # remain_size must big than size of previous db
    # and more than one time. such give the min rate 1.5
    remain_size = tablespace_name_stat_info_dict[tablespace_name].disk_left_size
    min_required_size = get_min_required_size(required_size)
    print_standout(
        "The required size from history is %s; The min evaluative required size is %s; And the the remain size is %s." %
        (pretty_size(required_size), pretty_size(min_required_size), pretty_size(remain_size)))
    if remain_size > min_required_size:
        return True
    else:
        print_error("The remain size of [%s] is [%s] not enough." % (tablespace_name, pretty_size(remain_size)))
        print_error("Tablespaces space info:%s." % [(name, pretty_size(size)) for name, size in
                                                    tablespace_name_stat_info_dict.iteritems()])
        return False


def main():
    parser = optparse.OptionParser()
    parser.add_option("-H", "--check-host", help="check host", dest="check_host")
    parser.add_option("-D", "--database", help="like NT_CN_17Q3,Unidb_NT_CN_17Q3,HERE_KOR17Q3", dest="database")
    parser.add_option("-T", "--tablespace", help="tablespace name", dest="tablespace")
    parser.add_option("-S", "--default-size", help="required default database size(unit is GB)", dest="default_size",
                      type=int)

    input_options, input_args = parser.parse_args()
    # default check
    if not input_options.check_host or not input_options.database or not input_options.tablespace:
        print_error("input check host or tablespace or database should not be none")
        print_standout(parser.print_help())
        return False
    #
    if input_options.default_size:
        input_options.default_size *= 1024 * 1024 * 1024
    return check_tablespace(host=input_options.check_host, specified_database_name=input_options.database,
                            tablespace_name=input_options.tablespace, default_required_size=input_options.default_size)


if __name__ == '__main__':
    if not main():
        sys.exit(-1)
    pass
    # print check_tablespace("hqd-ssdpostgis-05.mypna.com", "HERE_EU16Q4", "ssd2")
    # print check_tablespace("hqd-ssdpostgis-05.mypna.com", "HERE_EU17Q3", "ssd2")
    # print check_tablespace("172.16.101.92","")
    # print check_tablespace("hqd-ssdpostgis-04.mypna.com", "HERE_SEA17Q3", "ssd2")
    # print check_tablespace("shd-dpc6x64ssd-02.china.telenav.com", "NT_CN_17Q2", "pg_default")
    # print check_tablespace("shd-dpc6x64ssd-02.china.telenav.com", "NT_CN_17Q2_Level0", "pg_default")
