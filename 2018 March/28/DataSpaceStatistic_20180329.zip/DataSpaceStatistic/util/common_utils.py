import json
import os
import re
import socket
import sys

LEVEL0_FLAG = "LEVEL0"
LEVEL0_SUFFIX = "Level0"

DB_NAME_PREFIX_HERE = "HERE"
DB_NAME_PREFIX_CN = "NT"
DB_NAME_PREFIX_UNIDB = "UNIDB"
DB_NAME_PREFIX_AXF = "CN_AXF"
DB_NAME_PREFIX_AUTONAVI = "CN_AUTONAVI"


def is_localhost(host):
    """
    :param host:
        hostname judgement
    :return:
        is or not local hostname
    """
    if not host or not host.strip():
        return None

    ip_list = socket.gethostbyname_ex(socket.gethostname())
    # ("hqd-ssdpostgis-04.mypna.com", ["hqd-ssdpostgis-04"], ["10.224.76.206"])
    localhost_names = [ip_list[0]]
    localhost_aliases_names = ["localhost"] + ip_list[1]
    localhost_addresses = ["127.0.0.1"] + ip_list[2]

    localhost_list = localhost_names + localhost_aliases_names + localhost_addresses

    if host.strip() in localhost_list:
        print_standout(" address %s is localhost " % host)
        return True

    print_error("%s is not local address" % host)
    return False


def print_standout(info):
    """
    print information to standout
    :param info:
    :return:
    """
    sys.stdout.write("Info: %s" % info)
    sys.stdout.write("\n")
    sys.stdout.flush()


def json_print(info):
    data_str = json.dumps(info)
    print data_str
    return data_str


def print_error(err):
    """
    :param err: information of error
    :return:
    """
    sys.stderr.write("Error: %s" % err)
    sys.stderr.write("\n")
    sys.stderr.flush()


def region_version(database_name):
    """Parse database name, return region and version"""
    vendor, region, version = parse_rdf_unidb_db_name(database_name)
    if database_name.find("TUR") != -1:
        region = "TUR"
    return region, version


def parse_rdf_unidb_db_name(rdf_database_name):
    """Parse rdf and unidb database BD anme
    HERE_MEA17Q3 : HERE,MEA,17Q3,False
    NT_CN_17Q3
    Unidb_NT_CN_
    Unidb_HERE_MEA17
    :param rdf_database_name:
    :return:db_type,region,version,is_level0
    """
    p = r"([A-Z0-9_]+_)([A-Z]+)_?(\d+Q\d)(.*)"
    m = re.match(p, rdf_database_name, re.IGNORECASE)
    if not m:
        return None, None, None
    db_vendor = m.group(1).strip("_")
    db_region = m.group(2)
    db_version = m.group(3)
    db_is_level0 = (m.group(4).upper().strip("_").startswith(LEVEL0_FLAG))
    # specified process
    db_vendor, db_region, db_version = data_name_specified_process(data_name=rdf_database_name, db_vendor=db_vendor,
                                                                   db_region=db_region,
                                                                   db_version=db_version,
                                                                   is_level0=db_is_level0)
    return db_vendor, db_region, db_version


def parse_vendor_raw_data_name(data_name):
    """Parse raw data name
    region_vendor_17Q2, CN_NT_17Q1_Level0"""
    p = r"([A-Z]+)_([A-Z0-9_]+_)_?(\d+Q\d)(.*)"
    m = re.match(p, data_name, re.IGNORECASE)
    if not m:
        return None, None, None
    db_region = m.group(1)
    db_vendor = m.group(2).strip("_")
    db_version = m.group(3)
    db_is_level0 = (m.group(4).upper().strip("_").startswith(LEVEL0_FLAG))

    db_vendor, db_region, db_version = data_name_specified_process(data_name=data_name, db_vendor=db_vendor,
                                                                   db_region=db_region,
                                                                   db_version=db_version,
                                                                   is_level0=db_is_level0)
    return db_vendor, db_region, db_version


def data_name_specified_process(data_name, db_vendor, db_region, db_version, is_level0):
    """Database name parse specified case
    1.When name contain TUR, this region named TUR
    2.When AXF in region name, exchange region with vendor
    3.When region name start with Unidb, remove these string
    """
    if is_level0:
        db_region += "_" + LEVEL0_SUFFIX
    if data_name.find("TUR") != -1:
        db_region = "TUR"
    if "AXF" == db_region.upper():
        db_vendor, db_region = db_region, db_vendor
    if db_region.upper().startswith(DB_NAME_PREFIX_UNIDB):
        db_region = re.compile(re.escape(DB_NAME_PREFIX_UNIDB), re.IGNORECASE).sub("", db_region).strip("_")

    if db_vendor.upper().startswith(DB_NAME_PREFIX_UNIDB):
        db_vendor = re.compile(re.escape(DB_NAME_PREFIX_UNIDB), re.IGNORECASE).sub("", db_vendor).strip("_")

    return db_vendor, db_region, db_version


def parse_pbf_data_data_name(data_name):
    """data name like : GENERAL_PBF-CN_AXF_17Q2-AdaptorG2_UniDB_1.0.0.113978-20170823162512-RC/
    return time=20170823162512,type=RC
    """
    p = r".*(\d{4}\d{2}\d{2}\d{2}\d{2}\d{2})[_-].*(RC|DEV|TEST).*"
    m = re.match(p, data_name, re.IGNORECASE)
    if m:
        return m.group(1), m.group(2)
    # "unidb_cn_axf_16q4_1.0.0.113978_170927_123318_mainland-rc
    p = r".*(\d{2}\d{2}\d{2})[_-].*(RC|DEV|TEST).*"
    m = re.match(p, data_name, re.IGNORECASE)
    if m:
        return m.group(1), m.group(2)

    return None, None


def pretty_size(size_b):
    """Return the given bytes as a human friendly KB, MB, GB, or TB string
    :param size_b:
    :return:
    """
    B = float(size_b)
    KB = float(1024)
    MB = float(KB ** 2)  # 1,048,576
    GB = float(KB ** 3)  # 1,073,741,824
    TB = float(KB ** 4)  # 1,099,511,627,776

    if B < KB:
        return "{0} {1}".format(B, "Bytes" if 0 == B > 1 else "Byte")
    elif KB <= B < MB:
        return "{0:.2f} KB".format(B / KB)
    elif MB <= B < GB:
        return "{0:.2f} MB".format(B / MB)
    elif GB <= B < TB:
        return "{0:.2f} GB".format(B / GB)
    elif TB <= B:
        return "{0:.2f} TB".format(B / TB)


def filter_database_name(database_name):
    if database_name.upper().find("TEST") != -1 or database_name.upper().find("WORLDMAP") != -1:
        return False
    if is_rdf_db_name(database_name) or is_unidb_db_name(database_name):
        return True
    return False


def get_db_type(database_name):
    if is_rdf_db_name(database_name):
        return "RDF"
    if is_unidb_db_name(database_name):
        return "Unidb"
    return None


def get_unified_database_type(database_name):
    db_type = get_db_type(database_name=database_name)
    db_vendor, db_region, db_version = parse_rdf_unidb_db_name(database_name)
    if not db_vendor or not db_region or not db_version or not db_type:
        return None
    return "_".join([db_type, db_vendor, db_region])


def is_rdf_db_name(database_name):
    """Name start with NT, HERE, CN_AXF, CN_AUTONAVI"""
    if (database_name.upper().startswith(DB_NAME_PREFIX_CN) or
            database_name.upper().startswith(DB_NAME_PREFIX_HERE) or
            database_name.upper().startswith(DB_NAME_PREFIX_AXF) or
            database_name.upper().startswith(DB_NAME_PREFIX_AUTONAVI)):
        return True
    return False


def is_unidb_db_name(database_name):
    """Name start with Unidb """
    if database_name.upper().startswith(DB_NAME_PREFIX_UNIDB):
        return True
    return False


def filter_raw_raw_data_name(data_name):
    vendor, region, version = parse_vendor_raw_data_name(data_name)
    if not vendor or not region or not version:
        return False
    for filter_str in ["TEST", "BAK", "V0", "PAN", "ADAS", "OLD", "ARP", "LOGAN", "WORLDMAP", "REVA",
                       "SAMPLAE", "V2", "BEACONS", "GCC", "AF", "ISR"]:
        if filter_str in data_name.upper():
            return False

    return True


def filter_pbf_data_data_name(data_name):
    """Filter pbf data name
    1.remove when data time or data type is None;
    2.remove when contain ignored string
    """
    data_time, data_type = parse_pbf_data_data_name(data_name)
    if not data_time or not data_type:
        return False
    for filter_str in ["CI"]:
        if filter_str in data_name.upper():
            return False
    return True


def dic_list2json(dic_list, dump_json_file_path):
    """[{},] to json file"""
    base_path = os.path.dirname(dump_json_file_path)
    if not os.path.exists(base_path):
        print_standout("path[%s] not exist, create it." % base_path)
        os.makedirs(base_path)
    if os.path.exists(dump_json_file_path):
        print_standout("file[%s] exist, rewrite it." % dump_json_file_path)
        os.remove(dump_json_file_path)

    with open(dump_json_file_path, "w") as f:
        json.dump(dic_list, f, ensure_ascii=False, indent=4, separators=(",", ":"))
        print_standout("dump to file[%s] finished." % dump_json_file_path)


def load_json2list(json_file_path):
    if not os.path.exists(json_file_path):
        print_error("json file[%s] should exist" % json_file_path)
        sys.exit(-1)

    with open(json_file_path, "r") as f:
        data_list = json.load(f)
        return data_list


vendor_name_dic = {"AXF": "AUTONAVI", "NT": "NAV2", "HERE": "HERE", "AUTONAVI": "AUTONAVI"}


def get_vendor_name(vendor):
    return vendor_name_dic.get(vendor.upper())


def parse_build_type_name(build_type_name):
    """From build_type_name to project, data_type
    YANGZI_NGX return YANGZI,NZG"""
    p = "([A-Z0-9]*)_(.*)"
    m = re.match(p, build_type_name, re.IGNORECASE)
    if not m:
        return None, None
    return m.group(1), m.group(2)


if __name__ == "__main__":
    unidb_db_name = "UniDB_NT_CN_15Q3_1.0.0-gen3.421243-20160411222319-RC"
    rdf_db_name = "HERE"
    print parse_rdf_unidb_db_name("NT_CN_17Q2_Level0")
    print parse_rdf_unidb_db_name("UniDB_HERE_NA17Q4_1.0.0.524754-20171220000612-RC")
    print parse_rdf_unidb_db_name("unidb_cn_axf_16q4_1.0.0.113978_170927_123318_mainland-rc")

    print filter_database_name("UniDB_HERE_WORLDMAP17Q1_1.0.0.504326-20171013044235-RC-TURKEY")
    print parse_vendor_raw_data_name("CN_NT_17Q1")
    print parse_vendor_raw_data_name("CN_NT_17Q2_Level0")
    print parse_vendor_raw_data_name("EU_HERE_17Q1")
    print filter_raw_raw_data_name("CN_NT_14Q3_old")

    print parse_pbf_data_data_name("unidb_cn_axf_16q4_1.0.0.113978_170927_123318_mainland-rc")
    print parse_pbf_data_data_name("UniDB_HERE_EU17Q1_1.0.0.477938-20170215074604-RC")
    print parse_pbf_data_data_name("UniDB_HERE_WORLDMAP17Q1_1.0.0.504326-20171013044235-RC-TURKEY")
    print parse_pbf_data_data_name("unidb_cn_axf_17q4_1.0.0.525970_180115_092132-rc")

    print parse_pbf_data_data_name("UniDB_HERE_MEA17Q3_1.0.0.515772-20171013002550-RC")
    print parse_pbf_data_data_name("DENALI_PBF-ANZ_HERE_17Q4-AdaptorG2_UniDB_1.0.0.523239-20180305215328-TEST")
    print parse_rdf_unidb_db_name("UniDB_HERE_ANZ17Q4_1.0.0.524754-20180102184625-RC")
    print parse_rdf_unidb_db_name("unidb_anz_17q4_clipped")
