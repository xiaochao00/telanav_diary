import os
import logging

VDE_LOGGING_NAME = "check_logging"
LOG_FILE_PATH = os.path.join(os.path.dirname(__file__), "tablespace_check.log")

check_logging = None


def init_log(func):
    def _decorator(msg):
        if not check_logging:
            logging_initialize()
        return func(msg)

    return _decorator


def logging_initialize():
    global check_logging
    # 1. logging
    check_logging = logging.getLogger(VDE_LOGGING_NAME)
    check_logging.setLevel(logging.DEBUG)
    # 2.handler
    # file handler
    fh = logging.FileHandler(LOG_FILE_PATH, mode="w")
    fh.setLevel(logging.DEBUG)
    # standard control console
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    # 3.format
    formatter = logging.Formatter("[%(asctime)s %(name)s].%(levelname)s: %(message)s")
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)

    check_logging.addHandler(fh)
    check_logging.addHandler(ch)


@init_log
def logging_debug(debug_msg):
    check_logging.debug(debug_msg)


@init_log
def logging_info(info_msg):
    check_logging.info(info_msg)


@init_log
def logging_error(error_msg):
    check_logging.error(error_msg)


@init_log
def logging_warn(warn_msg):
    check_logging.warn(warn_msg)


if __name__ == '__main__':
    logging_initialize()
    logging_debug("debug")
    logging_info("info")
    print "print info"