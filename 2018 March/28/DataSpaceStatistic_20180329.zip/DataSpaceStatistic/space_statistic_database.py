import sys

from data_type_statistic.data_types import RdfDB, Unidb
from space_statistic_data_importer import do_importer, stat_data_doc_type, stat_data_index_name
from tablespace_util import DatabaseStatInfo, find_database_stat_info_list
from util.common_utils import pretty_size, parse_pbf_data_data_name


def transform_rdfdb_info_list2rdfdb_dict_list(rdfdb_info_list):
    """Transform rdfdb list[DatabaseStatInfo] to  list[RdfDB]"""
    # transform rdf db
    rdfdb_dic_list = [RdfDB(name=db_info.database_name, region=db_info.region, vendor=db_info.vendor,
                            version=db_info.version, size=db_info.size,
                            size_pretty=pretty_size(db_info.size)).__dict__
                      for db_info in rdfdb_info_list]
    return rdfdb_dic_list


def transform_unidb_info_list2unidb_list(unidb_db_info_list):
    """Transform unidb list[DatabaseStatInfo] to list[Unidb]"""
    unidb_dic_list = []
    for db_info in unidb_db_info_list:
        create_time, release_type = parse_pbf_data_data_name(db_info.database_name)
        unidb = Unidb(name=db_info.database_name, region=db_info.region, vendor=db_info.vendor, version=db_info.version,
                      size=db_info.size, size_pretty=pretty_size(db_info.size), create_time=create_time,
                      release_type=release_type)
        unidb_dic_list.append(unidb.__dict__)
    return unidb_dic_list


def database_statistic(host_name):
    db_info_list = find_database_stat_info_list(host_name)
    DatabaseStatInfo.sort_list(db_info_list)
    rdfdb_info_list, unidb_info_list = DatabaseStatInfo.split2rdf_pbf_db_list(db_info_list)
    rdfdb_dict_list = transform_rdfdb_info_list2rdfdb_dict_list(rdfdb_info_list=rdfdb_info_list)
    unidb_dict_list = transform_unidb_info_list2unidb_list(unidb_db_info_list=unidb_info_list)
    return rdfdb_dict_list, unidb_dict_list


def do_database_statistic_import(options):
    rdfdb_dict_list, unidb_dict_list = database_statistic(options.hostname)
    do_importer(host=options.es_host, port=options.es_port, user=options.es_username,
                password=options.es_password, data_list=(rdfdb_dict_list + unidb_dict_list),
                index_name=stat_data_index_name, doc_type=stat_data_doc_type)


def check_parameters(options):
    if not options.hostname:
        sys.stderr.write("Hostname of statistic should not None.\n")
        return False
    if not options.es_host:
        sys.stderr.write("Hostname of ElasticSearch should not None.\n")
        return False
    return True


def main():
    import optparse
    parse = optparse.OptionParser()
    parse.add_option("-H", "--database-hostname", help="machine name of statistic database", dest="hostname")

    parse.add_option("-e", "--elasticsearch-hostname", help="elasticsearch hostname", dest="es_host")
    parse.add_option("-u", "--username", help="username for ElasticSearch", dest="es_username")
    parse.add_option("-p", "--password", help="password for ElasticSearch", dest="es_password")
    parse.add_option("-n", "--port-number", help="port for Elasticsearch", dest="es_port", default=9200)

    options, args = parse.parse_args()
    if not check_parameters(options):
        parse.print_help()
        sys.exit(-1)

    try:
        do_database_statistic_import(options)
    except Exception, e:
        import traceback
        traceback.print_exc()
        sys.exit(-1)


if __name__ == '__main__':
    main()
