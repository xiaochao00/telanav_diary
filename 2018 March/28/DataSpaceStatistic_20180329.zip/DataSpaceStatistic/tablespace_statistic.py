# -*- coding: utf-8 -*-
"""
collection the information of specified machine
"""
import optparse
import os
import sys

from tablespace_util import find_tablespace_stat_info_dict, find_database_stat_info_list
from util.common_utils import dic_list2json

TABLESPACE_FILENAME_PATTERN = "tablespace_stat_info.json"
TABLESPACE_STAT_INFO_DUMP_NAME_TEMPLATE = "{hostname}_%s" % TABLESPACE_FILENAME_PATTERN

DATABASE_FILENAME_PATTERN = "database_stat_info.json"
DATABASE_STAT_INFO_DUMP_NAME_TEMPLATE = "{hostname}_%s" % DATABASE_FILENAME_PATTERN


def collect_tablespaces_info(output_dir, hostname="localhost"):
    tablespace_name_stat_info_dict = find_tablespace_stat_info_dict(host=hostname)
    tablespace_stat_info_dict_list = [stat_info.__dict__ for stat_info in tablespace_name_stat_info_dict.values()]
    dump_file_path = os.path.join(output_dir, TABLESPACE_STAT_INFO_DUMP_NAME_TEMPLATE.format(hostname=hostname))
    dic_list2json(tablespace_stat_info_dict_list, dump_file_path)


def collect_database_info(output_dir, hostname="localhost"):
    database_name_info_dict_list = find_database_stat_info_list(hostname)
    dump_file_path = os.path.join(output_dir, DATABASE_STAT_INFO_DUMP_NAME_TEMPLATE.format(host=hostname))
    dic_list2json(database_name_info_dict_list, dump_file_path)


def main():
    parser = optparse.OptionParser()
    parser.add_option("-T", "--tablespace-statistic", help="tablespace statistic", action="store_true",
                      dest="tablespace_stat", default=False)
    parser.add_option("-D", "--database-statistic", help="database statistic", action="store_true",
                      dest="database_stat", default=False)
    parser.add_option("-O", "--output-directory", help="output directory", dest="output_dir")

    options, args = parser.parse_args()
    # check
    if (options.tablespace_stat or options.database_stat) and not options.output_dir:
        parser.print_help()
        sys.exit(-1)
    # collect tablespace
    if options.tablespace_stat and options.output_dir:
        collect_tablespaces_info(options.output_dir)
    # collect database
    if options.database_stat and options.output_dir:
        collect_database_info(options.output_dir)


if __name__ == '__main__':
    main()
