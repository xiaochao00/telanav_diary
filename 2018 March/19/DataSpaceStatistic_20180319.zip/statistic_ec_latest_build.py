import os
import sys
import glob
from space_statistic_data import test_pbf_statistic, pretty_size
from statistic_parser import DataStat, JSUtils, JSChart, ChartData, OUT_PUT_JS_FILENAME, test_generate_pbf_js
import json

ROOT_DIR = os.path.abspath(os.path.dirname(__file__))
OUTPUT_STATISTIC_DIR = os.path.join(ROOT_DIR, "output_statistic")
OUTPUT_JS_DIR = os.path.join(ROOT_DIR, "output_js_builds")


class StatisticEcBuilds(object):
    @staticmethod
    def statistic_build(build_name, build_path):
        size = test_pbf_statistic(build_path, os.path.join(OUTPUT_STATISTIC_DIR, build_name), build_name)
        return size

    @staticmethod
    def statistic_ec_latest_build_by_mult(base_path):
        build_name_list = []
        build_path_list = []
        for build_name in os.listdir(base_path):
            build_path = os.path.join(base_path, build_name)
            if os.path.isdir(build_path):
                build_name_list.append(build_name)
                build_path_list.append(build_path)

        import multiprocessing
        pool = multiprocessing.Pool(processes=16)
        result_list = []
        for build_name, build_path in zip(build_name_list, build_path_list):
            result_list.append(pool.apply_async(StatisticEcBuilds.statistic_build, (build_name, build_path)))
        pool.close()
        pool.join()

        for i in range(len(result_list)):
            size = result_list[i].get()
            build_name = build_name_list[i]
            build_path = build_path_list[i]
            print build_name, build_path, pretty_size(size)

    @staticmethod
    def statistic_ec_latest_build(base_path):
        build_name_list = []
        build_path_list = []
        for build_name in os.listdir(base_path):
            build_path = os.path.join(base_path, build_name)
            if os.path.isdir(build_path):
                build_name_list.append(build_name)
                build_path_list.append(build_path)

        for build_name, build_path in zip(build_name_list, build_path_list):
            size = StatisticEcBuilds.statistic_build(build_name, build_path)
            print build_name, build_path, pretty_size(size)


class BuildsStat(DataStat):
    chart_type = "bar"
    table_name = "All builds Space Statistic"
    jump_rule = JSChart.series_name_jump_rule

    def __init__(self, build_name, build_type, build_size):
        DataStat.__init__(self, data_name=build_name, data_type=build_type, data_size=build_size)

    @staticmethod
    def data2chart_dic(pbf_list):
        chart_data_list = DataStat._list2chart_data_list(pbf_list)
        js_chart = ChartData.transform2chart(chart_data_list=chart_data_list,
                                             chart_type=BuildsStat.chart_type,
                                             title=BuildsStat.table_name,
                                             jump_rule=BuildsStat.jump_rule)
        return js_chart.format2dic()


class StatisticEcBuildsReader(object):
    @staticmethod
    def get_build_name_json_file_path_dic(statistic_out_dir):
        # return {build_name:json_file_path,...}
        build_name_json_file_path_dic = {}

        build_name_list = os.listdir(statistic_out_dir)
        for build_name in build_name_list:
            build_json_dir = os.path.join(statistic_out_dir, build_name)
            json_file_path_list = glob.glob(os.path.join(build_json_dir, "data", "pbf_data", "*.json"))
            if json_file_path_list:
                build_name_json_file_path_dic[build_name] = json_file_path_list[0]
        return build_name_json_file_path_dic

    @staticmethod
    def builds_json_reader(build_name_json_file_path_dic):
        builds_stat_data_list = []
        for build_name, file_path in build_name_json_file_path_dic.iteritems():
            with open(file_path, "r") as f:
                builds_data_list = json.load(f)
                f.close()
                total_build_size = 0
                for data in builds_data_list:
                    total_build_size += data["size"]
                builds_stat_data_list.append(BuildsStat(build_name=build_name, build_type="builds",
                                                        build_size=total_build_size))

        return builds_stat_data_list

    @staticmethod
    def builds_json_reader2(build_name_json_file_path_dic):
        """Read every version`s total size"""
        builds_stat_data_list = []
        for build_name, file_path in build_name_json_file_path_dic.iteritems():
            with open(file_path, "r") as f:
                builds_data_list = json.load(f)
                f.close()
                total_build_size = 0
                for data in builds_data_list:
                    version = data["version"]
                    size = data["size"]
                    builds_stat_data_list.append(BuildsStat(build_name=version, build_type=build_name,
                                                            build_size=size))

        return builds_stat_data_list

    @staticmethod
    def generate_builds_js(statistic_dir, output_js_dir):
        build_name_json_file_path_dic = StatisticEcBuildsReader.get_build_name_json_file_path_dic(statistic_dir)
        builds_stat_data_list = StatisticEcBuildsReader.builds_json_reader2(
            build_name_json_file_path_dic=build_name_json_file_path_dic)
        js_output_file_path = os.path.join(output_js_dir, "ec/builds", OUT_PUT_JS_FILENAME)
        JSUtils.save_parse_result(output_file_path=js_output_file_path,
                                  chart_dic_function=BuildsStat.data2chart_dic,
                                  pbf_list=builds_stat_data_list)
        output_sub_builds_js_dir = os.path.dirname(js_output_file_path)
        for build_name, json_file_path in build_name_json_file_path_dic.iteritems():
            output_sub_js_output_file_path = os.path.join(output_sub_builds_js_dir, build_name)
            test_generate_pbf_js(statistic_json_file_path=json_file_path,
                                 output_js_dir=output_sub_js_output_file_path)


if __name__ == '__main__':
    ec_latest_build_path = "/var/www/html/ec_latest_builds"
    # StatisticEcBuilds.statistic_ec_latest_build(ec_latest_build_path)
    StatisticEcBuildsReader.generate_builds_js(OUTPUT_STATISTIC_DIR, OUTPUT_JS_DIR)
    JSUtils.format_js_output_dir(output_base_dir="output_js_builds")
