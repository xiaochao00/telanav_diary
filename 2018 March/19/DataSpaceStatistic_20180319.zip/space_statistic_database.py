import glob
import os
import sys

from DBModule import DBModule
from data_type_statistic.data_types import RdfDB, Unidb
from db_info_collections import DBInfo, TablespaceInfo
from host_config.config_reader import Options, read_db_config
from space_statistic_data import OUTPUT_STATISTIC_DIR, STATISTIC_TYPE_LIST
from tablespace_util import find_tablespace_name_path_dic, find_tablespace_disk_space_info_dic
from util.common_utils import filter_database_name, dic_list2json, pretty_size, parse_pbf_data_data_name
from util.common_utils import parse_rdf_unidb_db_name, get_vendor_name, print_error, load_json2list

OUTPUT_STATISTIC_DB_DIR = "db"

OUTPUT_STATISTIC_RAW_DB_DIR = os.path.join(OUTPUT_STATISTIC_DB_DIR, "raw_db")
OUTPUT_STATISTIC_UNIDB_DB_DIR = os.path.join(OUTPUT_STATISTIC_DB_DIR, "unidb_db")

DB_STATISTIC_FILENAME_PREFIX = "db_statistic"
DB_STATISTIC_FILENAME = DB_STATISTIC_FILENAME_PREFIX + "_{host}.json"

OUTPUT_STATISTIC_RAW_DB_FILENAME = "raw_db_statistic.json"
OUTPUT_STATISTIC_UNIDB_DB_FILENAME = "unidb_db_statistic.json"


class DBStatisticUtils(object):
    @staticmethod
    def set_db_options(host="localhost", username="postgres", password="postgres", port="5432", database_name="postgres"):
        db_options = Options()
        setattr(db_options, "host", host)
        setattr(db_options, "username", username)
        setattr(db_options, "password", password)
        setattr(db_options, "port", port)
        return db_options

    @staticmethod
    def get_all_database_info(host_option):
        hostname = host_option.host
        username = host_option.username
        password = host_option.password
        port = host_option.port

        db_model = DBModule(host=hostname, username=username, password=password, port=port)
        all_database_name_size_dic = db_model.select_all_db_size_dic()

        selected_database_name_size_dic = dict([(d_name, size) for d_name, size in all_database_name_size_dic.iteritems()
                                                if filter_database_name(d_name)])

        database_info_list = []
        for database_name, db_size in selected_database_name_size_dic.iteritems():
            db_vendor, db_region, db_version = parse_rdf_unidb_db_name(database_name)
            if not db_region or not db_version:
                continue
            db_info = DBInfo(database_name, db_region, get_vendor_name(db_vendor), db_version, db_size)
            database_info_list.append(db_info)

        return database_info_list

    @staticmethod
    def get_all_host_database_info():
        all_host_options = read_db_config()
        database_info_list = []
        for host_option in all_host_options:
            if host_option.host == "10.179.1.110":
                print_error("KOR database cannot access. have pass")
                continue

            host_db_info_list = DBStatisticUtils.get_all_database_info(host_option)
            DBInfo.sort_list(host_db_info_list)
            database_info_list += host_db_info_list
        DBInfo.sort_list(database_info_list)
        return database_info_list

    @staticmethod
    def get_tablespace_usage_info(host_option):
        hostname = host_option.host
        username = host_option.username
        password = host_option.password
        port = host_option.port

        db_model = DBModule(host=hostname, username=username, password=password, port=port)
        tablespace_name_location_dic = find_tablespace_name_path_dic(hostname)
        # {name:disk_space_info,...}
        tablespace_size_info_dic = find_tablespace_disk_space_info_dic(hostname)
        tablespace_name_size_dic = db_model.select_tablespace_size_info_dic()
        # collection below info dic, [TablespaceInfo:,...]
        tablespace_info_list = []
        for name, location in tablespace_name_location_dic.iteritems():
            info_dic = tablespace_size_info_dic.get(name)
            db_used_size = tablespace_name_size_dic.get(name)
            tablespace_info = TablespaceInfo.transform_dic_to_info(name, location, info_dic, db_used_size)
            tablespace_info_list.append(tablespace_info)

        return tablespace_info_list


def statistic_raw_db(result_file_path, host_name):
    db_options = DBStatisticUtils.set_db_options()
    db_info_list = DBStatisticUtils.get_all_database_info(host_option=db_options)
    DBInfo.sort_list(db_info_list)

    db_data_dic_list = []
    for db_info in db_info_list:
        db_data_dic_list.append(db_info.__dict__)

    dic_list2json(db_data_dic_list, result_file_path)


def merge_db_statistic(out_dir):
    db_statistic_file_list = glob.glob(os.path.join(out_dir, OUTPUT_STATISTIC_DB_DIR,
                                                    DB_STATISTIC_FILENAME_PREFIX + "*.json"))
    db_info_dic_list = []
    # merge all database info list
    for db_statistic_file in db_statistic_file_list:
        db_info_dic_list += load_json2list(db_statistic_file)
    # transform json to DBInfo object
    db_info_list = DBInfo.transform_dic_list2db_info_list(db_info_dic_list=db_info_dic_list)
    DBInfo.sort_list(db_info_list)
    # split to rdf and pbf
    rdf_db_info_list, unidb_db_info_list = DBInfo.split2rdf_pbf_db_list(db_info_list)
    # transform rdf db
    rdfdb_dic_list = [RdfDB(name=db_info.database_name, region=db_info.region, vendor=db_info.vendor,
                            version=db_info.version, size=db_info.size,
                            size_pretty=pretty_size(db_info.size)).__dict__
                      for db_info in rdf_db_info_list]
    # save rdf json and pbf json file
    rdf_db_info_result_file_path = os.path.join(out_dir, OUTPUT_STATISTIC_RAW_DB_DIR, OUTPUT_STATISTIC_RAW_DB_FILENAME)
    dic_list2json(rdfdb_dic_list, rdf_db_info_result_file_path)
    # transform unidb
    unidb_dic_list = []
    for db_info in unidb_db_info_list:
        create_time, release_type = parse_pbf_data_data_name(db_info.database_name)
        unidb = Unidb(name=db_info.database_name, region=db_info.region, vendor=db_info.vendor, version=db_info.version,
                      size=db_info.size, size_pretty=pretty_size(db_info.size), create_time=create_time,
                      release_type=release_type)
        unidb_dic_list.append(unidb.__dict__)

    # save unidb
    unidb_db_info_result_file_path = os.path.join(out_dir, OUTPUT_STATISTIC_UNIDB_DB_DIR,
                                                  OUTPUT_STATISTIC_UNIDB_DB_FILENAME)
    dic_list2json(unidb_dic_list, unidb_db_info_result_file_path)


def test_raw_db_statistic(host_name, out_dir):
    result_file_path = os.path.join(out_dir, OUTPUT_STATISTIC_DB_DIR, DB_STATISTIC_FILENAME.format(host=host_name))
    statistic_raw_db(result_file_path, host_name)


def check_parameters(options):
    if not os.path.exists(options.output_path):
        sys.stderr.write("Output path do not exist.\n")
        return False

    if not options.statistic_type or options.statistic_type not in STATISTIC_TYPE_LIST:
        sys.stderr.write("statistic type should not be None.\n")
        return False
    return True


def main():
    import optparse
    parse = optparse.OptionParser()
    parse.add_option("-N", "--database-machine-name", help="machine name of statistic database", dest="machine_name")
    parse.add_option("-M", "--merge-db", help="is need merge db statistic", dest="merge_db",
                     action="store_true", default=False)
    parse.add_option("-O", "--output-path", help="statistic output path", dest="output_path", default=OUTPUT_STATISTIC_DIR)
    parse.add_option("-T", "--statistic-type", help="like autonavi,kor,global_cn,global_others", dest="statistic_type")

    options, args = parse.parse_args()
    if not check_parameters(options):
        parse.print_help()
        sys.exit(-1)

    output_path = os.path.join(options.output_path, options.statistic_type)
    if options.merge_db:
        merge_db_statistic(output_path)
    elif options.machine_name:
        test_raw_db_statistic(host_name=options.machine_name, out_dir=output_path)


if __name__ == '__main__':
    main()
