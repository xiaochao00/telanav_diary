# encoding=utf8
import glob
import json
import os
import sys
from collections import namedtuple

from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk

# rdf_db_statistic_file_path = "output_statistic/db/raw_db/raw_db_statistic.json"
es = Elasticsearch("localhost:9200")
# es = Elasticsearch(hosts=["172.16.101.122"], http_auth=("elastic", "8KLnWe^eeyWN4EHKtagu"), port=9200)

statistic_type_dic = {"data": ["pbf_data", "raw_data"],
                      "db": ["raw_db", "unidb_db"]}
region_type_list = ["autonavi", "global_cn", "global_other", "kor"]


def get_json_file(statistic_type_dir, region_type, base_path):
    json_path_pattern = os.path.join(base_path, region_type, statistic_type_dir, "*.json")
    json_path_list = glob.glob(json_path_pattern)
    if not json_path_list:
        print "can not find json file[%s]" % json_path_pattern
        sys.exit(-1)
    return json_path_list[0]


StatisticDataFile = namedtuple("StatisticDataFile", "region_type,statistic_type,json_file_path")


def get_statistic_file_list(base_path):
    statistic_file_list = []
    for region_type in region_type_list:
        for is_db, statistic_type_list in statistic_type_dic.iteritems():
            for statistic_type in statistic_type_list:
                statistic_type_dir = os.path.join(is_db, statistic_type)
                db_json_file_path = get_json_file(statistic_type_dir, region_type, base_path)
                statistic_file_list.append(StatisticDataFile(region_type=region_type, statistic_type=statistic_type,
                                                             json_file_path=db_json_file_path))
    return statistic_file_list


def import2es(index_name, doc_type, json_file_path):
    res = es.indices.create(index=index_name, ignore=400)
    with open(json_file_path, "r") as f:
        data_list = json.load(f)

        actions = [
            {
                "_op_type": "index",
                "_index": index_name,
                "_type": doc_type,
                "_source": d,
                "_id": "{category}_{vendor}_{region}_{version}_{name}".format(category=d["category"],
                                                                              vendor=d["vendor"], region=d["region"],
                                                                              version=d["version"], name=d["name"])
            }
            for d in data_list
        ]
        bulk(es, actions)


def process_old():
    base_path = os.path.join(os.path.dirname(__file__), "output_statistic")
    statistic_file_list = get_statistic_file_list(base_path)
    for s_file in statistic_file_list:
        index_name = s_file.region_type
        doc_type = s_file.statistic_type
        import2es(index_name=index_name + "_" + doc_type, doc_type=doc_type, json_file_path=s_file.json_file_path)


def process_autonavi_builds():
    builds_path = os.path.join(os.path.dirname(__file__), "pbf_statistic_autonavi.json")
    builds_index_name = "builds_data"
    builds_doc_type = "data_stat_doc"
    import2es(builds_index_name, builds_doc_type, builds_path)


if __name__ == '__main__':
    process_autonavi_builds()
    # pass
