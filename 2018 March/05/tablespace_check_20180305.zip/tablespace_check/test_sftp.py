import json
import os
import stat

import paramiko


class SFTPConnection(object):
    def __init__(self, host, username, password, port):
        try:
            self.transport = paramiko.Transport((host, port))
            self.transport.connect(username=username, password=password)
            self.sftp = paramiko.SFTPClient.from_transport(self.transport)
            print self.sftp.listdir("/")
        except Exception, e:
            print e

    def traverse_directory(self, base_dir, deep=1):
        dir_stru = {}
        base_dir_name = os.path.basename(base_dir)
        dir_list = self.sftp.listdir(base_dir)
        for dir_name in dir_list:
            dir_path = os.path.join(base_dir, dir_name)
            if stat.S_ISDIR(self.sftp.stat(dir_path).st_mode):
                if deep > 1:
                    dir_stru.setdefault(base_dir_name, []).append(self.traverse_directory(base_dir=dir_path,
                                                                                          deep=deep - 1))
                else:
                    dir_stru.setdefault(base_dir_name, []).append(dir_name)
            else:
                dir_stru.setdefault(base_dir_name, []).append(dir_name)

        return dir_stru


if __name__ == '__main__':
    traverse_dir = "/"
    host = "kor-download.ext.here.com"
    username = "telenav"
    password = "GT2r7qTlRUadYM"
    port = 7222
    sftp_conn = SFTPConnection(host=host, username=username, password=password, port=port)
    traverse_dir_stru = sftp_conn.traverse_directory(traverse_dir, 1)
    print json.dumps(traverse_dir_stru, indent=4, separators=(",", ":"))
