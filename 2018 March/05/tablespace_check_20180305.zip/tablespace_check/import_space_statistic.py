import glob
import json
import os
import sys

from elasticsearch_importer import ElasticSearchImporter
from space_statistic import OUTPUT_STATISTIC_PBF_DATA_DIR as pbf_data_dir
from space_statistic import OUTPUT_STATISTIC_RAW_DATA_DIR as raw_data_dir
from space_statistic import OUTPUT_STATISTIC_RAW_DB_DIR as rdf_db_dir
from space_statistic import OUTPUT_STATISTIC_UNIDB_DB_DIR as unidb_db_dir
from space_statistic import STATISTIC_TYPE_LIST

stat_data_index_name = "data_stat_index"
stat_data_doc_type = "data_stat_type"


class DataImport(object):
    def __init__(self, hostname="localhost", username=None, password=None):
        self.elasticsearch_import = ElasticSearchImporter(host=hostname, username=username, password=password)

    def import_data(self, file_path, index_name, doc_type):
        old_id_data_list = self.elasticsearch_import.search_data(index_name=index_name, doc_type=doc_type)

        with open(file_path, "r") as f:
            new_builds_data_list = json.load(f)
            new_builds_data_name_data_dic = dict([(generate_dist_data_name(data), data)
                                                  for data in new_builds_data_list])
            old_builds_data_name_list = []
            update_data_id_data_dict = {}

            for id_index, old_data in old_id_data_list:
                data_name = generate_dist_data_name(old_data)
                old_builds_data_name_list.append(data_name)
                if data_name in new_builds_data_name_data_dic:
                    # 1.if exist path, update data
                    new_data = new_builds_data_name_data_dic[data_name]
                    update_data_id_data_dict[id_index] = new_data
                else:
                    # 2.if not exist, add remove field
                    old_data["is_remove"] = True
                    update_data_id_data_dict[id_index] = old_data
            # 3.if new path, insert
            insert_data_list = [data for data in new_builds_data_list
                                if generate_dist_data_name(data) not in old_builds_data_name_list]
            # 4. update and insert
            self.elasticsearch_import.update_data_list(index_name=index_name, doc_type=doc_type,
                                                       id_data_dict=update_data_id_data_dict)
            self.elasticsearch_import.insert_data_list(index_name=index_name, doc_type=doc_type,
                                                       data_list=insert_data_list)


def collect_statistic_files(stat_out_dir):
    stat_file_list = []
    raw_data_json_file_pattern = os.path.join(os.path.join(stat_out_dir, "*", raw_data_dir, "*.json"))
    pbf_data_json_file_pattern = os.path.join(os.path.join(stat_out_dir, "*", pbf_data_dir, "*.json"))
    rdf_db_json_file_pattern = os.path.join(os.path.join(stat_out_dir, "*", rdf_db_dir, "*.json"))
    unidb_db_json_file_pattern = os.path.join(os.path.join(stat_out_dir, "*", unidb_db_dir, "*.json"))

    sub_dir_list = os.listdir(stat_out_dir)
    for sub_dir in sub_dir_list:
        if sub_dir in STATISTIC_TYPE_LIST:
            stat_file_list.extend(glob.glob(raw_data_json_file_pattern))
            stat_file_list.extend(glob.glob(pbf_data_json_file_pattern))
            stat_file_list.extend(glob.glob(rdf_db_json_file_pattern))
            stat_file_list.extend(glob.glob(unidb_db_json_file_pattern))
    return stat_file_list


def data_import(elasticsearch_host, elasticsearch_username, elasticsearch_password, stat_out_dir):
    d_i = DataImport(hostname=elasticsearch_host, username=elasticsearch_username,
                     password=elasticsearch_password)
    stat_file_list = collect_statistic_files(stat_out_dir=stat_out_dir)
    for stat_file in stat_file_list:
        d_i.import_data(stat_file, stat_data_index_name, stat_data_doc_type)


def generate_dist_data_name(data):
    return "_".join([data["category"], data["name"], data["region"], data["version"], data["vendor"]])


def main():
    import optparse
    parse = optparse.OptionParser()

    parse.add_option("-H", "--hostname", help="hostname", dest="hostname")
    parse.add_option("-P", "--password", help="password", dest="password")
    parse.add_option("-U", "--username", help="username", dest="username")
    parse.add_option("-O", "--stat-out-dir", help="stat out dir", dest="stat_out_dir")

    options, args = parse.parse_args()

    hostname = options.hostname
    password = options.password
    username = options.username
    stat_out_dir = options.stat_out_dir

    if not hostname:
        sys.stderr.write("hostname should not empty.\n")
    if not stat_out_dir or not os.path.exists(stat_out_dir):
        sys.stderr.write("the statistic out dir should not empty or not exist.\n")

    data_import(hostname, username, password, stat_out_dir)


if __name__ == '__main__':
    main()
