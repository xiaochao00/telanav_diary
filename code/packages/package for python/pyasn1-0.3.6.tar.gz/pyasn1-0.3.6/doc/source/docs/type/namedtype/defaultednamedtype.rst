
.. |NamedType| replace:: DefaultedNamedType

|NamedType|
------------------

.. autoclass:: pyasn1.type.namedtype.DefaultedNamedType
   :members:

   .. note::

        The |NamedType| class models named field of a constructed ASN.1 type which has a default value.
