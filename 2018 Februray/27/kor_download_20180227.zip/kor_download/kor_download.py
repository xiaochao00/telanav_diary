import optparse
import os
import sys

from KORDataDownloader import KORDataDownloader

KOR_DOWNLOAD_BASENAME_PATH = "misc"


def main():
    parser = optparse.OptionParser()
    parser.add_option("-V", "--data-version", help="data version like 17Q2", dest="data_version")
    parser.add_option("-R", "--kor-raw-data-path", help="kor raw data path", dest="raw_data_path")
    parser.add_option("-P", "--sftp-password", help="password of sftp user", dest="sftp_password")

    options, args = parser.parse_args()
    data_version = options.data_version
    raw_data_path = options.raw_data_path
    sftp_password = options.sftp_password
    if not data_version:
        sys.stderr.write("data version can not be none.\n")
        parser.print_help()
        sys.exit(-1)
    if not raw_data_path or not os.path.exists(raw_data_path):
        sys.stderr.write("kor data path[%s] can not be none or not exist.\n" % raw_data_path)
        parser.print_help()
        sys.exit(-1)
    if not sftp_password:
        sys.stderr.write("sftp password can not be none.\n")
        parser.print_help()
        sys.exit(-1)

    kor_download_path = os.path.join(raw_data_path, KOR_DOWNLOAD_BASENAME_PATH)
    if not os.path.exists(kor_download_path):
        os.mkdir(kor_download_path)

    kor_download = KORDataDownloader(quarter=data_version, sftp_password=sftp_password, project="auto")
    kor_download.download_rdf()
    kor_download.download_add_content()
    kor_download.data_prepared()


if __name__ == '__main__':
    main()
