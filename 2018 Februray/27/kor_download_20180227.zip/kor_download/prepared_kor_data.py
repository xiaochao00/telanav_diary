import glob
import optparse
import os
import shutil
import sys

from utils.util import safe_execute


def search(rdf_raw_data_path, target_file):
    for root, dirs, files in os.walk(rdf_raw_data_path):
        complete_path = glob.glob(os.path.join(root, target_file))
        if complete_path:
            return complete_path[0]


class KoreaPreProcessor(object):
    RDF_TRAGET_FILE = 'KRAM*_Core.zip'
    """
    *NG_Core.zip was a fuzzy product name for RDF core product.
    """
    RDF_FINAL_PATH = '__rdf'

    LANDMARK_TRAGET_FILE = 'VC9310_*.zip'
    """
    VC9310_*.zip was a fuzzy product name for 3D landmark in Korea. Below VC9320,\
    RC9430 were also corresponding with other products. Detailed, please refer to \
    http://spaces.telenav.com:8080/display/map/Korea+Raw+Data+File+Structure 
    """
    LANDMARK_FINAL_PATH = 'components/3dlandmark_vendor'
    LANDMARK_FILE_NAME = 'KOR.zip'

    JUNCTION_TRAGET_FILE = 'VC9320_*.zip'
    JUNCTION_FINAL_PATH = 'components/junction_view'
    JUNCTION_FILE_NAME = 'KOR_JV.zip'

    NEWADDR_TOLL_TRAGET_FILE = 'LAT*.zip'
    TOLLCOST_FINAL_PATH = 'components/TOLL_COST'
    TOLLCOST_FILE_STRUCTURE = '*/TOLL_COST/*'

    NEWADDRESS_FINAL_PATH = 'components/NEW_ADDRESS'
    NEWADDRESS_FILE_STRUCTURE = '*/NEW_ADDRESS/*'

    SPEEDCAM_TRAGET_FILE = 'RC9430_*.zip'
    SPEEDCAM_FINAL_PATH = 'components/speed_camera'
    SPEEDCAM_FILE_STRUCTURE = '*/Safety_Cameras_Korea/*'

    def __init__(self, rdf_raw_data_path, target_data_path):
        self.rdf_raw_data_path = rdf_raw_data_path
        self.target_data_path = target_data_path
        self.rdf_complete_path = ''
        self.landmark_complete_path = ''
        self.junction_view_complete_path = ''
        self.new_addr_toll_complete_path = ''
        self.speed_camera_complete_path = ''

    def process(self):
        if not self.check():
            return False
        if not self._rdf_data():
            return False
        if not self._landmark_data():
            return False
        if not self._junction_view_data():
            return False
        if not self.__toll_cost_data():
            return False
        if not self.__new_address_data():
            return False
        if not self.__speed_camera_data():
            return False
        return True

    def check(self):
        self.rdf_complete_path = search(self.rdf_raw_data_path, target_file=self.RDF_TRAGET_FILE)
        self.landmark_complete_path = search(self.rdf_raw_data_path, target_file=self.LANDMARK_TRAGET_FILE)
        self.junction_view_complete_path = search(self.rdf_raw_data_path, target_file=self.JUNCTION_TRAGET_FILE)
        self.new_addr_toll_complete_path = search(self.rdf_raw_data_path, target_file=self.NEWADDR_TOLL_TRAGET_FILE)
        self.speed_camera_complete_path = search(self.rdf_raw_data_path, target_file=self.SPEEDCAM_TRAGET_FILE)
        if not self.rdf_complete_path:
            print '%s not exist.' % self.rdf_complete_path
            return False
        if not self.landmark_complete_path:
            print '%s not exist.' % self.landmark_complete_path
            return False
        if not self.junction_view_complete_path:
            print '%s not exist.' % self.junction_view_complete_path
            return False
        if not self.new_addr_toll_complete_path:
            print '%s not exist.' % self.new_addr_toll_complete_path
            return False
        if not self.speed_camera_complete_path:
            print '%s not exist.' % self.speed_camera_complete_path
            return False
        return True

    def _rdf_data(self):
        """
        1. Process rdf data
        """
        rdf_full_path = os.path.join(self.target_data_path, self.RDF_FINAL_PATH)
        rdf_file_path = os.path.join(rdf_full_path, self.RDF_TRAGET_FILE)

        if not os.path.exists(rdf_full_path):
            os.makedirs(rdf_full_path)

        if os.path.exists(rdf_file_path):
            os.remove(rdf_file_path)

        cmd1 = 'cp %s %s' % (self.rdf_complete_path, rdf_full_path)
        safe_execute(cmd1)

        print("Deploying rdf data to file %s from directory %s succeeded!!!!!!" % (
            rdf_file_path, self.rdf_raw_data_path))

        return True

    def _landmark_data(self):
        """
        2. Process landmark data
        """
        landmark_full_path = os.path.join(self.target_data_path, self.LANDMARK_FINAL_PATH)
        landmark_file_path = os.path.join(landmark_full_path, self.LANDMARK_FILE_NAME)
        if not os.path.exists(landmark_full_path):
            os.makedirs(landmark_full_path)

        if os.path.exists(landmark_file_path):
            # shutil.rmtree(landmark_file_path)
            os.remove(landmark_file_path)

        cmd1 = 'cp %s %s' % (self.landmark_complete_path, landmark_file_path)
        safe_execute(cmd1)

        print("Deploying landmark data to file %s from directory %s succeeded!!!!!!" % (
            landmark_file_path, self.rdf_raw_data_path))

        return True

    def _junction_view_data(self):
        """
        3. Process junction view data
        """

        junction_full_path = os.path.join(self.target_data_path, self.JUNCTION_FINAL_PATH)
        junction_file_path = os.path.join(junction_full_path, self.JUNCTION_FILE_NAME)
        if not os.path.exists(junction_full_path):
            os.makedirs(junction_full_path)

        if os.path.exists(junction_file_path):
            # shutil.rmtree(junction_file_path)
            os.remove(junction_file_path)

        cmd1 = 'cp %s %s' % (self.junction_view_complete_path, junction_file_path)
        safe_execute(cmd1)

        print ("Deploying junction view data to file %s from directory %s succeeded!!!!!!" % (
            junction_file_path, self.rdf_raw_data_path))

        return True

    def __toll_cost_data(self):
        """
        4. Process toll cost data
        """

        toll_full_path = os.path.join(self.target_data_path, self.TOLLCOST_FINAL_PATH)

        if os.path.exists(toll_full_path):
            shutil.rmtree(toll_full_path)
            # os.removedirs(toll_full_path)
        os.makedirs(toll_full_path)

        cmd1 = 'unzip -j %s %s -d %s' % (self.new_addr_toll_complete_path, self.TOLLCOST_FILE_STRUCTURE, toll_full_path)
        safe_execute(cmd1)

        print("Deploying toll cost data to file %s from directory %s succeeded!!!!!!" % (
            toll_full_path, self.rdf_raw_data_path))

        return True

    def __new_address_data(self):
        """
        5. Process new address data
        """
        address_full_path = os.path.join(self.target_data_path, self.NEWADDRESS_FINAL_PATH)

        if os.path.exists(address_full_path):
            # os.removedirs(address_full_path)
            shutil.rmtree(address_full_path)
        os.makedirs(address_full_path)

        cmd1 = 'unzip -j %s %s -d %s' % (
            self.new_addr_toll_complete_path, self.NEWADDRESS_FILE_STRUCTURE, address_full_path)
        safe_execute(cmd1)

        print ("Deploying new address data to file %s from directory %s succeeded!!!!!!" % (
            address_full_path, self.rdf_raw_data_path))

        return True

    def __speed_camera_data(self):
        """
        6. Process speed camera data
        """
        speedcam_full_path = os.path.join(self.target_data_path, self.SPEEDCAM_FINAL_PATH)

        if os.path.exists(speedcam_full_path):
            # os.removedirs(speedcam_full_path) "only support empty ""
            shutil.rmtree(speedcam_full_path)
        os.makedirs(speedcam_full_path)

        cmd1 = 'unzip -j %s %s -d %s' % (
            self.speed_camera_complete_path, self.SPEEDCAM_FILE_STRUCTURE, speedcam_full_path)
        safe_execute(cmd1)

        print ("Deploying speed camera data to file %s from directory %s succeeded!!!!!!" % (
            speedcam_full_path, self.rdf_raw_data_path))

        return True


def main():
    parser = optparse.OptionParser()

    parser.add_option('-R', '--rdf_raw_data_path', help='rdf_raw_data_path', dest='rdf_raw_data_path')
    parser.add_option('-D', '--target_data_path', help='target_data_path', dest='target_data_path')

    options, args = parser.parse_args()

    if not (options.rdf_raw_data_path or options.target_data_path):
        parser.print_help()
        sys.exit(-1)

    pp = KoreaPreProcessor(options.rdf_raw_data_path, options.target_data_path)

    if not pp.process():
        sys.exit(-1)


if __name__ == '__main__':
    main()
