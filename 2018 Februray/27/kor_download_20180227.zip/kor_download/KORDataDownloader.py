import ConfigParser
import os
import re
import stat
import sys
import traceback

import paramiko

from utils.util import pretty_size

KOR_RDF_SOURCE_PATH = "/data/150_RDF_Core"
KOR_ADD_CONTENT_SOURCE_PATH = "/data/510_Additional_Contents"
KOR_SOURCE_PATH_BASENAME = "Q{quarter}{year}"

KOR_SFTP_HOST = "kor-download.ext.here.com"
KOR_SFTP_PORT = 7222
KOR_SFTP_USER = "telenav"


def parser_data_version(data_version):
    """Data quarter --> year,quarter_num . 17Q4 --> 17,4"""
    p = "(\d+)Q([1-4])"
    m = re.match(p, data_version)
    if not m:
        sys.stderr.write("Data quarter parser failed. [%s] is not format like 17Q4.\n" % data_version)
        sys.exit(-1)
    return int(m.group(1)), int(m.group(2))


class SFTPConnection(object):
    def __init__(self, host, username, password, port=22):
        try:
            self.transport = paramiko.Transport(sock=(host, port))
            self.transport.connect(username=username, password=password)
            self.sftp = paramiko.SFTPClient.from_transport(self.transport)
        except Exception, e:
            traceback.print_exc()
            sys.stderr.write("%s\n" % e)
            sys.exit(-1)

    def __del__(self):
        if self.transport:
            self.transport.close()

    def traverse_directory(self, base_dir, deep=1):
        """Traverse directory"""
        dir_stru = {}
        base_dir_name = os.path.basename(base_dir)
        dir_list = self.sftp.listdir(base_dir)

        for dir_name in dir_list:
            dir_path = os.path.join(base_dir, dir_name)
            if not self._is_file(dir_path):
                if deep > 1:
                    dir_stru.setdefault(base_dir_name, []).append(self.traverse_directory(base_dir=dir_path,
                                                                                          deep=deep - 1))
                else:
                    dir_stru.setdefault(base_dir_name, []).append(dir_name)
            else:
                dir_stru.setdefault(base_dir_name, []).append(dir_name)

        if not dir_list:
            dir_stru.setdefault(base_dir_name, []).append("")

        return dir_stru

    def _is_file(self, file_path):
        if not self.exist_path(file_path):
            sys.stderr.write("File path is not exist.[%s]\n" % file_path)
            return None
        return not stat.S_ISDIR(self.sftp.stat(file_path).st_mode)

    def exist_path(self, file_path):
        try:
            file_stat = self.sftp.stat(file_path)
            return True
        except IOError, e:
            traceback.print_exc()
            sys.stderr.write("%s\n" % e)
            return False

    def file_downloader(self, file_path_src, file_dir_des):
        file_path_des = os.path.join(file_dir_des, os.path.basename(file_path_src))
        if os.path.exists(file_path_des):
            sys.stderr.write("Download File[%s] have exist. Pass it.\n" % file_path_des)
            return
        if not os.path.exists(file_dir_des):
            os.mkdir(file_dir_des)
        sys.stdout.write("File[%s] size is %s \n" % (file_path_src, pretty_size(self.sftp.stat(file_path_src).st_size)))

        self.sftp.get(file_path_src, file_path_des)
        sys.stdout.write("Download file[%s] to [%s] done.\n" % (file_path_src, file_path_des))

    def directory_download(self, dir_path_src, dir_path_des):
        if not os.path.exists(dir_path_des):
            os.mkdir(dir_path_des)
        for sub_dir_name in self.sftp.listdir(dir_path_src):
            sub_dir_path = os.path.join(dir_path_src, sub_dir_name)
            if self._is_file(sub_dir_path):
                self.file_downloader(sub_dir_path, dir_path_des)
            else:
                self.directory_download(sub_dir_path, os.path.join(dir_path_des, sub_dir_name))
        sys.stdout.write("Download data from directory[%s] to [%s] done.\n" % (dir_path_src, dir_path_des))


class KORDataDownloader(object):
    def __init__(self, quarter, project, sftp_password):
        self.region = "KOR"
        self.data_version = quarter
        self.sftp_password = sftp_password

        self.download_sftp_conn = SFTPConnection(host=KOR_SFTP_HOST, username=KOR_SFTP_USER,
                                                 password=self.sftp_password, port=KOR_SFTP_PORT)
        self.download_output_path = ""
        self.prepared_output_path = ""
        self.data_path = ""

        self._set_path(project)

    def _set_path(self, project="auto"):
        config_file = "%s/config/%s_path.txt" % (sys.path[0], project)
        conf = ConfigParser.ConfigParser()
        conf.read(config_file)
        self.data_path = conf.get("RDF", "data_path")
        raw_data_path = os.path.join(self.data_path, "%s_HERE_%s" % (self.region, self.data_version))
        self.download_output_path = os.path.join(raw_data_path, "misc")
        self.prepared_output_path = raw_data_path

    def download_rdf(self):
        """Download KOR rdf data from remote machine."""
        year, quarter = parser_data_version(self.data_version)
        rdf_basename = KOR_SOURCE_PATH_BASENAME.format(quarter=quarter, year=year)
        rdf_path = os.path.join(KOR_RDF_SOURCE_PATH, rdf_basename)
        # check invalid path or empty directory
        if (not self.download_sftp_conn.exist_path(rdf_path) or
                not self.download_sftp_conn.sftp.listdir(rdf_path)):
            sys.stderr.write("The remote rdf path[%s] is not exist or is a empty directory\n" % rdf_path)
            sys.exit(-1)

        sys.stdout.write("RDF Files list in %s are : %s \n" % (
            rdf_path, self.download_sftp_conn.traverse_directory(base_dir=rdf_path)))

        self.download_sftp_conn.directory_download(dir_path_src=rdf_path, dir_path_des=self.download_output_path)

    def download_add_content(self):
        """Download KOR add content data from remote machine."""
        year, quarter = parser_data_version(self.data_version)
        add_content_basename = KOR_SOURCE_PATH_BASENAME.format(quarter=quarter, year=year)
        add_content_path = os.path.join(KOR_RDF_SOURCE_PATH, add_content_basename)
        # check invalid path or empty directory
        if (not self.download_sftp_conn.exist_path(add_content_path) or
                not self.download_sftp_conn.sftp.listdir(add_content_path)):
            sys.stderr.write("The remote add_content path[%s] is not exist or is a empty directory\n" % add_content_path)
            sys.exit(-1)
        sys.stdout.write("Add Content Files list in %s are : %s \n" % (
            add_content_path, self.download_sftp_conn.traverse_directory(base_dir=add_content_path)))

        self.download_sftp_conn.directory_download(dir_path_src=add_content_path, dir_path_des=self.download_output_path)

    def data_prepared(self):
        from prepared_kor_data import KoreaPreProcessor
        pp = KoreaPreProcessor(self.download_output_path, self.prepared_output_path)
        if not pp.check():
            sys.stderr.write("KOR data are not full download, please wait for full data prepared in remote machine.\n")
            return

        if not pp.process():
            sys.stderr.write("KOR data prepared failed.\n")
            sys.exit(-1)
