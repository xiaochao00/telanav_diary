import json

from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk


class ElasticSearchImporter(object):
    batch_search_size = 1000

    def __init__(self, host, port=9200, username=None, password=None):
        if not username or not password:
            self.es = Elasticsearch(hosts=[host], port=port)
        else:
            self.es = Elasticsearch(hosts=[host], port=port, http_auth=(username, password))

    def _check_response(self, res):
        pass

    def search_size(self, index_name, doc_type):
        res = self.es.search(index=index_name, doc_type=doc_type, body={"query": {"match_all": {}}})
        return res["hits"]["total"]

    def is_exist_index_doc_type(self, index_name, doc_type):
        res = self.es.search(index=index_name, doc_type=doc_type, body={"query": {"match_all": {}}})
        if u"error" in res:
            return False
        return True

    def insert_by_batch(self, index_name, doc_type, data_list):
        batch_size = len(data_list) / self.batch_search_size + 1
        for i in range(batch_size):
            begin_index = self.batch_search_size * i
            end_index = begin_index + self.batch_search_size
            self.insert_data_list(index_name=index_name, doc_type=doc_type, data_list=data_list[begin_index:end_index])

    def insert_data_list(self, index_name, doc_type, data_list):
        if not self.is_exist_index_doc_type(index_name=index_name, doc_type=doc_type):
            self.es.create(index=index_name, doc_type=doc_type)
        actions = [
            {
                "_op_type": "index",
                "_index": index_name,
                "_type": doc_type,
                "_source": d
            }
            for d in data_list
        ]
        res = bulk(self.es, actions)

    def search_data(self, index_name, doc_type):
        total_size = self.search_size(index_name=index_name, doc_type=doc_type)
        # search data by page
        total_page = total_size / self.batch_search_size + 1
        for page_num in range(total_page):
            batch_result_data = self.es.search(index=index_name, doc_type=doc_type, from_=page_num,
                                               size=self.batch_search_size)
            if not batch_result_data[u"hits"].get(u"hits"):
                break
            id_data_list = [(result[u"_id"], result[u"_source"])
                            for result in batch_result_data[u"hits"][u"hits"]]
            yield id_data_list

    def search_by_body(self, index_name, doc_type, **kwargs):
        body = {
            "query": {
                "match": kwargs
            },
            "size": 1
        }
        res = self.es.search(index_name, doc_type, body)
        print res

    def update_data_list(self, index_name, doc_type, id_data_dict):
        actions = [
            {
                # "_op_type": "update",
                "_index": index_name,
                "_type": doc_type,
                "_source": d,
                "_id": id_index
            }
            for id_index, d in id_data_dict.iteritems()
        ]
        res = bulk(self.es, actions)

    def clear_index_doc(self, index_name, doc_type):
        res = self.es.delete_by_query(index=index_name, doc_type=doc_type, body={"query": {"match_all": {}}})


def import_builds_data(builds_file_path):
    builds_index_name = "builds_data"
    builds_doc_type = "data_stat_doc"
    es_import = ElasticSearchImporter(host="localhost")

    old_id_data_list = es_import.search_data(index_name=builds_index_name, doc_type=builds_doc_type)

    with open(builds_file_path, "r") as f:
        new_builds_data_list = json.load(f)
        new_builds_path_data_dic = dict([(data["data_path"], data) for data in new_builds_data_list])
        old_builds_path_list = []
        update_data_id_data_dict = {}

        for id_data_ter in old_id_data_list:
            for id_index, old_data in id_data_ter:
                data_path = old_data["data_path"]
                old_builds_path_list.append(data_path)
                if data_path in new_builds_path_data_dic:
                    # 1.if exist path, update data
                    update_data_id_data_dict[id_index] = new_builds_path_data_dic[data_path]
                else:
                    # 2.if not exist, add remove field
                    old_data["is_remove"] = True
                    update_data_id_data_dict[id_index] = old_data
        # 3.if new path, insert
        insert_data_list = [data for data in new_builds_data_list if data["data_path"] not in old_builds_path_list]
        # 4. update and insert
        es_import.update_data_list(index_name=builds_index_name, doc_type=builds_doc_type,
                                   id_data_dict=update_data_id_data_dict)
        es_import.insert_data_list(index_name=builds_index_name, doc_type=builds_doc_type, data_list=insert_data_list)


def test_search():
    builds_index_name = "builds_data"
    builds_doc_type = "data_stat_doc"
    es_import = ElasticSearchImporter(host="localhost")
    es_import.search_by_body(index_name=builds_index_name, doc_type=builds_doc_type,
                             data_path="/var/www/html/ec_latest_builds/DENALI_NGXTRAFFIC/CN_AXF_16Q2/DENALI_NGXTRAFFIC-CN_AXF_16Q2-TnMapDataAccess-linux-centos6x64-2.9.491956-trunk-20170510093257-RC")


if __name__ == '__main__':
    # import_builds_data("pbf_statistic_autonavi.json")
    test_search()
