import sys

from DBModule import DBModule
from util.command_utils import execute_df_command
from util.common_utils import is_localhost, print_error, is_rdf_db_name, is_unidb_db_name, parse_rdf_unidb_db_name, \
    filter_database_name


class TablespaceStatInfo(object):
    def __init__(self, hostname, tablespace_name, tablespace_path, tablespace_size):
        self.hostname = hostname
        self.tablespace_name = tablespace_name
        self.tablespace_path = tablespace_path
        self.tablespace_size = tablespace_size
        self.disk_total_size = 0l
        self.disk_left_size = 0l
        self.disk_mount_on = ""

    def set_disk_info(self):
        disk_size_info = execute_df_command(self.tablespace_path)
        if not disk_size_info:
            print_error("Failed in get the disk size information of tablespace[%s] in [%s]." % (
                self.tablespace_name, self.tablespace_path))
            return False
        self.disk_left_size = disk_size_info.left_size
        self.disk_total_size = disk_size_info.total_size
        self.disk_mount_on = disk_size_info.mount_on
        return True

    @staticmethod
    def transform_dict_list2object(info_dict_list):
        info_list = []
        for info_dict in info_dict_list:
            info = TablespaceStatInfo(hostname="", tablespace_name="", tablespace_path="", tablespace_size=0l)
            info.__dict__ = info_dict
            info_list.append(info)
        return info_list


class DatabaseStatInfo(object):
    """Database information class"""

    def __init__(self, hostname, database_name, region, vendor, version, size):
        self.hostname = hostname
        self.database_name = database_name
        self.vendor = vendor.upper()

        self.region = region.upper()
        self.version = version.upper()
        self.size = size

    @staticmethod
    def sort_list(db_info_list):
        db_info_list.sort(key=lambda db_info: db_info.version, reverse=False)
        db_info_list.sort(key=lambda db_info: db_info.region, reverse=False)
        db_info_list.sort(key=lambda db_info: db_info.database_name[:6], reverse=False)

    @staticmethod
    def split2rdf_pbf_db_list(db_info_list):
        """Split rdf database name and pbf database name
        By HERE,NT,CN_AXF,CN_AUTONAVI for RDF
        UNIDB startswith
        """
        rdf_db_list = filter(lambda db_info: is_rdf_db_name(db_info.database_name), db_info_list)
        pbf_db_list = filter(lambda db_info: is_unidb_db_name(db_info.database_name), db_info_list)
        return rdf_db_list, pbf_db_list

    @staticmethod
    def transform_dic_list2db_info_list(db_info_dic_list):
        """Transform json dic list to db_info list"""
        db_info_list = []
        for db_info_dic in db_info_dic_list:
            db_info = DatabaseStatInfo(hostname="", database_name="", region="", version="", vendor="", size=0l)
            db_info.__dict__ = db_info_dic
            db_info_list.append(db_info)
        return db_info_list


def find_tablespace_stat_info_dict(host, database_name="postgres"):
    """get the disk usage of each tablespace path
        Tips:
            1. be clear that the value "Used" do not means this tablespace`s size.
    :param host:
    :param database_name:
    :return:  {name:TablespaceStatInfo(),}
    """
    if not is_localhost(host=host):
        print_error("Host is not local.")
        sys.exit(-1)

    # 1.get all tablespace and path
    dm = DBModule(host, database_name)
    # {name : (tablespace_location, tablespace_size), ...}
    tablespace_name_path_size_dict = dm.select_all_tablespace_path_size_dict()
    # 3.get the space information
    tablespace_name_stat_info_dict = {}
    for tablespace_name, (tablespace_location, tablespace_size) in tablespace_name_path_size_dict.iteritems():
        tablespace_info = TablespaceStatInfo(hostname=host, tablespace_name=tablespace_name,
                                             tablespace_path=tablespace_location, tablespace_size=tablespace_size)
        if not tablespace_info.set_disk_info():
            return None
        tablespace_name_stat_info_dict[tablespace_name] = tablespace_info
    return tablespace_name_stat_info_dict


def find_database_stat_info_list(host, database_name="postgres"):
    db_model = DBModule(host=host, dbname=database_name)
    all_database_name_size_dic = db_model.select_all_db_size_dic()

    selected_database_name_size_dic = dict([(d_name, size) for d_name, size in all_database_name_size_dic.iteritems()
                                            if filter_database_name(d_name)])
    database_info_list = []
    for database_name, db_size in selected_database_name_size_dic.iteritems():
        db_vendor, db_region, db_version = parse_rdf_unidb_db_name(database_name)
        if not db_region or not db_version or not db_vendor:
            continue
        db_info = DatabaseStatInfo(hostname=host, database_name=database_name, region=db_region,
                                   vendor=db_vendor, version=db_version, size=db_size)
        database_info_list.append(db_info)
    return database_info_list


def create_database(host, database, tablespace_name):
    if not database or not tablespace_name:
        sys.stderr.write("create database or tablespace name should noe be none.\n")
        return None
    db_model = DBModule(host=host)
    return db_model.create_db(database_name=database, tablespace=tablespace_name)
