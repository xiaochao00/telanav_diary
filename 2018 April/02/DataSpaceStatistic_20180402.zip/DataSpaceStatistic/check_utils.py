from DBModule import DBModule
from util.common_utils import filter_database_name, get_unified_database_type

DB_DIFFERENT_RATE = 1.5
DB_INCREMENTAL_SIZE = 200 * 1024 * 1024 * 1024


def find_required_db_size_in_local(host, specified_database_name):
    """Get the db`s required size in this machine. unit:B
    :param host:
    :param specified_database_name:
    :return:
    """
    dm = DBModule(host=host)
    # 1. get all database size dictionary structure
    all_database_name_size_dic = dm.select_all_db_size_dic()
    dm.close()
    # 2. select the same region and same type database name list
    same_db_list = find_same_db_list(all_database_name_size_dic.keys(), specified_database_name)
    # 3.get the same database name size list
    same_db_size_list = [size for name, size in all_database_name_size_dic.iteritems() if name in same_db_list]
    if not same_db_size_list:
        return None
    # 4. sort, make the max size as required size.
    same_db_size_list.sort(reverse=True)
    return same_db_size_list[0]


def find_same_db_list(all_database_name_list, specified_database_name):
    """From specified database name , find the same region database names in history. """
    spe_unique_type = get_unified_database_type(specified_database_name)
    if not spe_unique_type:
        return None
    valid_database_name_list = filter(filter_database_name, all_database_name_list)
    # 1. classify all database name {type_region:database_name,...}
    db_type_region_name_dic = {}
    for dbname in valid_database_name_list:
        db_unique_type = get_unified_database_type(dbname)
        if not db_unique_type:
            continue
        db_type_region_name_dic.setdefault(db_unique_type, []).append(dbname)
    # 2. select need database list
    return db_type_region_name_dic.get(spe_unique_type, [])


def get_min_required_size(required_size):
    """
    min(1.5 * db_size, db_size + 200G)
    :param required_size:
    :return:
    """
    return min(required_size * DB_DIFFERENT_RATE, required_size + DB_INCREMENTAL_SIZE)


if __name__ == "__main__":
    hostname = "hqd-ssdpostgis-05.mypna.com"
