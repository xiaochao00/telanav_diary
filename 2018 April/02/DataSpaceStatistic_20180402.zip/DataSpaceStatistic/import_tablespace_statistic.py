# -*- coding: utf-8 -*-
"""
import database and tablespace information to ES
"""
import optparse
import sys
from datetime import datetime

from elasticsearch_importer import ElasticSearchImporter
from tablespace_util import find_tablespace_stat_info_dict, find_database_stat_info_list

DATABASE_INDEX_NAME = "database_info_index"
DATABASE_INDEX_DOC_TYPE = "database_info_index"

TABLESPACE_INDEX_NAME = "tablespace_info_index"
TABLESPACE_INDEX_DOC_TYPE = "tablespace_info_index"


def transform_info_list2dict_list(info_list):
    info_dict_list = []
    now_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.000+0800")
    for info in info_list:
        info_dict = info.__dict__
        # info_dict["@timestamp"] = now_time
        info_dict_list.append(info_dict)
    return info_dict_list


def import_statistic_result(hostname, es_hostname, es_username, es_password, es_port):
    es_import = ElasticSearchImporter(host=es_hostname, username=es_username, password=es_password, port=es_port)
    # get statistic result
    tablespace_info_list = find_tablespace_stat_info_dict(host=hostname).values()
    database_info_list = find_database_stat_info_list(host=hostname)
    # transform data format
    tablespace_info_dict_list = transform_info_list2dict_list(tablespace_info_list)
    database_info_dict_list = transform_info_list2dict_list(database_info_list)
    # insert
    es_import.insert_data_list(index_name=TABLESPACE_INDEX_NAME, doc_type=TABLESPACE_INDEX_DOC_TYPE,
                               data_list=tablespace_info_dict_list)
    es_import.insert_data_list(index_name=DATABASE_INDEX_NAME, doc_type=DATABASE_INDEX_DOC_TYPE,
                               data_list=database_info_dict_list)
    return True


def main():
    parser = optparse.OptionParser()
    parser.add_option("-H", "--hostname", help="statistic hostname", dest="hostname", default="localhost")
    parser.add_option("-E", "--elasticsearch-hostname", help="elasticsearch hostname", dest="elasticsearch_hostname")
    parser.add_option("-u", "--username", help="username for ElasticSearch", dest="username")
    parser.add_option("-p", "--password", help="password for ElasticSearch", dest="password")
    parser.add_option("-P", "--port", help="port for Elasticsearch", dest="port", default=9200)
    options, args = parser.parse_args()

    # check
    if not options.hostname or not options.elasticsearch_hostname:
        sys.stderr.write("statistic hostname and hostname for elasticsearch should not be none.\n")
        parser.print_help()
        sys.exit(-1)
    if not import_statistic_result(hostname=options.hostname, es_hostname=options.elasticsearch_hostname,
                                   es_username=options.username, es_password=options.password, es_port=options.port):
        sys.exit(-1)


if __name__ == '__main__':
    main()
