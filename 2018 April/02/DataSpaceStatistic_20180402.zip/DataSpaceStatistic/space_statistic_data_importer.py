# -*- coding: utf-8 -*-
"""
space statistic data and importer
"""
import optparse
import os
import sys

from elasticsearch_importer import ElasticSearchImporter
from space_statistic_data import builds_statistic, vendor_data_statistic

stat_data_index_name = "data_stat_index"
stat_data_doc_type = "data_stat_type"


def generate_dist_data_name(data):
    return "_".join([data["category"], data["name"], data["region"], data["version"], data["vendor"]])


def do_importer(host, user, password, port, index_name, doc_type, data_list):
    """Import data"""
    es_importer = ElasticSearchImporter(host=host, password=password, port=port, username=user)
    es_importer.create_index(index_name=index_name)

    insert_data_list = []
    update_data_id_data_dict = {}
    for data in data_list:
        # search
        id_data = es_importer.multi_exact_match_by_body(index_name=index_name, doc_type=doc_type,
                                                        category=data["category"], name=data["name"],
                                                        region=data["region"], version=data["version"],
                                                        vendor=data["vendor"])
        if not id_data:
            # not match: add insert
            insert_data_list.append(data)
        else:
            # matched: add update
            data_id, data_value = id_data
            if data_id in update_data_id_data_dict:
                print data
                print data_id
                print "there is repeat search record:", data["category"], data["name"], data["region"], data[
                    "version"], data["vendor"]
            update_data_id_data_dict[data_id] = data
    # 4. update and insert
    es_importer.update_data_list(index_name=index_name, doc_type=doc_type, id_data_dict=update_data_id_data_dict)
    es_importer.insert_data_list(index_name=index_name, doc_type=doc_type, data_list=insert_data_list)


def do_data_statistic_import(options):
    data_list = []
    if options.raw_data_path:
        data_list.extend(vendor_data_statistic(options.raw_data_path))
    if options.build_data_path:
        data_list.extend(builds_statistic(options.build_data_path))
    # importer
    do_importer(host=options.es_host, index_name=stat_data_index_name, doc_type=stat_data_doc_type,
                data_list=data_list, user=options.es_username, password=options.es_password, port=options.es_port)


def check_parameters(options):
    # check elasticsearch
    if not options.es_host:
        sys.stderr.write("host for ElasticSearch should not none./n")
        return False
    # check raw data path availability if have this path
    if options.raw_data_path and not os.path.exists(options.raw_data_path):
        sys.stderr.write("raw data path[%s] does not exist.\n" % options.raw_data_path)
        return False
    # check build path availability if have this path
    if options.build_data_path and not os.path.exists(options.build_data_path):
        sys.stderr.write("build data path[%s] does not exist.\n" % options.build_data_path)
        return False

    return True


def main():
    parse = optparse.OptionParser()

    parse.add_option("-R", "--raw-data-path", help="raw data path", dest="raw_data_path")
    parse.add_option("-B", "--build-data-path", help="builds data path", dest="build_data_path")

    parse.add_option("-e", "--elasticsearch-hostname", help="elasticsearch hostname", dest="es_host")
    parse.add_option("-u", "--username", help="username for ElasticSearch", dest="es_username")
    parse.add_option("-p", "--password", help="password for ElasticSearch", dest="es_password")
    parse.add_option("-n", "--port-number", help="port for Elasticsearch", dest="es_port", default=9200)

    options, args = parse.parse_args()

    if not check_parameters(options):
        sys.stderr.write("%s\n" % parse.print_help())
        sys.exit(-1)

    do_data_statistic_import(options)


if __name__ == '__main__':
    main()
