import json
import os


class StatisticField(object):
    def __init__(self, region, version, field_type, field_name, field_value):
        self.region = region
        self.version = version
        self.tag_name = field_name
        self.tag_value = field_value
        self.tag_type = field_type


ROOT = os.path.dirname(os.path.abspath(__file__))
SRC_STATISTIC_DIR = os.path.join(ROOT, "data")
DES_STATISTIC_DIR = os.path.join(ROOT, "out")


def transform_statistic_data(src_file_path, des_dir_path, statistic_region=None, statistic_version=None):
    if not os.path.exists(des_dir_path):
        os.mkdir(des_dir_path)
    statistic_type = os.path.basename(src_file_path)
    statistic_region = "NA"
    statistic_version = "17Q2"
    field_dict_list = []
    with open(src_file_path, "r") as f:
        data_dict = json.load(f)
        for key, value in data_dict.iteritems():
            field_dict_list.append(StatisticField(region=statistic_region, version=statistic_version,
                                                  field_type=statistic_type, field_name=key,
                                                  field_value=value).__dict__)
    with open(os.path.join(des_dir_path, statistic_type), "w") as f:
        json.dump(field_dict_list, f, separators=(",", ":"), indent=4)


def statistic_data_import(data_dir):
    import sys
    sys.path.append(os.path.dirname(ROOT))
    from elasticsearch_importer import ElasticSearchImporter
    es_importer = ElasticSearchImporter("localhost")
    statistic_es_index = "pbf_statistic_index"
    statistic_es_doc = "pbf_statistic_doc"
    for filename in os.listdir(data_dir):
        es_importer.json_import(json_file=os.path.join(data_dir, filename), index_name=statistic_es_index,
                                doc_type=statistic_es_doc)


if __name__ == '__main__':
    for statistic_file in os.listdir(SRC_STATISTIC_DIR):
        transform_statistic_data(src_file_path=os.path.join(SRC_STATISTIC_DIR, statistic_file),
                                 des_dir_path=DES_STATISTIC_DIR)
    statistic_data_import(DES_STATISTIC_DIR)
