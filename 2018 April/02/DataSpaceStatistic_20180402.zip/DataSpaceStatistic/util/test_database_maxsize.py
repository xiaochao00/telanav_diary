# -*- coding: utf-8 -*-
"""
compute the max database size of each region

"""

host_list = ["hqd-ssdpostgis-05.mypna.com", "hqd-ssdpostgis-04.mypna.com", "hqd-ssdpostgis-06.mypna.com",
             "shd-dpc6x64ssd-02.china.telenav.com", "10.179.1.110"]
from tablespace_util import find_database_stat_info_list, DatabaseStatInfo
from util.common_utils import parse_rdf_unidb_db_name, pretty_size


def get_all_database_list():
    database_stat_info_list = []
    for host in host_list:
        database_stat_info_list.extend(find_database_stat_info_list(host=host))
    rdf_database_list, unidb_database_list = DatabaseStatInfo.split2rdf_pbf_db_list(database_stat_info_list)
    rdf_region_database_max_size_dict = {}
    for rdf_database_info in rdf_database_list:
        db_vendor, db_region, db_version = parse_rdf_unidb_db_name(rdf_database_name=rdf_database_info.database_name)
        rdf_region_database_max_size_dict.setdefault(db_region, []).append(rdf_database_info.size)
    for region, size_list in rdf_region_database_max_size_dict.iteritems():
        size_list.sort(reverse=True)
        average_size = sum(size_list) / len(size_list)
        print "\t".join(
            [str(region), str(size_list[0]), pretty_size(size_list[0]), str(average_size), pretty_size(average_size)])
    print "Unidb"
    unidb_region_database_max_size_dict = {}
    for unidb_database_info in unidb_database_list:
        db_vendor, db_region, db_version = parse_rdf_unidb_db_name(rdf_database_name=unidb_database_info.database_name)
        unidb_region_database_max_size_dict.setdefault(db_region, []).append(unidb_database_info.size)
    for region, size_list in unidb_region_database_max_size_dict.iteritems():
        size_list.sort(reverse=True)
        average_size = sum(size_list) / len(size_list)
        print "\t".join(
            [str(region), str(size_list[0]), pretty_size(size_list[0]), str(average_size), pretty_size(average_size)])


if __name__ == '__main__':
    get_all_database_list()
