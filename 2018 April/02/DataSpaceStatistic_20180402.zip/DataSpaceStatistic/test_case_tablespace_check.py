# -*- coding: utf-8 -*-
"""
tablespace check test case
"""
import unittest

from space_statistic_database import database_statistic, merge_db_statistic
from tablespace_checker import find_required_database_local_remote


class TablespaceCheckerUnitTest(unittest.TestCase):
    """Test case"""

    def test_database_statistic(self):
        database_statistic("172.16.101.92", "statistic_output/autonavi")

    def test_merge_statistic(self):
        merge_db_statistic("statistic_output/autonavi")

    def test_get_required_rdf_database_size(self):
        find_required_database_local_remote("statistic_output/autonavi", "cn_axf_17Q4")
        pass

    def test_get_required_unidb_database_size(self):
        find_required_database_local_remote("statistic_output/autonavi",
                                            "unidb_cn_axf_17q4_1.0.0.525970_180115_092132-rc")


if __name__ == '__main__':
    suite = unittest.TestSuite()
    tests = [TablespaceCheckerUnitTest("test_database_statistic"),
             TablespaceCheckerUnitTest("test_merge_statistic"),
             TablespaceCheckerUnitTest("test_get_required_rdf_database_size"),
             TablespaceCheckerUnitTest("test_get_required_unidb_database_size")]
    suite.addTests(tests)
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)
