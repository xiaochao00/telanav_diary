# -*- coding: utf-8 -*-
"""

"""
import re

p = ur"\s天\s"
print type(" \s".join([u"天", u"下"]))
pat = re.compile(p)
print pat.findall(u"天下  天  天天")
