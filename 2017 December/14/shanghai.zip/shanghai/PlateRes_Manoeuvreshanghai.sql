SET CLIENT_ENCODING TO UTF8;
SET STANDARD_CONFORMING_STRINGS TO ON;
BEGIN;
CREATE TABLE "plateres_manoeuvreshanghai" (gid serial,
"id" varchar(10),
"group_id" varchar(11),
"energytype" varchar(10),
"seatnum" varchar(3),
"platecolor" varchar(1),
"period_id" varchar(11),
"principle1" varchar(254),
"principle2" varchar(254),
"principle3" varchar(254),
"principle4" varchar(254),
"principle5" varchar(254),
"tail_char" varchar(50),
"out_flag" varchar(10));
ALTER TABLE "plateres_manoeuvreshanghai" ADD PRIMARY KEY (gid);
INSERT INTO "plateres_manoeuvreshanghai" ("id","group_id","energytype","seatnum","platecolor","period_id","principle1","principle2","principle3","principle4","principle5","tail_char","out_flag") VALUES ('1315','S3100000913','1|2|3','0','1','S3100001320','2016年4月15日开始执行每日7时至10时15时至20时,延安高架路(S20以东段);南北高架路(呼玛路至鲁班立交段',');逸仙高架路(全线);沪闵高架路(全线);中环路(全线);华夏高架路(全线);罗山高架路(全线);度假区高架路(中环路','至秀浦路段);内环高架路(除内圈中山北二路入口至锦绣路出口外圈锦绣路入口至黄兴路出口以外的路段);南浦大桥;卢浦大桥;','延安东路隧道禁止悬挂外省市机动车号牌的小客车使用临时行驶车号牌的小客车通行(周六周日国定假日除外)',NULL,'0|1|2|3|4|5|6|7|8|9|字母','1|2');
INSERT INTO "plateres_manoeuvreshanghai" ("id","group_id","energytype","seatnum","platecolor","period_id","principle1","principle2","principle3","principle4","principle5","tail_char","out_flag") VALUES ('1324','S3100000917','1|2|3','0','1','S3100001329','悬挂沪C号牌四轮机动车禁止在中环路(杨高南路立交桥至华夏高架路)华夏高架路度假区高架路(中环路--S2沪芦高速)',NULL,NULL,NULL,NULL,'0|1|2|3|4|5|6|7|8|9|字母','4');
INSERT INTO "plateres_manoeuvreshanghai" ("id","group_id","energytype","seatnum","platecolor","period_id","principle1","principle2","principle3","principle4","principle5","tail_char","out_flag") VALUES ('1326','S3100000273','1|2|3','0','1','S3100001331','悬挂沪C号牌四轮机动车禁止以下区域内的道路上通行:沿外环隧道(含两侧地面泰和路)-S20外环高速公路(外环隧道以西至','杨高南路立交桥,含两侧地面泰和路泰和西路至顾太路)-杨高南路-龙阳路立交-龙阳路-龙东大道-金桥路-金桥立交桥-杨高中','路-杨高北路-杨高北一路以及长江边线黄浦江边线所围合的区域(含上述道路)',NULL,NULL,'0|1|2|3|4|5|6|7|8|9|字母','4');
COMMIT;
ANALYZE "plateres_manoeuvreshanghai";
