SET CLIENT_ENCODING TO UTF8;
SET STANDARD_CONFORMING_STRINGS TO ON;
BEGIN;
CREATE TABLE "plateres_periodshanghai" (gid serial,
"period_id" varchar(11),
"start_date" varchar(254),
"end_date" varchar(254),
"datetype" varchar(50),
"time" varchar(254),
"spec_flag" varchar(15));
ALTER TABLE "plateres_periodshanghai" ADD PRIMARY KEY (gid);
INSERT INTO "plateres_periodshanghai" ("period_id","start_date","end_date","datetype","time","spec_flag") VALUES ('S3100001320','20160415',NULL,'1','(h7m0)(h10m0) + (h15m0)(h20m0)',NULL);
INSERT INTO "plateres_periodshanghai" ("period_id","start_date","end_date","datetype","time","spec_flag") VALUES ('S3100001329',NULL,NULL,'1',NULL,NULL);
INSERT INTO "plateres_periodshanghai" ("period_id","start_date","end_date","datetype","time","spec_flag") VALUES ('S3100001331',NULL,NULL,'1',NULL,NULL);
COMMIT;
ANALYZE "plateres_periodshanghai";
