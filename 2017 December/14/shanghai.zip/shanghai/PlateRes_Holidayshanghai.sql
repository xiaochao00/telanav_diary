SET CLIENT_ENCODING TO UTF8;
SET STANDARD_CONFORMING_STRINGS TO ON;
BEGIN;
CREATE TABLE "plateres_holidayshanghai" (gid serial,
"id" varchar(4),
"holiday" varchar(254),
"spec_flag" varchar(15));
ALTER TABLE "plateres_holidayshanghai" ADD PRIMARY KEY (gid);
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('1','20170402','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('10','20171001','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('11','20171002','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('12','20171003','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('13','20171004','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('14','20171005','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('15','20171006','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('16','20171007','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('17','20171008','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('2','20170403','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('3','20170404','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('4','20170429','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('5','20170430','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('6','20170501','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('7','20170528','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('8','20170529','3');
INSERT INTO "plateres_holidayshanghai" ("id","holiday","spec_flag") VALUES ('9','20170530','3');
COMMIT;
ANALYZE "plateres_holidayshanghai";
