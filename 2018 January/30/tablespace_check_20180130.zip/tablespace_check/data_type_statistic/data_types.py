class BaseData(object):
    def __init__(self, category, name, region, vendor, version, size, size_pretty):
        self.category = category
        self.name = name
        self.region = region
        self.vendor = vendor
        self.version = version
        self.size = size
        self.size_pretty = size_pretty


class BuildData(BaseData):
    category = "build_data"

    def __init__(self, name, region, vendor, version, size, size_pretty,
                 project, build_type, data_type, data_path, create_time, release_type):
        BaseData.__init__(self, category=BuildData.category, name=name, region=region, vendor=vendor, version=version,
                          size=size, size_pretty=size_pretty)
        self.project = project
        self.build_type = build_type
        self.daa_type = data_type
        self.data_path = data_path
        self.create_time = create_time
        self.release_type = release_type


class RawData(BaseData):
    category = "raw_data"

    def __init__(self, name, region, vendor, version, size, size_pretty, data_path):
        BaseData.__init__(self, category=RawData.category, name=name, region=region, vendor=vendor, version=version,
                          size=size, size_pretty=size_pretty)
        self.data_path = data_path


class RdfDB(BaseData):
    category = "rdfdb"

    def __init__(self, name, region, vendor, version, size, size_pretty):
        BaseData.__init__(self, category=RdfDB.category, name=name, region=region, vendor=vendor, version=version,
                          size=size, size_pretty=size_pretty)


class Unidb(BaseData):
    category = "unidb"

    def __init__(self, name, region, vendor, version, size, size_pretty, create_time, release_type):
        BaseData.__init__(self, category=Unidb.category, name=name, region=region, vendor=vendor, version=version,
                          size=size, size_pretty=size_pretty)
        self.create_time = create_time
        self.release_type = release_type
