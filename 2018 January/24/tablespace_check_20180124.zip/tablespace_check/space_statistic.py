# encoding=utf8
import os
import sys
import json
import glob
from collections import namedtuple
from host_config.config_reader import read_db_config, Options
from DBModule import DBModule
from db_info_collections import DBInfo, TablespaceInfo
from util.common_utils import filter_database_name, parse_rdf_unidb_db_name, print_error, parse_vendor_raw_data_name
from util.common_utils import filter_raw_raw_data_name, pretty_size, parse_pbf_data_data_name, filter_pbf_data_data_name
from util.common_utils import dic_list2json, load_json2list
from tablespace_util import find_tablespace_name_path_dic, find_tablespace_disk_space_info_dic

Disk_Usage = namedtuple("usage", "total used free percent")
ROOT_PATH = os.path.dirname(os.path.abspath(__file__))
OUTPUT_STATISTIC_DIR = os.path.join(ROOT_PATH, "output_statistic")

OUTPUT_STATISTIC_DB_DIR = "db"
OUTPUT_STATISTIC_DATA_DIR = "data"
OUTPUT_STATISTIC_RAW_DB_DIR = os.path.join(OUTPUT_STATISTIC_DB_DIR, "raw_db")
OUTPUT_STATISTIC_RAW_DB_FILENAME = "raw_db_statistic.json"
OUTPUT_STATISTIC_UNIDB_DB_DIR = os.path.join(OUTPUT_STATISTIC_DB_DIR, "unidb_db")
OUTPUT_STATISTIC_UNIDB_DB_FILENAME = "unidb_db_statistic.json"

OUTPUT_STATISTIC_RAW_DATA_DIR = os.path.join(OUTPUT_STATISTIC_DATA_DIR, "raw_data")
OUTPUT_STATISTIC_PBF_DATA_DIR = os.path.join(OUTPUT_STATISTIC_DATA_DIR, "pbf_data")


class DBStatisticUtils(object):
    @staticmethod
    def set_db_options(host="localhost", username="postgres", password="postgres", port="5432", database_name="postgres"):
        db_options = Options()
        setattr(db_options, "host", host)
        setattr(db_options, "username", username)
        setattr(db_options, "password", password)
        setattr(db_options, "port", port)
        return db_options

    @staticmethod
    def get_all_database_info(host_option):
        hostname = host_option.host
        username = host_option.username
        password = host_option.password
        port = host_option.port

        db_model = DBModule(host=hostname, username=username, password=password, port=port)
        all_database_name_size_dic = db_model.select_all_db_size_dic()

        selected_database_name_size_dic = dict([(d_name, size) for d_name, size in all_database_name_size_dic.iteritems()
                                                if filter_database_name(d_name)])

        database_info_list = []
        for database_name, db_size in selected_database_name_size_dic.iteritems():
            db_type, db_region, db_version = parse_rdf_unidb_db_name(database_name)
            if not db_region or not db_version:
                continue
            db_info = DBInfo(database_name, db_region, db_version, db_size)
            database_info_list.append(db_info)

        db_model.close()
        return database_info_list

    @staticmethod
    def get_all_host_database_info():
        all_host_options = read_db_config()
        database_info_list = []
        for host_option in all_host_options:
            if host_option.host == "10.179.1.110":
                print_error("KOR database cannot access. have pass")
                continue

            host_db_info_list = DBStatisticUtils.get_all_database_info(host_option)
            DBInfo.sort_list(host_db_info_list)
            database_info_list += host_db_info_list
        DBInfo.sort_list(database_info_list)
        return database_info_list

    @staticmethod
    def get_tablespace_usage_info(host_option):
        hostname = host_option.host
        username = host_option.username
        password = host_option.password
        port = host_option.port

        db_model = DBModule(host=hostname, username=username, password=password, port=port)
        tablespace_name_location_dic = find_tablespace_name_path_dic(hostname)
        # {name:disk_space_info,...}
        tablespace_size_info_dic = find_tablespace_disk_space_info_dic(hostname)
        tablespace_name_size_dic = db_model.select_tablespace_size_info_dic()
        # collection below info dic, [TablespaceInfo:,...]
        tablespace_info_list = []
        for name, location in tablespace_name_location_dic.iteritems():
            info_dic = tablespace_size_info_dic.get(name)
            db_used_size = tablespace_name_size_dic.get(name)
            tablespace_info = TablespaceInfo.transform_dic_to_info(name, location, info_dic, db_used_size)
            tablespace_info_list.append(tablespace_info)

        return tablespace_info_list


class DiskSpaceUtil(object):
    @staticmethod
    def get_dir_list_size(dir_path_list):
        import multiprocessing
        pool = multiprocessing.Pool(processes=8)
        result_list = []
        for dir_path in dir_path_list:
            result_list.append(pool.apply_async(dir_size_proxy, (DiskSpaceUtil, dir_path)))
        pool.close()
        pool.join()

        size_list = [result.get() for result in result_list]
        return size_list

    @staticmethod
    def get_dir_size(dir_path):
        """unit byte"""
        size = 0l
        if isinstance(dir_path, unicode):
            dir_path = dir_path.encode("utf8")
        for root, dirs, file_names in os.walk(dir_path):
            size += sum([os.path.getsize(os.path.join(root, file_name)) for file_name in file_names])
        return size

    @staticmethod
    def get_dir_usage(dir_path):
        """The usage of this dir_path`s mount path"""
        """Return disk usage associated with path."""
        st = os.statvfs(dir_path)
        free = (st.f_bavail * st.f_frsize)
        total = (st.f_blocks * st.f_frsize)
        used = (st.f_blocks - st.f_bfree) * st.f_frsize
        try:
            percent = ret = (float(used) / total) * 100
        except ZeroDivisionError:
            percent = 0

        return Disk_Usage(total, used, free, round(percent, 1))


# match the config components file, field name
ConfigComponents = namedtuple("component", "name path regions")


class Component(object):
    def __init__(self, name, path):
        self.name = name
        self.path = path
        self.size = 0
        self.component_pretty_size = ""

    def statistic(self):
        self.size = DiskSpaceUtil.get_dir_size(self.path)
        self.component_pretty_size = pretty_size(self.size)
        print self.name, self.size, self.component_pretty_size

    def __str__(self):
        return str(self.__dict__)


class VendorData(object):
    conf_component_list = []

    @staticmethod
    def get_vendor_data_list(base_dir):
        vendor_list = []

        all_data_name = os.listdir(base_dir)
        selected_data_name = filter(filter_raw_raw_data_name, all_data_name)
        for data_name in selected_data_name:
            data_path = os.path.join(base_dir, data_name)
            vendor, region, version = parse_vendor_raw_data_name(data_name)
            vendor_data = VendorData(data_name, region, version, data_path)
            vendor_list.append(vendor_data)

        vendor_list.sort(key=lambda d: d.name)
        return vendor_list

    @staticmethod
    def load_components_conf():
        if VendorData.conf_component_list:
            return VendorData.conf_component_list

        components_conf_file_path = os.path.join(ROOT_PATH, "vendor_data_components.json")
        with open(components_conf_file_path, "r") as f:
            component_json_list = json.load(f)
            conf_component_list = [ConfigComponents(c["name"], c["path"], c["regions"].split("|"))
                                   for c in component_json_list]
            if not conf_component_list:
                print_error("components from config should not empty")
                sys.exit(-1)

            return conf_component_list

    def __init__(self, name, region, version, data_path):
        self.name = name
        self.region = region
        self.version = version
        self.data_path = data_path
        self.component_list = []

        self.size = 0
        self.vendor_pretty_size = ""

        self._init_check()
        self.component_list = self._init_component_list()

    def _init_check(self):
        if not os.path.exists(self.data_path):
            sys.stderr.write("vendor raw data path does not exist.[%s]\n" % self.data_path)
            sys.exit(-1)

    def _init_component_list(self):
        VendorData.conf_component_list = VendorData.load_components_conf()
        component_list = []
        # load and check component
        for conf_component in self.conf_component_list:
            if self.region not in conf_component.regions:
                continue
            component_path = os.path.join(self.data_path, conf_component.path)
            if not os.path.exists(component_path):
                continue
            component = Component(conf_component.name, component_path)
            component_list.append(component)
        return component_list

    def statistic_components(self):
        component_list = self.component_list
        # statistic
        component_list_dic = []
        for component in component_list:
            component.statistic()
            component_size = component.size
            self.size += component_size
            component_list_dic.append(component.__dict__)
        # transform
        self.component_list = component_list_dic
        self.vendor_pretty_size = pretty_size(self.size)


def dir_size_proxy(cls_instance, i):
    return cls_instance.get_dir_size(i)


class PBFData(object):
    def __init__(self, name, data_time, data_type, data_path):
        self.name = name
        self.data_time = data_time
        self.data_type = data_type
        self.data_path = data_path
        self.data_size = 0
        self.data_pretty_size = ""

        self._init_check()

    def _init_check(self):
        if not os.path.exists(self.data_path):
            sys.stderr.write("PBF data path is not exist.[%s]\n" % self.data_path)
            sys.exit(-1)

    def statistic(self):
        self.data_size = DiskSpaceUtil.get_dir_size(self.data_path)
        self.data_pretty_size = pretty_size(self.data_size)
        print self.name, self.data_size, self.data_pretty_size

    def set_size(self, size):
        self.data_size = size
        self.data_pretty_size = pretty_size(size)

    @staticmethod
    def statistic_multiple_process(data_list):
        import multiprocessing
        pool = multiprocessing.Pool(processes=8)
        result_list = []
        for data in data_list:
            result_list.append(pool.apply_async(dir_size_proxy, args=(DiskSpaceUtil, data.data_path,)))
        pool.close()
        pool.join()
        for i in range(len(data_list)):
            data_size = result_list[i].get()
            data_list[i].data_size = data_size
            data_list[i].data_pretty_size = pretty_size(data_size)
            print data_list[i].name, data_list[i].data_pretty_size


class PBF(object):
    @staticmethod
    def get_pbf_list(base_dir):
        if not os.path.exists(base_dir):
            sys.stderr.write("PBF base dir is not exist.[%s]\n" % base_dir)
            sys.exit(-1)

        all_pbf_name = os.listdir(base_dir)
        selected_pbf_name = filter(filter_raw_raw_data_name, all_pbf_name)

        pbf_list = []
        for pbf_name in selected_pbf_name:
            pbf_path = os.path.join(base_dir, pbf_name)
            vendor, region, version = parse_vendor_raw_data_name(pbf_name)
            pbf = PBF(pbf_name, region, version, pbf_path)
            pbf_list.append(pbf)

        pbf_list.sort(key=lambda d: d.name)
        return pbf_list

    def __init__(self, name, region, version, data_path):
        self.name = name
        self.region = region
        self.version = version
        self.data_path = data_path

        self.size = 0
        self.pbf_pretty_size = ""
        self.data_list = []

        self._init_check()
        self.data_list = self._init_data_list()

    def _init_check(self):
        if not os.path.exists(self.data_path):
            sys.stderr.write("PBF data path is not exist.[%s]\n" % self.data_path)
            sys.exit(-1)

    def _init_data_list(self):
        """get all PBF data list"""
        data_list = []
        data_name_list = os.listdir(self.data_path)
        # TODO filter pbf data version name If need
        data_name_list = filter(filter_pbf_data_data_name, data_name_list)
        # Initialization pbf data list
        for data_name in data_name_list:
            data_time, data_type = parse_pbf_data_data_name(data_name)
            data_path = os.path.join(self.data_path, data_name)
            pbf_data = PBFData(name=data_name, data_time=data_time, data_type=data_type, data_path=data_path)
            data_list.append(pbf_data)

        data_list.sort(key=lambda d: d.data_time)
        data_list.sort(key=lambda d: d.data_type)
        return data_list

    def _choose_latest_pbf_data(self):
        # TODO from all version pbf data, choose one specified version
        # this step do in parser, choose the max size of each type(TEST,RC,)
        pass

    def statistic_data(self):
        """Statistic all pbf data size"""

        data_dic_list = []
        # PBFData.statistic_multiple_process(self.data_list)
        data_path_list = [data.data_path for data in self.data_list]
        data_size_list = DiskSpaceUtil.get_dir_list_size(data_path_list)

        for i in range(len(self.data_list)):
            data_size = data_size_list[i]
            pbf_data = self.data_list[i]

            pbf_data.set_size(data_size)
            self.size += data_size
            data_dic_list.append(pbf_data.__dict__)

            print pbf_data.name, pbf_data.data_pretty_size

        self.pbf_pretty_size = pretty_size(self.size)
        self.data_list = data_dic_list


def statistic_vendor_data(base_path, result_file):
    vendor_data_list = VendorData.get_vendor_data_list(base_dir=base_path)
    # statistic
    vendor_data_dic_list = []
    for vendor_data in vendor_data_list:
        vendor_data.statistic_components()
        vendor_data_dic_list.append(vendor_data.__dict__)

    dic_list2json(dic_list=vendor_data_dic_list, dump_json_file_path=result_file)


def statistic_pbf(base_path, result_file):
    total_size = 0
    pbf_list = PBF.get_pbf_list(base_dir=base_path)
    pbf_dic_list = []
    for pbf in pbf_list:
        pbf.statistic_data()
        pbf_dic_list.append(pbf.__dict__)
        total_size += pbf.size

    dic_list2json(dic_list=pbf_dic_list, dump_json_file_path=result_file)
    return total_size


def statistic_pbf_list(base_path_list, result_file):
    pbf_dic_list = []
    for base_path in base_path_list:
        pbf_list = PBF.get_pbf_list(base_dir=base_path)
        for pbf in pbf_list:
            pbf.statistic_data()
            pbf_dic_list.append(pbf.__dict__)
    dic_list2json(dic_list=pbf_dic_list, dump_json_file_path=result_file)


def statistic_raw_db(result_file_path):
    db_options = DBStatisticUtils.set_db_options()
    db_info_list = DBStatisticUtils.get_all_database_info(db_options)
    DBInfo.sort_list(db_info_list)

    db_info_dic_list = []
    for db_info in db_info_list:
        db_info_dic_list.append(db_info.__dict__)

    dic_list2json(db_info_dic_list, result_file_path)


def merge_db_statistic(out_dir, data_type):
    db_statistic_file_list = glob.glob(os.path.join(out_dir, OUTPUT_STATISTIC_DB_DIR.format(data_type=data_type),
                                                    DB_STATISTIC_FILENAME_PREFIX + "*.json"))
    db_info_dic_list = []
    # merge all database info list
    for db_statistic_file in db_statistic_file_list:
        db_info_dic_list += load_json2list(db_statistic_file)
    # transform json to DBInfo object
    db_info_list = DBInfo.transform_dic_list2db_info_list(db_info_dic_list=db_info_dic_list)
    DBInfo.sort_list(db_info_list)
    # split to rdf and pbf
    rdf_db_info_list, unidb_db_info_list = DBInfo.split2rdf_pbf_db_list(db_info_list)
    # save rdf json and pbf json file
    rdf_db_info_result_file_path = os.path.join(out_dir, OUTPUT_STATISTIC_RAW_DB_DIR, OUTPUT_STATISTIC_RAW_DB_FILENAME)
    rdf_db_info_dic_list = [db_info.__dict__ for db_info in rdf_db_info_list]
    dic_list2json(rdf_db_info_dic_list, rdf_db_info_result_file_path)
    # save unidb
    unidb_db_info_result_file_path = os.path.join(out_dir, OUTPUT_STATISTIC_UNIDB_DB_DIR, OUTPUT_STATISTIC_UNIDB_DB_FILENAME)

    unidb_db_info_dic_list = [db_info.__dict__ for db_info in unidb_db_info_list]
    dic_list2json(unidb_db_info_dic_list, unidb_db_info_result_file_path)


RAW_DATA_STATISTIC_FILE_NAME_PREFIX = "raw_data_statistic"
RAW_DATA_STATISTIC_FILE_NAME = RAW_DATA_STATISTIC_FILE_NAME_PREFIX + "_{host}.json"
PBF_DATA_STATISTIC_FILE_NAME_PREFIX = "pbf_statistic"
PBF_DATA_STATISTIC_FILE_NAME = PBF_DATA_STATISTIC_FILE_NAME_PREFIX + "_{host}.json"

DB_STATISTIC_FILENAME_PREFIX = "db_statistic"
DB_STATISTIC_FILENAME = DB_STATISTIC_FILENAME_PREFIX + "_{host}.json"


def test_region():
    region = "CN_Level0"
    VendorData("CN_Level0_17Q1", "CN_Level0", "17Q1", "")


def test_raw_data_statistic(base_path, out_dir, data_type):
    "D:\\test_temp\\test_rdf_data "
    result_file = os.path.join(out_dir, OUTPUT_STATISTIC_RAW_DATA_DIR, RAW_DATA_STATISTIC_FILE_NAME.format(host=data_type))
    statistic_vendor_data(base_path, result_file)


def test_pbf_statistic(base_path, out_dir, data_type):
    result_file_path = os.path.join(out_dir, OUTPUT_STATISTIC_PBF_DATA_DIR, PBF_DATA_STATISTIC_FILE_NAME.format(host=data_type))
    return statistic_pbf(base_path=base_path, result_file=result_file_path.format(data_type=data_type))


def test_pbf_list_statistic(base_path_list, out_dir, data_type):
    result_file_path = os.path.join(out_dir, OUTPUT_STATISTIC_PBF_DATA_DIR, PBF_DATA_STATISTIC_FILE_NAME.format(host=data_type))
    statistic_pbf_list(base_path_list, result_file_path)


def test_raw_db_statistic(host_name, out_dir, data_type):
    result_file_path = os.path.join(out_dir, OUTPUT_STATISTIC_DB_DIR.format(data_type=data_type),
                                    DB_STATISTIC_FILENAME.format(host=host_name))
    statistic_raw_db(result_file_path)


def main():
    import optparse
    parse = optparse.OptionParser()

    parse.add_option("-R", "--raw-data-path", help="raw data path", dest="raw_data_path")
    parse.add_option("-P", "--pbf-data-path", help="pbf data path", dest="pbf_data_path")
    parse.add_option("-D", "--database-host", help="statistic database host name", dest="database_host")
    parse.add_option("-M", "--merge-db", help="is need merge db statistic", dest="merge_db",
                     action="store_true", default=False)

    parse.add_option("-O", "--output-path", help="statistic output path", dest="output_path", default=OUTPUT_STATISTIC_DIR)
    parse.add_option("-T", "--statistic-type", help="like autonavi,kor,global_cn,global_others", dest="statistic_type")

    options, args = parse.parse_args()
    # check
    if not options.statistic_type:
        sys.stderr.write("%s\n" % parse.print_help())
        sys.exit(-1)

    raw_data_path = options.raw_data_path
    pbf_data_path = options.pbf_data_path
    output_path = options.output_path
    if raw_data_path and not os.path.exists(raw_data_path):
        sys.stderr.write("raw data path[%s] does not exist.\n" % raw_data_path)
        sys.exit(-1)
    if pbf_data_path and not os.path.exists(pbf_data_path):
        sys.stderr.write("pbf data path[%s] does not exist.\n" % pbf_data_path)
        sys.exit(-1)

    if not os.path.exists(output_path):
        sys.stderr.write("output path[%s] does not exist.\n" % output_path)
        sys.exit(-1)
    #
    statistic_type = options.statistic_type
    db_host = options.database_host
    output_path = os.path.join(output_path, statistic_type)
    # do
    if raw_data_path:
        test_raw_data_statistic(base_path=raw_data_path, out_dir=output_path, data_type=statistic_type)
    if pbf_data_path:
        test_pbf_list_statistic(base_path_list=pbf_data_path.splie("|"), out_dir=output_path,
                                data_type=statistic_type)
    if options.merge_db:
        merge_db_statistic(output_path, statistic_type)
    elif db_host:
        test_raw_db_statistic(host_name=db_host, out_dir=output_path, data_type=statistic_type)


if __name__ == '__main__':
    main()
