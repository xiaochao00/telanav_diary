import os
from space_statistic import test_pbf_statistic, OUTPUT_STATISTIC_DIR, pretty_size


def statistic_project(project_name, project_path):
    size = test_pbf_statistic(project_path, os.path.join(OUTPUT_STATISTIC_DIR, project_name), project_name)
    return size


def statistic_ec_latest_build_by_mult(base_path):
    project_name_list = os.listdir(base_path)
    project_path_list = [os.path.join(base_path, project_name) for project_name in project_name_list]
    import multiprocessing
    pool = multiprocessing.Pool(processes=16)
    result_list = []
    for project_name, project_path in zip(project_name_list, project_path_list):
        result_list.append(pool.apply_async(statistic_project, (project_name, project_path)))
    pool.close()
    pool.join()

    for i in range(len(result_list)):
        size = result_list[i].get()
        project_name = project_name_list[i]
        project_path = project_path_list[i]
        print project_name, project_path, pretty_size(size)


def statistic_ec_latest_build(base_path):
    project_name_list = os.listdir(base_path)
    project_path_list = [os.path.join(base_path, project_name) for project_name in project_name_list]
    for project_name, project_path in zip(project_name_list, project_path_list):
        size = statistic_project(project_name, project_path)
        print project_name, project_path, pretty_size(size)


if __name__ == '__main__':
    ec_latest_build_path = "/var/www/html/ec_latest_builds"
    statistic_ec_latest_build(ec_latest_build_path)
