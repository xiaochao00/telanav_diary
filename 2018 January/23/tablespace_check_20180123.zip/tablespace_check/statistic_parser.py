import os
import sys
import json
import glob
import shutil

ROOT_PATH = os.path.dirname(os.path.abspath(__file__))
raw_statistic_json_file_base_dir = "data/raw_data"
pbf_statistic_json_file_base_dir = "data/pbf_data"
rdf_db_statistic_json_file_base_dir = "db/raw_db"
unidb_db_statistic_json_file_base_dir = "db/unidb_db"


class JSChart(object):
    def __init__(self, chart_series_list, chart_legend_list, chart_x_list, table_title, **kwargs):
        self.chart_series_list = chart_series_list
        self.chart_legend_list = chart_legend_list
        self.chart_x_list = chart_x_list

        self.table_title = table_title
        self.kwargs = kwargs

    def format2dic(self):
        series_dic = [chart_series.format2dict() for chart_series in self.chart_series_list]
        x_dic = [chart_x.data for chart_x in self.chart_x_list]
        legend_dic = [chart_legend.data for chart_legend in self.chart_legend_list]
        data_dic = {"regions_series": series_dic, "regions_x": x_dic, "regions_legend": legend_dic,
                    "table_title": self.table_title}

        if self.kwargs:
            data_dic = dict(self.kwargs, **data_dic)
        return data_dic


class ChartSeries(object):
    def __init__(self, name, chart_type, data, stack="stack"):
        self.name = name
        self.type = chart_type
        self.data = data
        self.stack = stack

    def format2dict(self):
        data_dic = {"name": self.name, "type": self.type, "data": self.data}
        if self.stack:
            data_dic["stack"] = self.stack
        return data_dic


class ChartLegend(object):
    def __init__(self, data):
        self.data = data


class ChartXAxis(object):
    def __init__(self, data):
        self.data = data


class ChartData(object):
    def __init__(self, x_name, x_type, value):
        self.x_name = x_name
        self.x_type = x_type
        self.value = value

    @staticmethod
    def transform2chart(chart_data_list, chart_type, title, stack="stack", **kwargs):
        """To JSChart"""
        # There are missing value in x_type for x_name column.
        x_type_name_size_dic = {}
        x_name_list = []
        for chart_data in chart_data_list:
            x_name = chart_data.x_name
            x_type = chart_data.x_type
            value = chart_data.value
            x_name_list.append(x_name)
            x_type_name_size_dic.setdefault(x_type, {}).setdefault(x_name, value)
        x_name_list = list(set(x_name_list))
        x_name_list.sort()
        # add missing value
        # chart_series
        chart_series_list = []
        for x_type, x_name_value_dic in x_type_name_size_dic.iteritems():
            series_value_list = []
            type_name_list = x_name_value_dic.keys()
            for name in x_name_list:
                if name in type_name_list:
                    series_value_list.append(x_name_value_dic[name])
                else:
                    series_value_list.append(0)
            chart_series_list.append(ChartSeries(x_type, chart_type, series_value_list, stack))
        # x axis
        chart_x_list = [ChartXAxis(name) for name in x_name_list]
        #  legend
        chart_legend_list = [ChartLegend(x_type) for x_type in x_type_name_size_dic]

        return JSChart(chart_series_list=chart_series_list, chart_legend_list=chart_legend_list,
                       chart_x_list=chart_x_list,
                       table_title=title, kwargs=kwargs)


class DataStat(object):
    def __init__(self, data_name, data_type, data_size):
        self.data_name = data_name
        self.data_type = data_type
        self.data_size = data_size

    @staticmethod
    def _list2chart_data_list(data_list):
        """Transform pbf list to chart data list[{x_name: , x_type: , value:},...]"""
        chart_data_list = []
        for data in data_list:
            x_name = data.data_name
            x_type = data.data_type
            size = data.data_size
            chart_data_list.append(ChartData(x_name=x_name, x_type=x_type, value=size))
        return chart_data_list

    @staticmethod
    def choose_max_size_pbf_data(pbf_data_list):
        """Choose max size pbf data of each type"""
        pbf_data_list.sort(key=lambda d: d.data_size)
        type_pbf_data_dic = {}
        for pbf_data in pbf_data_list:
            data_type = pbf_data.data_type
            type_pbf_data_dic[data_type] = pbf_data
        return type_pbf_data_dic.values()

        # @staticmethod
        # def data2chart_dic(data_list, chart_type, table_name, stack="stack", **kwargs):
        #     chart_data_list = DataStat._list2chart_data_list(data_list)
        #     js_chart = ChartData.transform2chart(chart_data_list, chart_type, table_name, stack, **kwargs)
        #     return js_chart.format2dic()


class RawDataAllRegionStat(DataStat):
    chart_type = "bar"
    table_name = "Raw Data Space Statistic"
    jump_rule = "series_name"

    def __init__(self, region, version, size):
        DataStat.__init__(self, data_name=version, data_type=region, data_size=size)

    @staticmethod
    def data2chart_dic(raw_data_list):
        chart_data_list = DataStat._list2chart_data_list(raw_data_list)
        js_chart = ChartData.transform2chart(chart_data_list, RawDataAllRegionStat.chart_type,
                                             RawDataAllRegionStat.table_name, jump_rule=RawDataAllRegionStat.jump_rule)
        return js_chart.format2dic()


class PBFAllRegionStat(DataStat):
    chart_type = "bar"
    table_name = "PBF All Region Space Statistic"
    jump_rule = "series_name"

    def __init__(self, region, version, size):
        DataStat.__init__(self, data_name=version, data_type=region, data_size=size)

    @staticmethod
    def data2chart_dic(pbf_list):
        chart_data_list = DataStat._list2chart_data_list(pbf_list)
        js_chart = ChartData.transform2chart(chart_data_list, PBFAllRegionStat.chart_type, PBFAllRegionStat.table_name,
                                             jump_rule=PBFAllRegionStat.jump_rule)
        return js_chart.format2dic()


class RawDataRegionStat(DataStat):
    chart_type = "line"
    table_name = "Raw Data Region:{region} Space Statistic"
    jump_rule = "name"

    def __init__(self, version, data_type, size):
        DataStat.__init__(self, data_name=version, data_size=size, data_type=data_type)

    @staticmethod
    def data2chart_dict(raw_data_data_list, region):
        chart_data_list = DataStat._list2chart_data_list(raw_data_data_list)

        js_chart = ChartData.transform2chart(chart_data_list, RawDataRegionStat.chart_type,
                                             RawDataRegionStat.table_name.format(region=region), stack="",
                                             jump_rule=RawDataRegionStat.jump_rule)
        return js_chart.format2dic()


class PBFRegionStat(DataStat):
    chart_type = "line"
    table_name = "PBF Region:{region} Space Statistic"
    jump_rule = "name"

    def __init__(self, version, data_type, size):
        DataStat.__init__(self, data_name=version, data_type=data_type, data_size=size)

    @staticmethod
    def data2chart_dic(pbf_region_data_list, region):
        chart_data_list = DataStat._list2chart_data_list(pbf_region_data_list)

        js_chart = ChartData.transform2chart(chart_data_list, PBFRegionStat.chart_type,
                                             PBFRegionStat.table_name.format(region=region), stack="",
                                             jump_rule=PBFRegionStat.jump_rule)
        return js_chart.format2dic()


class PBFSubDataStat(DataStat):
    chart_type = "bar"
    table_name = "PBF Data[{data_name}] Detail Space Statistic"

    def __init__(self, data_type, data_time, size):
        DataStat.__init__(self, data_name=data_time, data_type=data_type, data_size=size)

    @staticmethod
    def data2chart_dic(pbf_data_list, data_name):
        chart_data_list = DataStat._list2chart_data_list(pbf_data_list)
        js_chart = ChartData.transform2chart(chart_data_list, PBFSubDataStat.chart_type,
                                             PBFSubDataStat.table_name.format(data_name=data_name))
        return js_chart.format2dic()


class RawDataComponentStat(DataStat):
    chart_type = "bar"
    table_name = "{data_name} Components Statistic"

    def __init__(self, component_name, data_type, size):
        DataStat.__init__(self, data_name=data_type, data_type=component_name, data_size=size)

    @staticmethod
    def data2chart_dict(data_list, data_name):
        chart_data_list = DataStat._list2chart_data_list(data_list)
        js_chart = ChartData.transform2chart(chart_data_list, RawDataComponentStat.chart_type,
                                             RawDataComponentStat.table_name.format(data_name=data_name), stack="")
        return js_chart.format2dic()


class DBStat(DataStat):
    chart_type = "bar"
    rdf_db_table_name = "RDF Database Statistic"
    unidb_db_table_name = "Unidb Database Statistic"
    jump_rule = "series_name"

    def __init__(self, region, version, size):
        DataStat.__init__(self, data_name=version, data_type=region, data_size=size)

    @staticmethod
    def data2chart_dic(db_info_list, table_name):
        chart_data_list = DataStat._list2chart_data_list(db_info_list)
        js_chart = ChartData.transform2chart(chart_data_list, DBStat.chart_type, table_name,
                                             jump_rule=RawDataAllRegionStat.jump_rule)
        return js_chart.format2dic()


class RDFDBSingleStat(DataStat):
    chart_type = "line"
    table_name = "Region:{region} RDF Database Statistic"

    def __init__(self, version, region, size):
        DataStat.__init__(self, data_name=version, data_type=region, data_size=size)

    @staticmethod
    def data2chart_dic(db_info_list, region_name):
        chart_data_list = DataStat._list2chart_data_list(db_info_list)
        js_chart = ChartData.transform2chart(chart_data_list, RDFDBSingleStat.chart_type,
                                             RDFDBSingleStat.table_name.format(region=region_name))
        return js_chart.format2dic()


class UnidbDBSingleStat(DataStat):
    chart_type = "line"
    table_name = "Region:{region} Unidb Database Statistic"

    def __init__(self, size, pbf_type, pbf_time):
        DataStat.__init__(self, data_name=pbf_time, data_type=pbf_type, data_size=size)

    @staticmethod
    def data2chart_dic(db_info_list, region_name):
        chart_data_list = DataStat._list2chart_data_list(db_info_list)
        js_chart = ChartData.transform2chart(chart_data_list, UnidbDBSingleStat.chart_type,
                                             UnidbDBSingleStat.table_name.format(region=region_name))
        return js_chart.format2dic()


class StatisticJsonReader(object):
    @staticmethod
    def read_raw_statistic_file(statistic_file_path):
        """
        read raw data statistic file, get
        1. []
            all region`s all quarter`s data size
        2. {region:[],...}
            all quarter`s data size of this region
        3. {region#version:[],...}
            all components data size of this quarter of this region
        :param statistic_file_path:
        :return:
        """
        with open(statistic_file_path, "r") as f:
            data_json_list = json.load(f)
            data_json_list.sort(key=lambda d: d["version"])
            data_json_list.sort(key=lambda d: d["region"])
            # TODO remove same region same version data
            raw_data_all_region_data_list = []
            raw_data_region_name_data_list_dic = {}
            raw_data_name_component_list_dic = {}
            for raw_data in data_json_list:
                region = raw_data["region"]
                version = raw_data["version"]
                data_size = raw_data["size"]
                components = raw_data["component_list"]
                raw_data_all_region_data_list.append(RawDataAllRegionStat(region=region, version=version, size=data_size))
                raw_data_region_name_data_list_dic.setdefault(region, []).append(
                    RawDataRegionStat(version=version, data_type=region, size=data_size))
                component_list = []
                for component in components:
                    component_name = component["name"]
                    component_size = component["size"]
                    component_list.append(RawDataComponentStat(component_name=component_name, data_type=region,
                                                               size=component_size))
                    raw_data_name = StatisticJsonReader.generate_data_name(region, version)
                    raw_data_name_component_list_dic[raw_data_name] = component_list

            return raw_data_all_region_data_list, raw_data_region_name_data_list_dic, raw_data_name_component_list_dic

    @staticmethod
    def generate_data_name(region, version):
        return "{region}#{version}".format(region=region, version=version)

    @staticmethod
    def read_pbf_statistic_file(pbf_statistic_file):
        """
        read PBF data statistic, get
        1. []
            all region`s all quarter pbf data size; here the quarter`s data size is the max of all types pbf data size
            of this quarter
        2. {region:[],...}
            all quarter`s all type`s pbf data of this region; here the type`s data size if the max of this type
        3. {region#version:[],...}
            all types`s pbf data size of this version of this region
        """
        with open(pbf_statistic_file, "r") as f:
            data_json_list = json.load(f)
            data_json_list.sort(key=lambda d: d["version"])
            data_json_list.sort(key=lambda d: d["region"])

            pbf_all_region_data_list = []
            pbf_region_name_data_list_dic = {}
            pbf_name_sub_data_list_dic = {}

            for data in data_json_list:
                region = data["region"]
                version = data["version"]
                data_size = data["size"]  # the sum size
                pbf_data_list = data["data_list"]

                data_list = []
                for pbf_data in pbf_data_list:
                    data_type = pbf_data["data_type"]
                    data_time = pbf_data["data_time"]
                    data_size = pbf_data["data_size"]
                    if not data_type or not data_time:
                        continue

                    data_list.append(PBFSubDataStat(data_type=data_type, data_time=data_time, size=data_size))

                pbf_name = StatisticJsonReader.generate_data_name(region, version)
                pbf_name_sub_data_list_dic[pbf_name] = data_list
                # choose max of every type(TEST,RC,DEV) in this data list
                region_max_type_data_list = PBFSubDataStat.choose_max_size_pbf_data(data_list)

                for type_max_data in region_max_type_data_list:
                    pbf_region_data = PBFRegionStat(version=version, data_type=type_max_data.data_type,
                                                    size=type_max_data.data_size)
                    pbf_region_name_data_list_dic.setdefault(region, []).append(pbf_region_data)

                if not len(region_max_type_data_list):
                    continue
                max_data_size = max([data_stat.data_size for data_stat in region_max_type_data_list])
                pbf_all_region_data_list.append(PBFAllRegionStat(region=region, version=version, size=max_data_size))
            return pbf_all_region_data_list, pbf_region_name_data_list_dic, pbf_name_sub_data_list_dic

    @staticmethod
    def read_raw_db_statistic_file(raw_db_statistic_file_path):
        """"""
        with open(raw_db_statistic_file_path, "r") as f:
            db_info_dic_list = json.load(f)
            f.close()
            db_stat_list = []
            region_name_db_stat_list_dic = {}
            for db_info_dic in db_info_dic_list:
                name = db_info_dic["database_name"]
                version = db_info_dic["version"]
                region = db_info_dic["region"]
                size = db_info_dic["size"]
                db_stat_list.append(DBStat(region=region, version=version, size=size))
                signal_db_stat = RDFDBSingleStat(version=version, region=region, size=size)
                region_name_db_stat_list_dic.setdefault(region, []).append(signal_db_stat)

        return db_stat_list, region_name_db_stat_list_dic

    @staticmethod
    def read_unidb_db_statistic_file(unidb_db_statistic_info_file_path):
        """
        read unidb statistic json file
        tip:
        1. one version unidb have many type
        2. one type db have many time,
        So, there are two max operations here.
        :param unidb_db_statistic_info_file_path:
        :return:
        """
        with open(unidb_db_statistic_info_file_path, "r") as f:
            db_info_dic_list = json.load(f)
            f.close()
            db_stat_list = []
            region_name_db_stat_list_dic = {}
            name_db_stat_list_dic = {}
            for db_info_dic in db_info_dic_list:
                name = db_info_dic["database_name"]
                version = db_info_dic["version"]
                region = db_info_dic["region"]
                size = db_info_dic["size"]

                data_type = db_info_dic["data_type"]
                data_time = db_info_dic["data_time"]
                signal_db_stat = UnidbDBSingleStat(pbf_time=version, pbf_type=data_type, size=size)

                region_version = StatisticJsonReader.generate_data_name(region, version)
                name_db_stat_list_dic.setdefault(region_version, []).append(signal_db_stat)

            # 2. for same region and same version unidb, choose the max
            # 3. for same types, choose the max
            for region_version, db_list in name_db_stat_list_dic.iteritems():
                max_type_unidb_db_list = UnidbDBSingleStat.choose_max_size_pbf_data(db_list)
                region, version = region_version.split("#")
                region_name_db_stat_list_dic.setdefault(region, [])
                region_name_db_stat_list_dic[region] += max_type_unidb_db_list

                max_db_size = max([unidb_signal_db_stat.data_size for unidb_signal_db_stat in max_type_unidb_db_list])
                db_stat_list.append(DBStat(region=region, version=version, size=max_db_size))

            return db_stat_list, region_name_db_stat_list_dic


REGIONS_VARIABLE_NAME = "regions"
JS_OUTPUT_PATH = os.path.join(ROOT_PATH, "output_js")
RAW_JS_OUTPUT_PATH = "raw"
PBF_JS_OUTPUT_PATH = "pbf"
RDF_DB_JS_OUTPUT_PATH = "rdf_db"
UNIDB_DB_JS_OUTPUT_PATH = "unidb_db"
OUT_PUT_JS_FILENAME = "info.js"

JS_RESOURCE_PATH = os.path.join(ROOT_PATH, "js_resource", "js")
HTML_TEMPLATE_FILE_PATH = os.path.join(ROOT_PATH, "js_resource", "index.html")


class JSUtils(object):
    @staticmethod
    def copy_js_resource(des_path):
        """
        index.html to this path;
        js to its`parent path
        :param des_path:
        :return:
        """
        html_file_name = os.path.basename(HTML_TEMPLATE_FILE_PATH)
        html_file_des_path = os.path.join(des_path, html_file_name)
        if os.path.exists(html_file_des_path):
            os.remove(html_file_des_path)
        js_source_des_path = os.path.join(os.path.dirname(des_path), os.path.basename(JS_RESOURCE_PATH))
        if os.path.exists(js_source_des_path):
            shutil.rmtree(js_source_des_path)
        # copy
        shutil.copy(HTML_TEMPLATE_FILE_PATH, des_path)
        shutil.copytree(JS_RESOURCE_PATH, js_source_des_path)

    @staticmethod
    def save_parse_result(output_file_path, chart_dic_function, **kwargs):
        js_chart_dic = chart_dic_function(**kwargs)
        JSUtils.save_dic2js(file_name=output_file_path, data_dic=js_chart_dic)

    @staticmethod
    def save_dic2js(file_name, data_dic):
        if not os.path.exists(os.path.dirname(file_name)):
            os.makedirs(os.path.dirname(file_name))
        # copy js resource
        JSUtils.copy_js_resource(os.path.dirname(file_name))
        with open(file_name, "w") as f:
            for key, content in data_dic.iteritems():
                json_content = json.dumps(content, ensure_ascii=False)
                f.write("var {variable_name}={content};\n".format(variable_name=key, content=json_content))
            f.close()

    @staticmethod
    def generate_raw_all_regions(raw_data_list, data_type):
        output_js_file_path = os.path.join(JS_OUTPUT_PATH, data_type, RAW_JS_OUTPUT_PATH, OUT_PUT_JS_FILENAME)
        JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                  chart_dic_function=RawDataAllRegionStat.data2chart_dic, raw_data_list=raw_data_list)

    @staticmethod
    def generate_pbf_all_regions(pbf_list, data_type):
        output_js_file_path = os.path.join(JS_OUTPUT_PATH, data_type, PBF_JS_OUTPUT_PATH, OUT_PUT_JS_FILENAME)
        JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                  chart_dic_function=PBFAllRegionStat.data2chart_dic, pbf_list=pbf_list)

    @staticmethod
    def generate_raw_signal_region(region_name_data_list_dic, data_type):
        for region_name, data_list in region_name_data_list_dic.iteritems():
            output_js_file_path = os.path.join(JS_OUTPUT_PATH, data_type, RAW_JS_OUTPUT_PATH, region_name, OUT_PUT_JS_FILENAME)
            JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                      chart_dic_function=RawDataRegionStat.data2chart_dict,
                                      raw_data_data_list=data_list, region=region_name)

    @staticmethod
    def generate_pbf_single_region(pbf_region_name_data_list_dic, data_type):
        for region_name, data_list in pbf_region_name_data_list_dic.iteritems():
            output_js_file_path = os.path.join(JS_OUTPUT_PATH, data_type, PBF_JS_OUTPUT_PATH, region_name, OUT_PUT_JS_FILENAME)
            JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                      chart_dic_function=PBFRegionStat.data2chart_dic,
                                      pbf_region_data_list=data_list, region=region_name)

    @staticmethod
    def generate_raw_components(name_components_list_dic, data_type):
        for name, components_list in name_components_list_dic.iteritems():
            region, version = name.split("#")
            output_js_file_path = os.path.join(JS_OUTPUT_PATH, data_type, RAW_JS_OUTPUT_PATH, region, version, OUT_PUT_JS_FILENAME)
            JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                      chart_dic_function=RawDataComponentStat.data2chart_dict,
                                      data_list=components_list, data_name=name)

    @staticmethod
    def generate_pbf_sub_data_list(pbf_name_sub_data_list_dic, data_type):

        for pbf_name, sub_data_list in pbf_name_sub_data_list_dic.iteritems():
            region, version = pbf_name.split("#")
            output_js_file_path = os.path.join(JS_OUTPUT_PATH, data_type, PBF_JS_OUTPUT_PATH, region, version, OUT_PUT_JS_FILENAME)
            JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                      chart_dic_function=PBFSubDataStat.data2chart_dic,
                                      pbf_data_list=sub_data_list, data_name=pbf_name)

    @staticmethod
    def generate_rdf_db_data_list(db_stat_list, data_type):
        output_js_file_path = os.path.join(JS_OUTPUT_PATH, data_type, RDF_DB_JS_OUTPUT_PATH, OUT_PUT_JS_FILENAME)
        JSUtils.save_parse_result(output_file_path=output_js_file_path, chart_dic_function=DBStat.data2chart_dic,
                                  db_info_list=db_stat_list, table_name=DBStat.rdf_db_table_name)

    @staticmethod
    def generate_rdf_db_single_data_list(region_name_db_stat_list_dic, data_type):
        for region, data_list in region_name_db_stat_list_dic.iteritems():
            output_js_file_path = os.path.join(JS_OUTPUT_PATH, data_type, RDF_DB_JS_OUTPUT_PATH, region, OUT_PUT_JS_FILENAME)
            JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                      chart_dic_function=RDFDBSingleStat.data2chart_dic,
                                      db_info_list=data_list, region_name=region)

    @staticmethod
    def generate_unidb_db_data_list(db_stat_list, data_type):
        output_js_file_path = os.path.join(JS_OUTPUT_PATH, data_type, UNIDB_DB_JS_OUTPUT_PATH, OUT_PUT_JS_FILENAME)
        JSUtils.save_parse_result(output_file_path=output_js_file_path, chart_dic_function=DBStat.data2chart_dic,
                                  db_info_list=db_stat_list, table_name=DBStat.unidb_db_table_name)

    @staticmethod
    def generate_unidb_db_single_data_list(region_name_db_stat_list_dic, data_type):
        for region_name, db_stat_list in region_name_db_stat_list_dic.iteritems():
            output_js_file_path = os.path.join(JS_OUTPUT_PATH, data_type, UNIDB_DB_JS_OUTPUT_PATH, region_name, OUT_PUT_JS_FILENAME)
            JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                      chart_dic_function=UnidbDBSingleStat.data2chart_dic,
                                      db_info_list=db_stat_list, region_name=region_name)


def test_generate_raw_data_regions_stat(statistic_json_file_path, data_type):
    all_region_data_list, region_name_data_list_dic, name_component_list_dic = (
        StatisticJsonReader.read_raw_statistic_file(statistic_json_file_path))
    JSUtils.generate_raw_all_regions(all_region_data_list, data_type)
    JSUtils.generate_raw_signal_region(region_name_data_list_dic, data_type)
    JSUtils.generate_raw_components(name_component_list_dic, data_type)


def test_generate_pbf_js(statistic_json_file_path, data_des_path):
    all_region_data_list, region_data_list_dic, pbf_name_sub_data_list_dic = (
        StatisticJsonReader.read_pbf_statistic_file(statistic_json_file_path))
    JSUtils.generate_pbf_all_regions(all_region_data_list, data_des_path)
    JSUtils.generate_pbf_single_region(region_data_list_dic, data_des_path)
    JSUtils.generate_pbf_sub_data_list(pbf_name_sub_data_list_dic, data_des_path)


def test_generate_rdf_db_js(statistic_json_file_path, data_type):
    rdf_db_stat_list, region_name_rdf_db_stat_list_dic = StatisticJsonReader.read_raw_db_statistic_file(
        statistic_json_file_path)
    JSUtils.generate_rdf_db_data_list(rdf_db_stat_list, data_type)
    JSUtils.generate_rdf_db_single_data_list(region_name_rdf_db_stat_list_dic, data_type)


def test_generate_unidb_db_js(statistic_json_file_path, data_des_path):
    unidb_db_stat_list, region_name_unidb_db_stat_list_dic = StatisticJsonReader.read_unidb_db_statistic_file(
        statistic_json_file_path)
    JSUtils.generate_unidb_db_data_list(unidb_db_stat_list, data_des_path)
    JSUtils.generate_unidb_db_single_data_list(region_name_unidb_db_stat_list_dic, data_des_path)


def test_generate_all_regions():
    statistic_base_dir = "output_statistic"
    region_types = os.listdir(statistic_base_dir)
    for region_type in region_types:
        raw_json_file_path_list = glob.glob(os.path.join(statistic_base_dir, region_type,
                                                         raw_statistic_json_file_base_dir,
                                                         "*.json"))
        pbf_json_file_path_list = glob.glob(os.path.join(statistic_base_dir,
                                                         region_type, pbf_statistic_json_file_base_dir,
                                                         "*.json"))
        rdf_db_json_file_path_list = glob.glob(os.path.join(statistic_base_dir, region_type,
                                                            rdf_db_statistic_json_file_base_dir,
                                                            "*.json"))
        unidb_db_json_file_path_list = glob.glob(os.path.join(statistic_base_dir, region_type,
                                                              unidb_db_statistic_json_file_base_dir,
                                                              "*.json"))
        if (not raw_json_file_path_list or not pbf_json_file_path_list or
                not rdf_db_json_file_path_list or not unidb_db_json_file_path_list):
            sys.stderr.write("json statistic file can not find.\n")
            sys.exit(-1)

        test_generate_raw_data_regions_stat(raw_json_file_path_list[0], region_type)
        test_generate_pbf_js(pbf_json_file_path_list[0], region_type)
        test_generate_rdf_db_js(rdf_db_json_file_path_list[0], region_type)
        test_generate_unidb_db_js(unidb_db_json_file_path_list[0], region_type)


if __name__ == '__main__':
    test_generate_all_regions()
