# encoding=utf8
from datetime import datetime
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
import json
import jpy

# rdf_db_statistic_file_path = "output_statistic/db/raw_db/raw_db_statistic.json"
es = Elasticsearch("localhost:9200")
es.indices.create(index="rdf_db", ignore=400)

# with open("", "r") as f:
#     rdf_db_list = json.load(f)
#
#     actions = [
#         {
#             "_op_type": "index",
#             "_index": "rdf_db",
#             "_type": "space_statistic",
#             "_source": d
#         }
#         for d in rdf_db_list
#     ]
#     # bulk(es, actions)

import jieba

print ",".join(jieba.cut(u"我们要搬家了，从仙霞路333号东方维京大厦搬到娄山关路523号金虹桥国际中心"))
