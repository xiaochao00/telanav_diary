import os
import json

ROOT_PATH = os.path.dirname(os.path.abspath(__file__))
raw_data_statistic_file_path = os.path.join(ROOT_PATH, "raw_data_statistic_Other.json")


class JSChart(object):
    def __init__(self, chart_series_list, chart_legend_list, chart_x_list):
        self.chart_series_list = chart_series_list
        self.chart_legend_list = chart_legend_list
        self.chart_x_list = chart_x_list

    def format2dic(self):
        series_dic = [chart_series.__dict__ for chart_series in self.chart_series_list]
        x_dic = [chart_x.data for chart_x in self.chart_x_list]
        legend_dic = [chart_legend.data for chart_legend in self.chart_legend_list]
        return {"regions_series": series_dic, "regions_x": x_dic, "regions_legend": legend_dic}


class ChartSeries(object):
    def __init__(self, name, type, data, stack="stack"):
        self.name = name
        self.type = type
        self.data = data
        self.stack = stack


class ChartLegend(object):
    def __init__(self, data):
        self.data = data


class ChartXAxis(object):
    def __init__(self, data):
        self.data = data


class ChartData(object):
    def __init__(self, x_name, x_type, value):
        self.x_name = x_name
        self.x_type = x_type
        self.value = value

    @staticmethod
    def transform2chart(chart_data_list, chart_type):
        """To JSChart"""
        # There are missing value in x_type for x_name column.
        x_type_name_size_dic = {}
        x_name_list = []
        for chart_data in chart_data_list:
            x_name = chart_data.x_name
            x_type = chart_data.x_type
            value = chart_data.value
            x_name_list.append(x_name)
            x_type_name_size_dic.setdefault(x_type, {}).setdefault(x_name, value)
        x_name_list = list(set(x_name_list))
        x_name_list.sort()
        # add missing value
        # chart_series
        chart_series_list = []
        for x_type, x_name_value_dic in x_type_name_size_dic.iteritems():
            series_value_list = []
            type_name_list = x_name_value_dic.keys()
            for name in x_name_list:
                if name in type_name_list:
                    series_value_list.append(x_name_value_dic[name])
                else:
                    series_value_list.append(0)
            chart_series_list.append(ChartSeries(x_type, chart_type, series_value_list))
        # x axis
        chart_x_list = [ChartXAxis(name) for name in x_name_list]
        #  legend
        chart_legend_list = [ChartLegend(x_type) for x_type in x_type_name_size_dic]

        return JSChart(chart_series_list, chart_legend_list, chart_x_list)


class VendorDataStat(object):
    chart_type = "bar"

    def __init__(self, region, version, path, size, pretty_size):
        self.region = region
        self.version = version
        self.path = path
        self.pretty_size = pretty_size
        self.size = size

    @staticmethod
    def _list2chart_data_list(vendor_data_list):
        """Transform vendor data list to chart data list[{x_name: , x_type: , value:},...]"""
        chart_data_list = []
        for vendor_data in vendor_data_list:
            x_name = vendor_data.version
            x_type = vendor_data.region
            size = vendor_data.size
            chart_data_list.append(ChartData(x_name=x_name, x_type=x_type, value=size))
        return chart_data_list

    @staticmethod
    def data2chart(vendor_data_list):
        chart_data_list = VendorDataStat._list2chart_data_list(vendor_data_list)
        return ChartData.transform2chart(chart_data_list, VendorDataStat.chart_type)


class ComponentStat(object):
    def __init__(self, name, path, size, pretty_size):
        self.name = name
        self.path = path
        self.size = size
        self.pretty_size = pretty_size


class StatisticJsonReader(object):
    @staticmethod
    def read_statistic_file(statistic_file_path):
        with open(statistic_file_path, "r") as f:
            data_json_list = json.load(f)
            data_json_list.sort(key=lambda d: d["version"])
            data_json_list.sort(key=lambda d: d["region"])
            # TODO remove same region same version data
            vendor_list = []
            vendor_components_dic = {}
            for vendor_data in data_json_list:
                region = vendor_data["region"]
                version = vendor_data["version"]
                data_path = vendor_data["data_path"]
                data_size = vendor_data["size"]
                vendor_pretty_size = vendor_data["vendor_pretty_size"]
                components = vendor_data["component_list"]
                vendor_list.append(VendorDataStat(region=region, version=version, path=data_path, size=data_size,
                                                  pretty_size=vendor_pretty_size))
                vendor_name = StatisticJsonReader.generate_vendor_name(region, version)
                component_list = []
                for component in components:
                    component_name = component["name"]
                    component_path = component["path"]
                    component_size = component["size"]
                    component_pretty_size = component["component_pretty_size"]
                    component_list.append(ComponentStat(name=component_name, path=component_path, size=component_size,
                                                        pretty_size=component_pretty_size))
                vendor_components_dic[vendor_name] = component_list
            return vendor_list, vendor_components_dic

    @staticmethod
    def generate_vendor_name(region, version):
        return "_".join([region, version])


REGIONS_VARIABLE_NAME = "regions"
REGIONS_JS_FILENAME = os.path.join(ROOT_PATH, "other_regions.js")


class JSUtils(object):
    @staticmethod
    def save_dic2js(file_name, data_dic):
        with open(file_name, "w") as f:
            for key, content in data_dic.iteritems():
                json_content = json.dumps(content, ensure_ascii=False)
                f.write("var {variable_name}={content};\n".format(variable_name=key, content=json_content))
            f.close()

    @staticmethod
    def generate_all_regions(vendor_data_list):
        js_chart = VendorDataStat.data2chart(vendor_data_list)
        #
        region_data_dic = js_chart.format2dic()
        JSUtils.save_dic2js(REGIONS_JS_FILENAME, region_data_dic)


def test_generate_regions_stat():
    vendor_data_list, vendor_components_dic = StatisticJsonReader.read_statistic_file(raw_data_statistic_file_path)
    JSUtils.generate_all_regions(vendor_data_list)


if __name__ == '__main__':
    test_generate_regions_stat()
