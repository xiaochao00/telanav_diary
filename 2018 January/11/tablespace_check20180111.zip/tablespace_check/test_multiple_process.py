import multiprocessing


def a(b):
    return b + 1


def multiple(list):
    pool = multiprocessing.Pool(processes=2)

    result_list = []
    # for l in list:
    #     result_list.append(pool.apply_async(a, (l,)))
    c = pool.map(a, (list,))
    pool.close()
    pool.join()
    for res in result_list:
        print res.get()


if __name__ == '__main__':
    list = [1, 2, 3, 4]
    multiple(list)
