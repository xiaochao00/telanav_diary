var title="PBF Data Detail Space Statistic";
var regions_series=[{"data": [18076605], "type": "line", "name": "RC", "stack": "stack"}];
var regions_legend=["RC"];
var regions_x=["20170526170018"];
