var title="PBF Region:CN_Level0 Space Statistic";
var regions_series=[{"data": [0, 12538129, 0, 0, 0, 9746831], "type": "bar", "name": "TEST", "stack": "stack"}, {"data": [7795538, 8314804, 0, 0, 0, 0], "type": "bar", "name": null, "stack": "stack"}, {"data": [0, 8312707, 60817046, 49554075, 0, 18992062], "type": "bar", "name": "DEV", "stack": "stack"}, {"data": [0, 10313356, 52397948, 364349320, 18076605, 16708429], "type": "bar", "name": "RC", "stack": "stack"}];
var regions_legend=["TEST", null, "DEV", "RC"];
var regions_x=["14Q1", "15Q1", "15Q3", "16Q1", "17Q1", "17Q2"];
