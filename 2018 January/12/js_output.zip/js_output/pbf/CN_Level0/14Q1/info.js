var title="PBF Data Detail Space Statistic";
var regions_series=[{"data": [287], "type": "line", "name": null, "stack": "stack"}];
var regions_legend=[null];
var regions_x=[null];
