var title="PBF Data Detail Space Statistic";
var regions_series=[{"data": [0, 0, 0, 0, 0, 0, 0, 0, 49554075], "type": "line", "name": "DEV", "stack": "stack"}, {"data": [364349320, 51029040, 51028895, 12898183, 12900523, 12900357, 12900367, 51029628, 0], "type": "line", "name": "RC", "stack": "stack"}];
var regions_legend=["DEV", "RC"];
var regions_x=["20160504104804", "20160504134912", "20160614103507", "20160628174005", "20160628184531", "20160629094700", "20160629101559", "20160629103346", "20170310094847"];
