var title="PBF Data Detail Space Statistic";
var regions_series=[{"data": [8047234, 14507217, 60817046, 0, 0, 0, 0], "type": "line", "name": "DEV", "stack": "stack"}, {"data": [0, 0, 0, 12907102, 51036068, 36113964, 52397948], "type": "line", "name": "RC", "stack": "stack"}];
var regions_legend=["DEV", "RC"];
var regions_x=["20151204173928", "20151207185949", "20160104111504", "20160122103021", "20160122110912", "20160122112253", "20160122135311"];
