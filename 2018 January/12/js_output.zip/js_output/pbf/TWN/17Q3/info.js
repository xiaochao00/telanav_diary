var title="PBF Data Detail Space Statistic";
var regions_series=[{"data": [2354], "type": "line", "name": "TEST", "stack": "stack"}];
var regions_legend=["TEST"];
var regions_x=["20171130133416"];
