var title="PBF Region:TWN Space Statistic";
var regions_series=[{"data": [2354], "type": "bar", "name": "TEST", "stack": "stack"}];
var regions_legend=["TEST"];
var regions_x=["17Q3"];
