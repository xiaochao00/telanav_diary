var title="PBF Data Detail Space Statistic";
var regions_series=[{"data": [10343987517, 10202225205, 10216583590, 10216518656, 10216495722, 10218141352], "type": "line", "name": "RC", "stack": "stack"}];
var regions_legend=["RC"];
var regions_x=["20160510144018", "20160512130150", "20160614162009", "20160615175027", "20160628172021", "20160811100524"];
