var title="PBF Data Detail Space Statistic";
var regions_series=[{"data": [0, 0, 0, 0, 0], "type": "line", "name": null, "stack": "stack"}, {"data": [0, 14472024625, 14463201886, 14462548744, 1691650988], "type": "line", "name": "DEV", "stack": "stack"}];
var regions_legend=[null, "DEV"];
var regions_x=[null, "20180103175539", "20180104110335", "20180110014035", "20180110192743"];
