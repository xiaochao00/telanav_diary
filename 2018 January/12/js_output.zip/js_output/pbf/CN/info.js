var title="PBF Region:CN Space Statistic";
var regions_series=[{"data": [0, 738148352, 0, 0, 17177536654, 0], "type": "bar", "name": "TEST", "stack": "stack"}, {"data": [0, 720428804, 0, 0, 0, 0], "type": "bar", "name": "CI", "stack": "stack"}, {"data": [9812913961, 0, 0, 0, 0, 0], "type": "bar", "name": null, "stack": "stack"}, {"data": [0, 9389232641, 0, 0, 14953319612, 14472024625], "type": "bar", "name": "DEV", "stack": "stack"}, {"data": [8658620682, 10083825996, 10343987517, 25290439923, 14112370317, 0], "type": "bar", "name": "RC", "stack": "stack"}];
var regions_legend=["TEST", "CI", null, "DEV", "RC"];
var regions_x=["15Q1", "15Q3", "16Q1", "17Q1", "17Q2", "17Q3"];
