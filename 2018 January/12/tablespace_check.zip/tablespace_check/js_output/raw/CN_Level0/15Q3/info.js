var regions_series=[{"data": [14011392], "type": "bar", "name": "rdf"}, {"data": [101164], "type": "bar", "name": "components"}];
var table_title="CN_Level0#15Q3 Components Statistic";
var regions_legend=["rdf", "components"];
var regions_x=["CN_Level0"];
var kwargs={};
