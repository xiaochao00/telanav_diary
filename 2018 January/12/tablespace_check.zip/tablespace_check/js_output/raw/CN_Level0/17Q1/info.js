var regions_series=[{"data": [13834240], "type": "bar", "name": "rdf"}, {"data": [101895], "type": "bar", "name": "components"}];
var table_title="CN_Level0#17Q1 Components Statistic";
var regions_legend=["rdf", "components"];
var regions_x=["CN_Level0"];
var kwargs={};
