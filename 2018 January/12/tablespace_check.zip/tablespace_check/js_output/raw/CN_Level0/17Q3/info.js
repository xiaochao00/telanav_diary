var regions_series=[{"data": [13926862], "type": "bar", "name": "rdf"}, {"data": [101935], "type": "bar", "name": "components"}];
var table_title="CN_Level0#17Q3 Components Statistic";
var regions_legend=["rdf", "components"];
var regions_x=["CN_Level0"];
var kwargs={};
