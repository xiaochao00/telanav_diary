var regions_series=[{"data": [13987840], "type": "bar", "name": "rdf"}, {"data": [242974], "type": "bar", "name": "components"}];
var table_title="CN_Level0#15Q1 Components Statistic";
var regions_legend=["rdf", "components"];
var regions_x=["CN_Level0"];
var kwargs={};
