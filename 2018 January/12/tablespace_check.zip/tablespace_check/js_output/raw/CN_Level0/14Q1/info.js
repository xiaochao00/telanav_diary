var regions_series=[{"data": [10443112], "type": "bar", "name": "rdf"}, {"data": [256451], "type": "bar", "name": "components"}];
var table_title="CN_Level0#14Q1 Components Statistic";
var regions_legend=["rdf", "components"];
var regions_x=["CN_Level0"];
var kwargs={};
