var regions_series=[{"data": [10699563, 14230814, 14112556, 14201612, 13936135, 13987375, 14028797], "type": "line", "name": "CN_Level0"}];
var table_title="PBF Region:CN_Level0 Space Statistic";
var regions_legend=["CN_Level0"];
var regions_x=["14Q1", "15Q1", "15Q3", "16Q1", "17Q1", "17Q2", "17Q3"];
var kwargs={"jump_rule": "name"};
