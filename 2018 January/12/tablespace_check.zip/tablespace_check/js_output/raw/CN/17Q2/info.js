var regions_series=[{"data": [146912], "type": "bar", "name": "level2_sensitive"}, {"data": [1266462352], "type": "bar", "name": "speed_camera"}, {"data": [629493541], "type": "bar", "name": "speed_pattern"}, {"data": [8347463300], "type": "bar", "name": "junction_view"}, {"data": [18205348098], "type": "bar", "name": "rdf"}, {"data": [10519004], "type": "bar", "name": "cn_add_content"}, {"data": [2218682630], "type": "bar", "name": "3D_landmark"}, {"data": [74522963], "type": "bar", "name": "traffic_location"}];
var table_title="CN#17Q2 Components Statistic";
var regions_legend=["level2_sensitive", "speed_camera", "speed_pattern", "junction_view", "rdf", "cn_add_content", "3D_landmark", "traffic_location"];
var regions_x=["CN"];
var kwargs={};
