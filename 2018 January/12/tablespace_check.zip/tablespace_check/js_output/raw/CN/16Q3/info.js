var regions_series=[{"data": [7846726], "type": "bar", "name": "cn_add_content"}, {"data": [206464], "type": "bar", "name": "level2_sensitive"}, {"data": [2697032124], "type": "bar", "name": "3D_landmark"}, {"data": [528072492], "type": "bar", "name": "speed_camera"}];
var table_title="CN#16Q3 Components Statistic";
var regions_legend=["cn_add_content", "level2_sensitive", "3D_landmark", "speed_camera"];
var regions_x=["CN"];
var kwargs={};
