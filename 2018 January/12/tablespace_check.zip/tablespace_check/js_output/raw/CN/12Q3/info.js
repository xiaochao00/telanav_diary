var regions_series=[{"data": [1145617370], "type": "bar", "name": "3D_landmark"}];
var table_title="CN#12Q3 Components Statistic";
var regions_legend=["3D_landmark"];
var regions_x=["CN"];
var kwargs={};
