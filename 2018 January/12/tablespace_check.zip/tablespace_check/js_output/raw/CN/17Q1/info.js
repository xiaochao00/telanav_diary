var regions_series=[{"data": [206554], "type": "bar", "name": "level2_sensitive"}, {"data": [1206877132], "type": "bar", "name": "speed_camera"}, {"data": [633135534], "type": "bar", "name": "speed_pattern"}, {"data": [3939388798], "type": "bar", "name": "junction_view"}, {"data": [17932974080], "type": "bar", "name": "rdf"}, {"data": [10028453], "type": "bar", "name": "cn_add_content"}, {"data": [3268878652], "type": "bar", "name": "3D_landmark"}, {"data": [74522963], "type": "bar", "name": "traffic_location"}];
var table_title="CN#17Q1 Components Statistic";
var regions_legend=["level2_sensitive", "speed_camera", "speed_pattern", "junction_view", "rdf", "cn_add_content", "3D_landmark", "traffic_location"];
var regions_x=["CN"];
var kwargs={};
