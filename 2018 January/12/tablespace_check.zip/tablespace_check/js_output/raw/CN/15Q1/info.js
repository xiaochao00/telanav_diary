var regions_series=[{"data": [7001014], "type": "bar", "name": "cn_add_content"}, {"data": [60382], "type": "bar", "name": "level2_sensitive"}, {"data": [2498794826], "type": "bar", "name": "3D_landmark"}, {"data": [476918361], "type": "bar", "name": "speed_camera"}, {"data": [10496020480], "type": "bar", "name": "rdf"}];
var table_title="CN#15Q1 Components Statistic";
var regions_legend=["cn_add_content", "level2_sensitive", "3D_landmark", "speed_camera", "rdf"];
var regions_x=["CN"];
var kwargs={};
