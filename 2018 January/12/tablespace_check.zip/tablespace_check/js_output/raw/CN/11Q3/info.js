var regions_series=[{"data": [228348923], "type": "bar", "name": "cn_add_content"}, {"data": [372017887], "type": "bar", "name": "3D_landmark"}, {"data": [8583845], "type": "bar", "name": "speed_camera"}];
var table_title="CN#11Q3 Components Statistic";
var regions_legend=["cn_add_content", "3D_landmark", "speed_camera"];
var regions_x=["CN"];
var kwargs={};
