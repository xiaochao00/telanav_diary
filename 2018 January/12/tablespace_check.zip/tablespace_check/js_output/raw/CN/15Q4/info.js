var regions_series=[{"data": [5970110], "type": "bar", "name": "traffic_location"}];
var table_title="CN#15Q4 Components Statistic";
var regions_legend=["traffic_location"];
var regions_x=["CN"];
var kwargs={};
