var regions_series=[{"data": [4393420], "type": "bar", "name": "cn_add_content"}, {"data": [2395777278], "type": "bar", "name": "3D_landmark"}, {"data": [4323221], "type": "bar", "name": "speed_camera"}];
var table_title="CN#13Q2 Components Statistic";
var regions_legend=["cn_add_content", "3D_landmark", "speed_camera"];
var regions_x=["CN"];
var kwargs={};
