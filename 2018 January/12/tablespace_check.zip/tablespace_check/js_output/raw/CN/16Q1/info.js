var regions_series=[{"data": [207796], "type": "bar", "name": "level2_sensitive"}, {"data": [871568094], "type": "bar", "name": "speed_camera"}, {"data": [101903440], "type": "bar", "name": "speed_pattern"}, {"data": [3327048285], "type": "bar", "name": "junction_view"}, {"data": [12625786880], "type": "bar", "name": "rdf"}, {"data": [8542387], "type": "bar", "name": "cn_add_content"}, {"data": [3002391761], "type": "bar", "name": "3D_landmark"}, {"data": [67202460], "type": "bar", "name": "traffic_location"}];
var table_title="CN#16Q1 Components Statistic";
var regions_legend=["level2_sensitive", "speed_camera", "speed_pattern", "junction_view", "rdf", "cn_add_content", "3D_landmark", "traffic_location"];
var regions_x=["CN"];
var kwargs={};
