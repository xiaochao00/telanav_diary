var regions_series=[{"data": [0, 0, 0, 0, 0, 0, 2354], "type": "bar", "name": "TWN", "stack": "stack"}, {"data": [0, 131305441350, 63103909141, 61413952042, 25290439923, 146238584989, 45089426243], "type": "bar", "name": "CN", "stack": "stack"}, {"data": [15406148, 213443316, 235826579, 618590388, 18076605, 191588856, 0], "type": "bar", "name": "CN_Level0", "stack": "stack"}];
var table_title="PBF All Region Space Statistic";
var regions_legend=["TWN", "CN", "CN_Level0"];
var regions_x=["14Q1", "15Q1", "15Q3", "16Q1", "17Q1", "17Q2", "17Q3"];
var kwargs={"jump_rule": "series_name"};
