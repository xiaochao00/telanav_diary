var regions_series=[{"data": [12538129, 0, 0, 0, 9746831], "type": "line", "name": "TEST"}, {"data": [8312707, 60817046, 49554075, 0, 18992062], "type": "line", "name": "DEV"}, {"data": [10313356, 52397948, 364349320, 18076605, 16708429], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN_Level0 Space Statistic";
var regions_legend=["TEST", "DEV", "RC"];
var regions_x=["15Q1", "15Q3", "16Q1", "17Q1", "17Q2"];
var kwargs={"jump_rule": "name"};
