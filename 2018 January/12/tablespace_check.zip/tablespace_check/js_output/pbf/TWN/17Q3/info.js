var regions_series=[{"data": [2354], "type": "line", "name": "TEST", "stack": "stack"}];
var table_title="PBF Data[TWN#17Q3] Detail Space Statistic";
var regions_legend=["TEST"];
var regions_x=["20171130133416"];
var kwargs={};
