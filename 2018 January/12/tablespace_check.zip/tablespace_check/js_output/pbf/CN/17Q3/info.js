var regions_series=[{"data": [14472024625, 14463201886, 14462548744, 1691650988], "type": "line", "name": "DEV", "stack": "stack"}];
var table_title="PBF Data[CN#17Q3] Detail Space Statistic";
var regions_legend=["DEV"];
var regions_x=["20180103175539", "20180104110335", "20180110014035", "20180110192743"];
var kwargs={};
