var regions_series=[{"data": [0, 738148352, 0, 0, 17177536654, 0], "type": "line", "name": "TEST"}, {"data": [0, 720428804, 0, 0, 0, 0], "type": "line", "name": "CI"}, {"data": [0, 9389232641, 0, 0, 14953319612, 14472024625], "type": "line", "name": "DEV"}, {"data": [8658620682, 10083825996, 10343987517, 25290439923, 14112370317, 0], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["TEST", "CI", "DEV", "RC"];
var regions_x=["15Q1", "15Q3", "16Q1", "17Q1", "17Q2", "17Q3"];
var kwargs={"jump_rule": "name"};
