import os
import json
import shutil

ROOT_PATH = os.path.dirname(os.path.abspath(__file__))
raw_data_statistic_file_path = os.path.join(ROOT_PATH, "raw_data_statistic_CN.json")
pbf_statistic_file_path = os.path.join(ROOT_PATH, "pbf_statistic_CN.json")


class JSChart(object):
    def __init__(self, chart_series_list, chart_legend_list, chart_x_list, table_title, **kwargs):
        self.chart_series_list = chart_series_list
        self.chart_legend_list = chart_legend_list
        self.chart_x_list = chart_x_list

        self.table_title = table_title
        self.kwargs = kwargs

    def format2dic(self):
        series_dic = [chart_series.format2dict() for chart_series in self.chart_series_list]
        x_dic = [chart_x.data for chart_x in self.chart_x_list]
        legend_dic = [chart_legend.data for chart_legend in self.chart_legend_list]
        data_dic = {"regions_series": series_dic, "regions_x": x_dic, "regions_legend": legend_dic, "table_title": self.table_title}

        if self.kwargs:
            data_dic = dict(self.kwargs, **data_dic)
        return data_dic


class ChartSeries(object):
    def __init__(self, name, chart_type, data, stack="stack"):
        self.name = name
        self.type = chart_type
        self.data = data
        self.stack = stack

    def format2dict(self):
        data_dic = {"name": self.name, "type": self.type, "data": self.data}
        if self.stack:
            data_dic["stack"] = self.stack
        return data_dic


class ChartLegend(object):
    def __init__(self, data):
        self.data = data


class ChartXAxis(object):
    def __init__(self, data):
        self.data = data


class ChartData(object):
    def __init__(self, x_name, x_type, value):
        self.x_name = x_name
        self.x_type = x_type
        self.value = value

    @staticmethod
    def transform2chart(chart_data_list, chart_type, title, stack="stack", **kwargs):
        """To JSChart"""
        # There are missing value in x_type for x_name column.
        x_type_name_size_dic = {}
        x_name_list = []
        for chart_data in chart_data_list:
            x_name = chart_data.x_name
            x_type = chart_data.x_type
            value = chart_data.value
            x_name_list.append(x_name)
            x_type_name_size_dic.setdefault(x_type, {}).setdefault(x_name, value)
        x_name_list = list(set(x_name_list))
        x_name_list.sort()
        # add missing value
        # chart_series
        chart_series_list = []
        for x_type, x_name_value_dic in x_type_name_size_dic.iteritems():
            series_value_list = []
            type_name_list = x_name_value_dic.keys()
            for name in x_name_list:
                if name in type_name_list:
                    series_value_list.append(x_name_value_dic[name])
                else:
                    series_value_list.append(0)
            chart_series_list.append(ChartSeries(x_type, chart_type, series_value_list, stack))
        # x axis
        chart_x_list = [ChartXAxis(name) for name in x_name_list]
        #  legend
        chart_legend_list = [ChartLegend(x_type) for x_type in x_type_name_size_dic]

        return JSChart(chart_series_list=chart_series_list, chart_legend_list=chart_legend_list, chart_x_list=chart_x_list,
                       table_title=title, kwargs=kwargs)


class DataStat(object):
    def __init__(self, data_name, data_type, data_size):
        self.data_name = data_name
        self.data_type = data_type
        self.data_size = data_size

    @staticmethod
    def _list2chart_data_list(data_list):
        """Transform pbf list to chart data list[{x_name: , x_type: , value:},...]"""
        chart_data_list = []
        for data in data_list:
            x_name = data.data_name
            x_type = data.data_type
            size = data.data_size
            chart_data_list.append(ChartData(x_name=x_name, x_type=x_type, value=size))
        return chart_data_list

        # @staticmethod
        # def data2chart_dic(data_list, chart_type, table_name, stack="stack", **kwargs):
        #     chart_data_list = DataStat._list2chart_data_list(data_list)
        #     js_chart = ChartData.transform2chart(chart_data_list, chart_type, table_name, stack, **kwargs)
        #     return js_chart.format2dic()


class RawDataAllRegionStat(DataStat):
    chart_type = "bar"
    table_name = "Raw Data Space Statistic"
    jump_rule = "series_name"

    def __init__(self, region, version, size):
        DataStat.__init__(self, data_name=version, data_type=region, data_size=size)

    @staticmethod
    def data2chart_dic(raw_data_list):
        chart_data_list = DataStat._list2chart_data_list(raw_data_list)
        js_chart = ChartData.transform2chart(chart_data_list, RawDataAllRegionStat.chart_type,
                                             RawDataAllRegionStat.table_name, jump_rule=RawDataAllRegionStat.jump_rule)
        return js_chart.format2dic()


class PBFAllRegionStat(DataStat):
    chart_type = "bar"
    table_name = "PBF All Region Space Statistic"
    jump_rule = "series_name"

    def __init__(self, region, version, size):
        DataStat.__init__(self, data_name=version, data_type=region, data_size=size)

    @staticmethod
    def data2chart_dic(pbf_list):
        chart_data_list = DataStat._list2chart_data_list(pbf_list)
        js_chart = ChartData.transform2chart(chart_data_list, PBFAllRegionStat.chart_type, PBFAllRegionStat.table_name,
                                             jump_rule=PBFAllRegionStat.jump_rule)
        return js_chart.format2dic()


class RawDataRegionStat(DataStat):
    chart_type = "line"
    table_name = "Raw Data Region:{region} Space Statistic"
    jump_rule = "name"

    def __init__(self, version, data_type, size):
        DataStat.__init__(self, data_name=version, data_size=size, data_type=data_type)

    @staticmethod
    def data2chart_dict(raw_data_data_list, region):
        chart_data_list = DataStat._list2chart_data_list(raw_data_data_list)

        js_chart = ChartData.transform2chart(chart_data_list, PBFRegionStat.chart_type,
                                             PBFRegionStat.table_name.format(region=region), stack="",
                                             jump_rule=RawDataRegionStat.jump_rule)
        return js_chart.format2dic()


class PBFRegionStat(DataStat):
    chart_type = "line"
    table_name = "PBF Region:{region} Space Statistic"
    jump_rule = "name"

    def __init__(self, version, data_type, size):
        DataStat.__init__(self, data_name=version, data_type=data_type, data_size=size)

    @staticmethod
    def data2chart_dic(pbf_region_data_list, region):
        chart_data_list = DataStat._list2chart_data_list(pbf_region_data_list)

        js_chart = ChartData.transform2chart(chart_data_list, PBFRegionStat.chart_type,
                                             PBFRegionStat.table_name.format(region=region), stack="",
                                             jump_rule=PBFRegionStat.jump_rule)
        return js_chart.format2dic()


class PBFSubDataStat(DataStat):
    chart_type = "line"
    table_name = "PBF Data[{data_name}] Detail Space Statistic"

    def __init__(self, data_type, data_time, size):
        DataStat.__init__(self, data_name=data_time, data_type=data_type, data_size=size)

    @staticmethod
    def data2chart_dic(pbf_data_list, data_name):
        chart_data_list = DataStat._list2chart_data_list(pbf_data_list)
        js_chart = ChartData.transform2chart(chart_data_list, PBFSubDataStat.chart_type,
                                             PBFSubDataStat.table_name.format(data_name=data_name))
        return js_chart.format2dic()

    @staticmethod
    def choose_max_size_pbf_data(pbf_data_list):
        """Choose max size pbf data of each type"""
        [].sort()
        pbf_data_list.sort(key=lambda d: d.data_size)
        type_pbf_data_dic = {}
        for pbf_data in pbf_data_list:
            data_type = pbf_data.data_type
            type_pbf_data_dic[data_type] = pbf_data
        return type_pbf_data_dic


class RawDataComponentStat(DataStat):
    chart_type = "bar"
    table_name = "{data_name} Components Statistic"

    def __init__(self, component_name, data_type, size):
        DataStat.__init__(self, data_name=data_type, data_type=component_name, data_size=size)

    @staticmethod
    def data2chart_dict(data_list, data_name):
        chart_data_list = DataStat._list2chart_data_list(data_list)
        js_chart = ChartData.transform2chart(chart_data_list, RawDataComponentStat.chart_type,
                                             RawDataComponentStat.table_name.format(data_name=data_name), stack="")
        return js_chart.format2dic()


class StatisticJsonReader(object):
    @staticmethod
    def read_raw_statistic_file(statistic_file_path):
        with open(statistic_file_path, "r") as f:
            data_json_list = json.load(f)
            data_json_list.sort(key=lambda d: d["version"])
            data_json_list.sort(key=lambda d: d["region"])
            # TODO remove same region same version data
            raw_data_all_region_data_list = []
            raw_data_region_name_data_list_dic = {}
            raw_data_name_component_list_dic = {}
            for raw_data in data_json_list:
                region = raw_data["region"]
                version = raw_data["version"]
                data_size = raw_data["size"]
                components = raw_data["component_list"]
                raw_data_all_region_data_list.append(RawDataAllRegionStat(region=region, version=version, size=data_size))
                raw_data_region_name_data_list_dic.setdefault(region, []).append(
                    RawDataRegionStat(version=version, data_type=region, size=data_size))
                component_list = []
                for component in components:
                    component_name = component["name"]
                    component_size = component["size"]
                    component_list.append(RawDataComponentStat(component_name=component_name, data_type=region, size=component_size))
                    raw_data_name = StatisticJsonReader.generate_data_name(region, version)
                    raw_data_name_component_list_dic[raw_data_name] = component_list

            return raw_data_all_region_data_list, raw_data_region_name_data_list_dic, raw_data_name_component_list_dic

    @staticmethod
    def generate_data_name(region, version):
        return "{region}#{version}".format(region=region, version=version)

    @staticmethod
    def read_pbf_statistic_file(pbf_statistic_file):
        """From Statistic json file, parse get statistic information of all region
        And get all part data size in each pbf path
        """
        with open(pbf_statistic_file, "r") as f:
            data_json_list = json.load(f)
            data_json_list.sort(key=lambda d: d["version"])
            data_json_list.sort(key=lambda d: d["region"])

            pbf_all_region_data_list = []
            pbf_region_name_data_list_dic = {}
            pbf_name_sub_data_list_dic = {}

            for data in data_json_list:
                region = data["region"]
                version = data["version"]
                data_size = data["size"]
                pbf_data_list = data["data_list"]

                pbf_all_region_data_list.append(PBFAllRegionStat(region=region, version=version, size=data_size))

                data_list = []
                for pbf_data in pbf_data_list:
                    data_type = pbf_data["data_type"]
                    data_time = pbf_data["data_time"]
                    data_size = pbf_data["data_size"]
                    if not data_type or not data_time:
                        continue

                    data_list.append(PBFSubDataStat(data_type=data_type, data_time=data_time, size=data_size))

                pbf_name = StatisticJsonReader.generate_data_name(region, version)
                pbf_name_sub_data_list_dic[pbf_name] = data_list
                # choose max of every type(TEST,RC,DEV) in this data list
                region_max_type_data_list = PBFSubDataStat.choose_max_size_pbf_data(data_list).values()
                for type_max_data in region_max_type_data_list:
                    pbf_region_data = PBFRegionStat(version=version, data_type=type_max_data.data_type,
                                                    size=type_max_data.data_size)
                    pbf_region_name_data_list_dic.setdefault(region, []).append(pbf_region_data)

            return pbf_all_region_data_list, pbf_region_name_data_list_dic, pbf_name_sub_data_list_dic


REGIONS_VARIABLE_NAME = "regions"
RAW_JS_OUTPUT_PATH = os.path.join(ROOT_PATH, "js_output", "raw")
PBF_JS_OUTPUT_PATH = os.path.join(ROOT_PATH, "js_output", "pbf")
# RAW_REGIONS_JS_FILE_PATH = os.path.join(JS_OUTPUT_PATH, "raw_cn_regions.js")
# PBF_REGION_JS_FILE_PATH = os.path.join(JS_OUTPUT_PATH, "pbf_cn_region.js")
OUT_PUT_JS_FILENAME = "info.js"

JS_RESOURCE_PATH = os.path.join(ROOT_PATH, "js_resource", "js")
HTML_TEMPLATE_FILE_PATH = os.path.join(ROOT_PATH, "js_resource", "index.html")


class JSUtils(object):
    @staticmethod
    def copy_js_resource(des_path):
        """
        index.html to this path;
        js to its`parent path
        :param des_path:
        :return:
        """
        html_file_name = os.path.basename(HTML_TEMPLATE_FILE_PATH)
        html_file_des_path = os.path.join(des_path, html_file_name)
        if os.path.exists(html_file_des_path):
            os.remove(html_file_des_path)
        js_source_des_path = os.path.join(os.path.dirname(des_path), os.path.basename(JS_RESOURCE_PATH))
        if os.path.exists(js_source_des_path):
            shutil.rmtree(js_source_des_path)
        # copy
        shutil.copy(HTML_TEMPLATE_FILE_PATH, des_path)
        shutil.copytree(JS_RESOURCE_PATH, js_source_des_path)

    @staticmethod
    def save_parse_result(output_file_path, chart_dic_function, **kwargs):
        js_chart_dic = chart_dic_function(**kwargs)
        JSUtils.save_dic2js(file_name=output_file_path, data_dic=js_chart_dic)

    @staticmethod
    def save_dic2js(file_name, data_dic):
        if not os.path.exists(os.path.dirname(file_name)):
            os.makedirs(os.path.dirname(file_name))
        # copy js resource
        JSUtils.copy_js_resource(os.path.dirname(file_name))
        with open(file_name, "w") as f:
            for key, content in data_dic.iteritems():
                json_content = json.dumps(content, ensure_ascii=False)
                f.write("var {variable_name}={content};\n".format(variable_name=key, content=json_content))
            f.close()

    @staticmethod
    def generate_raw_all_regions(raw_data_list):
        output_js_file_path = os.path.join(RAW_JS_OUTPUT_PATH, OUT_PUT_JS_FILENAME)
        JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                  chart_dic_function=RawDataAllRegionStat.data2chart_dic, raw_data_list=raw_data_list)

    @staticmethod
    def generate_pbf_all_regions(pbf_list):
        output_js_file_path = os.path.join(PBF_JS_OUTPUT_PATH, OUT_PUT_JS_FILENAME)
        JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                  chart_dic_function=PBFAllRegionStat.data2chart_dic, pbf_list=pbf_list)

    @staticmethod
    def generate_raw_signal_region(region_name_data_list_dic):
        for region_name, data_list in region_name_data_list_dic.iteritems():
            output_js_file_path = os.path.join(RAW_JS_OUTPUT_PATH, region_name, OUT_PUT_JS_FILENAME)
            JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                      chart_dic_function=RawDataRegionStat.data2chart_dict,
                                      raw_data_data_list=data_list, region=region_name)

    @staticmethod
    def generate_pbf_single_region(pbf_region_name_data_list_dic):
        for region_name, data_list in pbf_region_name_data_list_dic.iteritems():
            output_js_file_path = os.path.join(PBF_JS_OUTPUT_PATH, region_name, OUT_PUT_JS_FILENAME)
            JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                      chart_dic_function=PBFRegionStat.data2chart_dic,
                                      pbf_region_data_list=data_list, region=region_name)

    @staticmethod
    def generate_raw_components(name_components_list_dic):
        for name, components_list in name_components_list_dic.iteritems():
            region, version = name.split("#")
            output_js_file_path = os.path.join(RAW_JS_OUTPUT_PATH, region, version, OUT_PUT_JS_FILENAME)
            JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                      chart_dic_function=RawDataComponentStat.data2chart_dict,
                                      data_list=components_list, data_name=name)

    @staticmethod
    def generate_pbf_sub_data_list(pbf_name_sub_data_list_dic):
        """

        :param pbf_name_sub_data_list_dic:
        :return:
        """
        for pbf_name, sub_data_list in pbf_name_sub_data_list_dic.iteritems():
            region, version = pbf_name.split("#")
            output_js_file_path = os.path.join(PBF_JS_OUTPUT_PATH, region, version, OUT_PUT_JS_FILENAME)
            JSUtils.save_parse_result(output_file_path=output_js_file_path,
                                      chart_dic_function=PBFSubDataStat.data2chart_dic,
                                      pbf_data_list=sub_data_list, data_name=pbf_name)


def test_generate_regions_stat():
    all_region_data_list, region_name_data_list_dic, name_component_list_dic = (
        StatisticJsonReader.read_raw_statistic_file(raw_data_statistic_file_path))
    JSUtils.generate_raw_all_regions(all_region_data_list)
    JSUtils.generate_raw_signal_region(region_name_data_list_dic)
    JSUtils.generate_raw_components(name_component_list_dic)


def test_generate_pbf_js():
    all_region_data_list, region_data_list_dic, pbf_name_sub_data_list_dic = (
        StatisticJsonReader.read_pbf_statistic_file(pbf_statistic_file_path))
    JSUtils.generate_pbf_all_regions(all_region_data_list)
    JSUtils.generate_pbf_single_region(region_data_list_dic)
    JSUtils.generate_pbf_sub_data_list(pbf_name_sub_data_list_dic)


if __name__ == '__main__':
    test_generate_regions_stat()
    test_generate_pbf_js()
