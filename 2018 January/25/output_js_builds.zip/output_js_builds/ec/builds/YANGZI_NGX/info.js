var regions_series=[{"data": [12228894828, 17512931147, 38758557991], "type": "bar", "name": "CN", "stack": "stack"}];
var table_title="PBF All Region Space Statistic";
var regions_legend=["CN"];
var regions_x=["15Q4", "16Q2", "17Q2"];
var kwargs={"jump_rule": "series_name"};
