var regions_series=[{"data": [32146338272, 38758557991, 36955722538], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q2] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170919103814", "20171025140715", "20171201141526"];
var kwargs={};
