var regions_series=[{"data": [17512931147, 17505821203, 11993460226, 11993451762, 12008281505, 12118271488, 14976533654], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q2] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170122202601", "20170124191230", "20170213215620", "20170215183002", "20170228134954", "20170310144140", "20170505155503"];
var kwargs={};
