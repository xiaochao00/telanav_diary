var regions_series=[{"data": [12228894828, 10099123254, 10357268725, 10297339845, 10304161524, 10304300014], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#15Q4] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20161201213134", "20161202230920", "20170122170124", "20170213102807", "20170213215420", "20170215174745"];
var kwargs={};
