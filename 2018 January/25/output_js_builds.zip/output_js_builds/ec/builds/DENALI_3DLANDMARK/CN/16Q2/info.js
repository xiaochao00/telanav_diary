var regions_series=[{"data": [628078087, 0, 0, 0, 0, 0, 0, 0, 0], "type": "bar", "name": "TEST", "stack": "stack"}, {"data": [0, 919719518, 293458673, 293456511, 293457932, 293457846, 293458037, 1429, 293457910], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q2] Detail Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["20161124144156", "20170125153211", "20170310155212", "20170510093254", "20170511120011", "20170511142910", "20170515105236", "20170522184436", "20170523103414"];
var kwargs={};
