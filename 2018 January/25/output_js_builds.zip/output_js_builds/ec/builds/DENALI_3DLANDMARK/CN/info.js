var regions_series=[{"data": [305013807, 628078087, 0, 0, 0, 266776010], "type": "line", "name": "TEST"}, {"data": [305018161, 919719518, 293734824, 293429886, 304615118, 266799961], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["15Q4", "16Q2", "16Q3", "16Q4", "17Q1", "17Q2"];
var kwargs={"jump_rule": "name"};
