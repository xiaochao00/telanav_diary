var regions_series=[{"data": [0, 0, 0, 0, 305013807], "type": "bar", "name": "TEST", "stack": "stack"}, {"data": [305018161, 305017447, 305017747, 305017336, 0], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#15Q4] Detail Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["20170222200232", "20170224180729", "20170313113110", "20170315163839", "20170420155818"];
var kwargs={};
