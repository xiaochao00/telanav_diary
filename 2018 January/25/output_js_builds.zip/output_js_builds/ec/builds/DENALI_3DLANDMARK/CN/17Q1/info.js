var regions_series=[{"data": [304614787, 304609676, 304614565, 304615118], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q1] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170628150735", "20171103140603", "20171107164919", "20180122125636"];
var kwargs={};
