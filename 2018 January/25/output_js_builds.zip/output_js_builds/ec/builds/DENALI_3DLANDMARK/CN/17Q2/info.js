var regions_series=[{"data": [266776010, 0, 0, 0, 0, 0], "type": "bar", "name": "TEST", "stack": "stack"}, {"data": [0, 266798922, 266795531, 266799410, 266799961, 266799248], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q2] Detail Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["20170915170327", "20171120120242", "20171120160459", "20171123103913", "20171123104517", "20171123131808"];
var kwargs={};
