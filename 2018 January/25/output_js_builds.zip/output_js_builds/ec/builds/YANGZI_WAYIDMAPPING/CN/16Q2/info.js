var regions_series=[{"data": [2952951202, 2952951241, 2952951199], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q2] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170505154058", "20170505154911", "20170505155239"];
var kwargs={};
