var regions_series=[{"data": [2952951241], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["RC"];
var regions_x=["16Q2"];
var kwargs={"jump_rule": "name"};
