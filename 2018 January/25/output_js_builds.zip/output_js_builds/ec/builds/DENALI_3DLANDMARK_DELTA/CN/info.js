var regions_series=[{"data": [5612, 0, 0], "type": "line", "name": "TEST"}, {"data": [0, 15510211, 6439468], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["16Q2", "16Q3", "16Q4"];
var kwargs={"jump_rule": "name"};
