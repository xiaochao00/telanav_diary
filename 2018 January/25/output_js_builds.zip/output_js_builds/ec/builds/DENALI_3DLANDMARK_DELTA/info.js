var regions_series=[{"data": [5612, 15510211, 6439468], "type": "bar", "name": "CN", "stack": "stack"}];
var table_title="PBF All Region Space Statistic";
var regions_legend=["CN"];
var regions_x=["16Q2", "16Q3", "16Q4"];
var kwargs={"jump_rule": "series_name"};
