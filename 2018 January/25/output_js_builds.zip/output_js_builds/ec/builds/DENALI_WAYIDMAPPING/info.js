var regions_series=[{"data": [2876705711, 3239050951, 3245968081, 3514563275, 3491403026, 3824152525], "type": "bar", "name": "CN", "stack": "stack"}];
var table_title="PBF All Region Space Statistic";
var regions_legend=["CN"];
var regions_x=["16Q2", "16Q3", "16Q4", "17Q1", "17Q2", "17Q3"];
var kwargs={"jump_rule": "series_name"};
