var regions_series=[{"data": [3491403026, 3491403014], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q2] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20171120095632", "20171123104816"];
var kwargs={};
