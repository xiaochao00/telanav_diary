var regions_series=[{"data": [3364698612, 3364695318, 3514563275, 3364700137, 3364700099], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q1] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170628131050", "20171103112658", "20171130142006", "20171222104024", "20180122110211"];
var kwargs={};
