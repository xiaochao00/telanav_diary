var regions_series=[{"data": [3824152525], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q3] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20180108140336"];
var kwargs={};
