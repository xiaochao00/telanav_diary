var regions_series=[{"data": [3245968081], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q4] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170830164538"];
var kwargs={};
