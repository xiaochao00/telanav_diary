var regions_series=[{"data": [3239050951, 2948397455], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q3] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170516162520", "20170802185320"];
var kwargs={};
