var regions_series=[{"data": [2876705711], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q2] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170523100552"];
var kwargs={};
