var regions_series=[{"data": [2449, 6328449514, 9239401092, 3624333944, 5241711633, 6706026487], "type": "bar", "name": "CN", "stack": "stack"}];
var table_title="PBF All Region Space Statistic";
var regions_legend=["CN"];
var regions_x=["16Q2", "16Q3", "16Q4", "17Q1", "17Q2", "17Q3"];
var kwargs={"jump_rule": "series_name"};
