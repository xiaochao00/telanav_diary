var regions_series=[{"data": [3624333944], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q1] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20171130200911"];
var kwargs={};
