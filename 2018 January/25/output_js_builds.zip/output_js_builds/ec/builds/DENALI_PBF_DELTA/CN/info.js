var regions_series=[{"data": [2449, 0, 0, 0, 0, 0], "type": "line", "name": "TEST"}, {"data": [0, 6328449514, 9239401092, 3624333944, 5241711633, 6706026487], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["16Q2", "16Q3", "16Q4", "17Q1", "17Q2", "17Q3"];
var kwargs={"jump_rule": "name"};
