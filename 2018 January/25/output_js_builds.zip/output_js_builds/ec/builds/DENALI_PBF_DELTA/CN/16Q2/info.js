var regions_series=[{"data": [2096, 2449], "type": "bar", "name": "TEST", "stack": "stack"}];
var table_title="PBF Data[CN#16Q2] Detail Space Statistic";
var regions_legend=["TEST"];
var regions_x=["20170426112952", "20170426150031"];
var kwargs={};
