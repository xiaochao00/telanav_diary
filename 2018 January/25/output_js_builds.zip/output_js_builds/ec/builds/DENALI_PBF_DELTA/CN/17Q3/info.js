var regions_series=[{"data": [6706026487], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q3] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20171117204923"];
var kwargs={};
