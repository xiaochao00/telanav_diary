var regions_series=[{"data": [3761, 6328449514, 6328449229], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q3] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170505113847", "20170609175432", "20170711175319"];
var kwargs={};
