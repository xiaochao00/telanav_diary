var regions_series=[{"data": [0, 0, 0, 10472253588], "type": "bar", "name": "TEST", "stack": "stack"}, {"data": [9103073416, 10469934905, 10472230774, 0], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#15Q4] Detail Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["20170313113112", "20170313204518", "20170315163841", "20170420155820"];
var kwargs={};
