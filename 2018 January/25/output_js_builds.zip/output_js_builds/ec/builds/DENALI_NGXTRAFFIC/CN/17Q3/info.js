var regions_series=[{"data": [13587849499], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q3] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20180108180851"];
var kwargs={};
