var regions_series=[{"data": [12325974358, 10540200793, 10539950617, 15741748482, 13697199877, 14547616448], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q2] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170310155214", "20170510093257", "20170511120014", "20170511142912", "20170515105238", "20170523103416"];
var kwargs={};
