var regions_series=[{"data": [10472253588, 550998779, 0, 0, 0, 0, 0, 0], "type": "line", "name": "TEST"}, {"data": [10472230774, 0, 15741748482, 24985284505, 13574820041, 18609084699, 21015092424, 13587849499], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["15Q4", "16Q1", "16Q2", "16Q3", "16Q4", "17Q1", "17Q2", "17Q3"];
var kwargs={"jump_rule": "name"};
