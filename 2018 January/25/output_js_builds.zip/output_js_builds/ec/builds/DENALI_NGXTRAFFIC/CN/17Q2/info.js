var regions_series=[{"data": [8941984162, 20985307383, 14259390522, 21015092424], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q2] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20171120120244", "20171120160501", "20171123103914", "20171123131810"];
var kwargs={};
