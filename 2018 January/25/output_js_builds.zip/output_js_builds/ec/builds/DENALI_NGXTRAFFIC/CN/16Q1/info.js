var regions_series=[{"data": [550998779, 1388], "type": "bar", "name": "TEST", "stack": "stack"}];
var table_title="PBF Data[CN#16Q1] Detail Space Statistic";
var regions_legend=["TEST"];
var regions_x=["20170302103832", "20170302110212"];
var kwargs={};
