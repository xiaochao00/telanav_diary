var regions_series=[{"data": [24985284505, 19368833096, 19244565651, 15110540865], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q3] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170426150836", "20170503134557", "20170525161444", "20170802200514"];
var kwargs={};
