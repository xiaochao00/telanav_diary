var regions_series=[{"data": [0, 0, 0, 1954], "type": "bar", "name": "TEST", "stack": "stack"}, {"data": [37368330560, 37580018009, 53681760674, 0], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q1] Detail Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["20170831181917", "20171101181040", "20171106173259", "20171107152416"];
var kwargs={};
