var regions_series=[{"data": [0, 20572020388], "type": "bar", "name": "DEV", "stack": "stack"}, {"data": [41528567548, 0], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q3] Detail Space Statistic";
var regions_legend=["DEV", "RC"];
var regions_x=["20171112150026", "20180112105105"];
var kwargs={};
