var regions_series=[{"data": [0, 0, 0, 0, 1954, 47972393, 0], "type": "line", "name": "TEST"}, {"data": [0, 0, 0, 0, 0, 0, 20572020388], "type": "line", "name": "DEV"}, {"data": [27050742844, 34823520710, 34745406528, 36796749707, 53681760674, 38857452270, 41528567548], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["TEST", "DEV", "RC"];
var regions_x=["15Q4", "16Q1", "16Q3", "16Q4", "17Q1", "17Q2", "17Q3"];
var kwargs={"jump_rule": "name"};
