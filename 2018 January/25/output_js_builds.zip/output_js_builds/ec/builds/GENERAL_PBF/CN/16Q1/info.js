var regions_series=[{"data": [29634355281, 34823520710, 34808832637], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q1] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20161209171351", "20161228183529", "20170119183327"];
var kwargs={};
