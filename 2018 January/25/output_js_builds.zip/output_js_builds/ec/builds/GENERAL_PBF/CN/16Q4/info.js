var regions_series=[{"data": [36773922180, 36796749707, 36791067964], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q4] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170629152249", "20170824185903", "20170927203259"];
var kwargs={};
