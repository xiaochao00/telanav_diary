var regions_series=[{"data": [34744034403, 34743571430, 34745406528], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q3] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170606100751", "20170719133435", "20170801135217"];
var kwargs={};
