var regions_series=[{"data": [0, 0, 47635088, 47972393, 47971995], "type": "bar", "name": "TEST", "stack": "stack"}, {"data": [38702884943, 38857452270, 0, 0, 0], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q2] Detail Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["20170823162512", "20171027100946", "20171120153133", "20171120161430", "20171120173655"];
var kwargs={};
