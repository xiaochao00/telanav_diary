var regions_series=[];
var table_title="PBF Data[CN#16Q2] Detail Space Statistic";
var regions_legend=[];
var regions_x=[];
var kwargs={};
