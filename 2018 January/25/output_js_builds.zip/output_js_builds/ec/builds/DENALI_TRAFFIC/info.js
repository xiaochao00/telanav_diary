var regions_series=[{"data": [138083665], "type": "bar", "name": "CN", "stack": "stack"}];
var table_title="PBF All Region Space Statistic";
var regions_legend=["CN"];
var regions_x=["15Q4"];
var kwargs={"jump_rule": "series_name"};
