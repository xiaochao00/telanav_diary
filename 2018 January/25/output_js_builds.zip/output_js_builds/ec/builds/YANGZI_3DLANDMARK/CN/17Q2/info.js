var regions_series=[{"data": [0, 0, 257156606, 0], "type": "bar", "name": "TEST", "stack": "stack"}, {"data": [257155744, 257153432, 0, 257153650], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q2] Detail Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["20170828155943", "20170919103812", "20171018155356", "20171025140713"];
var kwargs={};
