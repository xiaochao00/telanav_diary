var regions_series=[{"data": [293437494, 293437804, 293457577, 293458398, 293459027, 293458200, 293458276], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q2] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170122202558", "20170124191228", "20170213215618", "20170215183000", "20170228134951", "20170310144138", "20170505155501"];
var kwargs={};
