var regions_series=[{"data": [0, 0, 257156606], "type": "line", "name": "TEST"}, {"data": [293744754, 293459027, 257155744], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["15Q4", "16Q2", "17Q2"];
var kwargs={"jump_rule": "name"};
