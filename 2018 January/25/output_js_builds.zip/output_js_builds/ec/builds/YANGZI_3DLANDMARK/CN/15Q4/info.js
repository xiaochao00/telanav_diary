var regions_series=[{"data": [293727310, 1429, 293727816, 293728631, 293743920, 293744754], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#15Q4] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20161202180657", "20170122153229", "20170122170122", "20170213102805", "20170213215417", "20170215174742"];
var kwargs={};
