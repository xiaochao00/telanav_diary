var regions_series=[{"data": [984223452, 99222832, 118564567], "type": "bar", "name": "CN", "stack": "stack"}];
var table_title="PBF All Region Space Statistic";
var regions_legend=["CN"];
var regions_x=["15Q4", "16Q2", "17Q2"];
var kwargs={"jump_rule": "series_name"};
