var regions_series=[{"data": [118562789, 118564567, 1424, 112891178, 116772471, 116508238, 113545535, 113279974], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q2] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170919163022", "20171025200231", "20171121112641", "20171121112828", "20171201194849", "20171204143011", "20180103104201", "20180103142039"];
var kwargs={};
