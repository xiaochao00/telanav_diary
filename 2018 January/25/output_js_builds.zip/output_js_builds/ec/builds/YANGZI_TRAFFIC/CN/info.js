var regions_series=[{"data": [984223333, 53148900, 0], "type": "line", "name": "TEST"}, {"data": [984223452, 99222832, 118564567], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["15Q4", "16Q2", "17Q2"];
var kwargs={"jump_rule": "name"};
