var regions_series=[{"data": [0, 91940251, 984223333, 0, 0, 0, 0], "type": "bar", "name": "TEST", "stack": "stack"}, {"data": [41851104, 0, 0, 984223452, 91987326, 91983680, 91983679], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#15Q4] Detail Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["20161202160100", "20170112163350", "20170112171524", "20170123135711", "20170213125653", "20170214002709", "20170215214455"];
var kwargs={};
