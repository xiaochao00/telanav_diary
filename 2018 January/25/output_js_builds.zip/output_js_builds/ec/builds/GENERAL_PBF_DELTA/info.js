var regions_series=[{"data": [6328448039, 19248352697], "type": "bar", "name": "CN", "stack": "stack"}];
var table_title="PBF All Region Space Statistic";
var regions_legend=["CN"];
var regions_x=["16Q3", "17Q1"];
var kwargs={"jump_rule": "series_name"};
