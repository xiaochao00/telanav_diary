var regions_series=[{"data": [8477507609, 19248352697], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q1] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["171107", "171221"];
var kwargs={};
