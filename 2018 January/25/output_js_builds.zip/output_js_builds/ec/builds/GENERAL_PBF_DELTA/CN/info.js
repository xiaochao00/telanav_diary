var regions_series=[{"data": [6328448039, 19248352697], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["RC"];
var regions_x=["16Q3", "17Q1"];
var kwargs={"jump_rule": "name"};
