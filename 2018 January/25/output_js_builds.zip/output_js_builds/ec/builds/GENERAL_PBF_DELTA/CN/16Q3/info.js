var regions_series=[{"data": [6305752082, 6305837846, 6327659368, 6328448039], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q3] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170405195413", "20170424221019", "20170511182921", "20170514112717"];
var kwargs={};
