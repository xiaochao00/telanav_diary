var regions_series=[{"data": [29616317642], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q4] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20180115172027"];
var kwargs={};
