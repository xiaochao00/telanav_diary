var regions_series=[{"data": [1722, 1951, 1950, 135925926], "type": "bar", "name": "TEST", "stack": "stack"}];
var table_title="PBF Data[CN#17Q1] Detail Space Statistic";
var regions_legend=["TEST"];
var regions_x=["20171116171051", "20171116171728", "20171116173942", "20171116174155"];
var kwargs={};
