var regions_series=[{"data": [0, 135925926, 761094918, 0], "type": "line", "name": "TEST"}, {"data": [0, 0, 0, 29616317642], "type": "line", "name": "RC"}, {"data": [32482438375, 0, 0, 0], "type": "line", "name": "rc"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["TEST", "RC", "rc"];
var regions_x=["16Q2", "17Q1", "17Q2", "17Q4"];
var kwargs={"jump_rule": "name"};
