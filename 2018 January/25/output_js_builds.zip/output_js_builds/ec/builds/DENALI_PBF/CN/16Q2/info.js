var regions_series=[{"data": [32482438375], "type": "bar", "name": "rc", "stack": "stack"}];
var table_title="PBF Data[CN#16Q2] Detail Space Statistic";
var regions_legend=["rc"];
var regions_x=["033603"];
var kwargs={};
