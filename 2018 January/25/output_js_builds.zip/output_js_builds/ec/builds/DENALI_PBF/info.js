var regions_series=[{"data": [32482438375, 135925926, 761094918, 29616317642], "type": "bar", "name": "CN", "stack": "stack"}];
var table_title="PBF All Region Space Statistic";
var regions_legend=["CN"];
var regions_x=["16Q2", "17Q1", "17Q2", "17Q4"];
var kwargs={"jump_rule": "series_name"};
