var regions_series=[{"data": [573033720, 1913], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#15Q4] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20161216173644", "20161223125044"];
var kwargs={};
