var regions_series=[{"data": [573033720], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["RC"];
var regions_x=["15Q4"];
var kwargs={"jump_rule": "name"};
