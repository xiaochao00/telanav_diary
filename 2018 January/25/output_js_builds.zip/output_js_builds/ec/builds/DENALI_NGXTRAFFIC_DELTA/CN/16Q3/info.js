var regions_series=[{"data": [11669144158, 10858457964, 20786532335, 11668881850, 12186507700, 13811916893, 13810127054], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q3] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170531140855", "20170605113057", "20170609195203", "20170612171058", "20170714112022", "20171207194032", "20180109175715"];
var kwargs={};
