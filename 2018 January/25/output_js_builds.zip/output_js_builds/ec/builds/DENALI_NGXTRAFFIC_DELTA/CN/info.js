var regions_series=[{"data": [2143, 0, 0, 0], "type": "line", "name": "TEST"}, {"data": [0, 20786532335, 33113799880, 58060673281], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["16Q2", "16Q3", "16Q4", "17Q1"];
var kwargs={"jump_rule": "name"};
