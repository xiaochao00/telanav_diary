var regions_series=[{"data": [2143, 2143], "type": "bar", "name": "TEST", "stack": "stack"}];
var table_title="PBF Data[CN#16Q2] Detail Space Statistic";
var regions_legend=["TEST"];
var regions_x=["20170426184241", "20170426184922"];
var kwargs={};
