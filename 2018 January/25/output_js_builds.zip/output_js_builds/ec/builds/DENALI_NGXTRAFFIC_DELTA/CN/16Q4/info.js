var regions_series=[{"data": [33113799880, 14311428807, 22443982679, 15146685389, 15134246666], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#16Q4] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170905104817", "20170905190712", "20171009150737", "20171208105615", "20180110092514"];
var kwargs={};
