var regions_series=[{"data": [2143, 20786532335, 33113799880, 58060673281], "type": "bar", "name": "CN", "stack": "stack"}];
var table_title="PBF All Region Space Statistic";
var regions_legend=["CN"];
var regions_x=["16Q2", "16Q3", "16Q4", "17Q1"];
var kwargs={"jump_rule": "series_name"};
