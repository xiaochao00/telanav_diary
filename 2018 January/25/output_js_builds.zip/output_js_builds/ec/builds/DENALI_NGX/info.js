var regions_series=[];
var table_title="PBF All Region Space Statistic";
var regions_legend=[];
var regions_x=[];
var kwargs={"jump_rule": "series_name"};
