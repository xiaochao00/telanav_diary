var regions_series=[{"data": [0, 0, 146884792], "type": "line", "name": "DEV", "stack": "stack"}, {"data": [135547064, 134465720, 152520888], "type": "line", "name": "RC", "stack": "stack"}];
var table_title="Region:CN_Level0 Unidb Database Statistic";
var regions_legend=["DEV", "RC"];
var regions_x=["15Q3", "16Q1", "17Q2"];
var kwargs={};
