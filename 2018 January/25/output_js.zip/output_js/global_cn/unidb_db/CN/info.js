var regions_series=[{"data": [0, 0, 0, 142755023032, 145158359224], "type": "line", "name": "DEV", "stack": "stack"}, {"data": [137568045240, 109131745464, 140684347576, 152630741176, 0], "type": "line", "name": "RC", "stack": "stack"}];
var table_title="Region:CN Unidb Database Statistic";
var regions_legend=["DEV", "RC"];
var regions_x=["15Q3", "16Q1", "17Q1", "17Q2", "17Q3"];
var kwargs={};
