var regions_series=[{"data": [137568045240, 109131745464, 140684347576, 152630741176, 145158359224], "type": "bar", "name": "CN", "stack": "stack"}, {"data": [135547064, 134465720, 0, 152520888, 0], "type": "bar", "name": "CN_Level0", "stack": "stack"}];
var table_title="Unidb Database Statistic";
var regions_legend=["CN", "CN_Level0"];
var regions_x=["15Q3", "16Q1", "17Q1", "17Q2", "17Q3"];
var kwargs={"jump_rule": "series_name"};
