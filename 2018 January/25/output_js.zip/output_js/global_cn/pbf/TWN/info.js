var regions_series=[{"data": [2354], "type": "line", "name": "TEST"}];
var table_title="PBF Region:TWN Space Statistic";
var regions_legend=["TEST"];
var regions_x=["17Q3"];
var kwargs={"jump_rule": "name"};
