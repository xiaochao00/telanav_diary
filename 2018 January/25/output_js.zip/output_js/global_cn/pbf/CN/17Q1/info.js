var regions_series=[{"data": [25290439923], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#17Q1] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170527125225"];
var kwargs={};
