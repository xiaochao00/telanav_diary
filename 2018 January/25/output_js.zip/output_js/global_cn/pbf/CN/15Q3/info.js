var regions_series=[{"data": [0, 0, 0, 0, 0, 0, 738148352], "type": "bar", "name": "TEST", "stack": "stack"}, {"data": [9384864523, 9389232641, 0, 0, 0, 0, 0], "type": "bar", "name": "DEV", "stack": "stack"}, {"data": [0, 0, 10083825996, 9455087269, 9455107690, 9455089051, 0], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN#15Q3] Detail Space Statistic";
var regions_legend=["TEST", "DEV", "RC"];
var regions_x=["20151204173843", "20151208094401", "20160122101258", "20160317171025", "20160401112057", "20160411222319", "20160503172447"];
var kwargs={};
