var regions_series=[{"data": [18076605], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[CN_Level0#17Q1] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170526170018"];
var kwargs={};
