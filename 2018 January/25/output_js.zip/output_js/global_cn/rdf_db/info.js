var regions_series=[{"data": [187065026744, 198404786360, 272370288824, 288982616248], "type": "bar", "name": "CN", "stack": "stack"}, {"data": [144787640, 141052088, 141543608, 0], "type": "bar", "name": "CN_Level0", "stack": "stack"}];
var table_title="RDF Database Statistic";
var regions_legend=["CN", "CN_Level0"];
var regions_x=["15Q3", "16Q1", "17Q2", "17Q3"];
var kwargs={"jump_rule": "series_name"};
