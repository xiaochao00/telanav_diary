var regions_series=[{"data": [144787640, 141052088, 141543608], "type": "line", "name": "CN_Level0", "stack": "stack"}];
var table_title="Region:CN_Level0 RDF Database Statistic";
var regions_legend=["CN_Level0"];
var regions_x=["15Q3", "16Q1", "17Q2"];
var kwargs={};
