var regions_series=[{"data": [187065026744, 198404786360, 272370288824, 288982616248], "type": "line", "name": "CN", "stack": "stack"}];
var table_title="Region:CN RDF Database Statistic";
var regions_legend=["CN"];
var regions_x=["15Q3", "16Q1", "17Q2", "17Q3"];
var kwargs={};
