var regions_series=[{"data": [2357173450, 6379370, 8403048], "type": "bar", "name": "CN"}];
var table_title="CN#14Q3 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "cn_add_content", "speed_camera"];
var kwargs={"partly": "partly"};
