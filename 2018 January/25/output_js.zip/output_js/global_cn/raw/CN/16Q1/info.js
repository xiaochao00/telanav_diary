var regions_series=[{"data": [3002391761, 8542387, 60564, 12807680000, 925908527], "type": "bar", "name": "CN"}];
var table_title="CN#16Q1 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "cn_add_content", "level2_sensitive", "rdf", "speed_camera"];
var kwargs={"partly": "partly"};
