var regions_series=[{"data": [2697032124, 7846726, 206464, 528072492], "type": "bar", "name": "CN"}];
var table_title="CN#16Q3 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "cn_add_content", "level2_sensitive", "speed_camera"];
var kwargs={"partly": "partly"};
