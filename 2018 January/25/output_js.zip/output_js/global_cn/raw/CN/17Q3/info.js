var regions_series=[{"data": [2218682630, 10519004, 8347463300, 146912, 19377121280, 1266462352, 629493541, 74522963], "type": "bar", "name": "CN"}];
var table_title="CN#17Q3 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "cn_add_content", "junction_view", "level2_sensitive", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
