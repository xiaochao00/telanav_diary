var regions_series=[{"data": [2395777278, 4393420, 4323221], "type": "bar", "name": "CN"}];
var table_title="CN#13Q2 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "cn_add_content", "speed_camera"];
var kwargs={"partly": "partly"};
