var regions_series=[{"data": [3268878652, 10028453, 3939388798, 206554, 17932974080, 1206877132, 633135534, 74522963], "type": "bar", "name": "CN"}];
var table_title="CN#17Q1 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "cn_add_content", "junction_view", "level2_sensitive", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
