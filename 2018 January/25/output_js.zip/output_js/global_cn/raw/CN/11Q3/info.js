var regions_series=[{"data": [372017887, 228348923, 8583845], "type": "bar", "name": "CN"}];
var table_title="CN#11Q3 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "cn_add_content", "speed_camera"];
var kwargs={"partly": "partly"};
