var regions_series=[{"data": [2498794826, 7001014, 60382, 10496020480, 476918361], "type": "bar", "name": "CN"}];
var table_title="CN#15Q1 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "cn_add_content", "level2_sensitive", "rdf", "speed_camera"];
var kwargs={"partly": "partly"};
