var regions_series=[{"data": [1306676243, 4037989, 4768491], "type": "bar", "name": "CN"}];
var table_title="CN#13Q1 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "cn_add_content", "speed_camera"];
var kwargs={"partly": "partly"};
