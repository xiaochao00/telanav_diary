var regions_series=[{"data": [1145617370], "type": "bar", "name": "CN"}];
var table_title="CN#12Q3 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark"];
var kwargs={"partly": "partly"};
