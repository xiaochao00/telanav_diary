var regions_series=[{"data": [2697032124, 7846726, 59343, 11550490112, 528072492], "type": "bar", "name": "CN"}];
var table_title="CN#15Q3 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "cn_add_content", "level2_sensitive", "rdf", "speed_camera"];
var kwargs={"partly": "partly"};
