var regions_series=[{"data": [2697032124, 0], "type": "bar", "name": "CN"}];
var table_title="CN#17Q4 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "speed_camera"];
var kwargs={"partly": "partly"};
