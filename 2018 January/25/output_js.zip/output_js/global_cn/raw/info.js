var regions_series=[{"data": [608950655, 1145617370, 1315482723, 2404493919, 0, 419840, 13478795063, 7378864223, 5970110, 20004651103, 3233157806, 27066012166, 30752638800, 31924411982, 2697032124], "type": "bar", "name": "CN", "stack": "stack"}, {"data": [0, 0, 0, 0, 10699563, 0, 14230814, 14112556, 0, 14201612, 0, 13936135, 13987375, 14028797, 0], "type": "bar", "name": "CN_Level0", "stack": "stack"}];
var table_title="Raw Data Space Statistic";
var regions_legend=["CN", "CN_Level0"];
var regions_x=["11Q3", "12Q3", "13Q1", "13Q2", "14Q1", "14Q3", "15Q1", "15Q3", "15Q4", "16Q1", "16Q3", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={"jump_rule": "series_name"};
