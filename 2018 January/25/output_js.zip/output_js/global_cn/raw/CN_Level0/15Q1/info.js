var regions_series=[{"data": [242974, 13987840], "type": "bar", "name": "CN_Level0"}];
var table_title="CN_Level0#15Q1 Components Statistic";
var regions_legend=["CN_Level0"];
var regions_x=["components", "rdf"];
var kwargs={"partly": "partly"};
