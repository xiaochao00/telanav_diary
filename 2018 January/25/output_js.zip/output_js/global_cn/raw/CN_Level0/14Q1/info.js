var regions_series=[{"data": [256451, 10443112], "type": "bar", "name": "CN_Level0"}];
var table_title="CN_Level0#14Q1 Components Statistic";
var regions_legend=["CN_Level0"];
var regions_x=["components", "rdf"];
var kwargs={"partly": "partly"};
