var regions_series=[{"data": [4218874601, 23257269102, 1561745484, 3221524414, 0, 5881024], "type": "bar", "name": "KOR"}];
var table_title="KOR#17Q3 Components Statistic";
var regions_legend=["KOR"];
var regions_x=["3D_landmark", "junction_view", "new_address", "rdf", "speed_camera", "toll_cost"];
var kwargs={"partly": "partly"};
