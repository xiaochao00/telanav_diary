var regions_series=[{"data": [7104468556, 14453565910, 1552825065, 6258453265, 12335233, 5476691], "type": "bar", "name": "KOR"}];
var table_title="KOR#17Q1 Components Statistic";
var regions_legend=["KOR"];
var regions_x=["3D_landmark", "junction_view", "new_address", "rdf", "speed_camera", "toll_cost"];
var kwargs={"partly": "partly"};
