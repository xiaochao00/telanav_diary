var regions_series=[{"data": [55196459], "type": "bar", "name": "KOR"}];
var table_title="KOR#17Q2 Components Statistic";
var regions_legend=["KOR"];
var regions_x=["rdf"];
var kwargs={"partly": "partly"};
