var regions_series=[{"data": [9096017279, 23889157076, 2027451287, 3787107279, 4675352, 6408966], "type": "bar", "name": "KOR"}];
var table_title="KOR#17Q4 Components Statistic";
var regions_legend=["KOR"];
var regions_x=["3D_landmark", "junction_view", "new_address", "rdf", "speed_camera", "toll_cost"];
var kwargs={"partly": "partly"};
