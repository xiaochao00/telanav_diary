var regions_series=[{"data": [7691398332, 13228629114, 1543981326, 5608915680, 4122826, 4988613], "type": "bar", "name": "KOR"}];
var table_title="KOR#16Q3 Components Statistic";
var regions_legend=["KOR"];
var regions_x=["3D_landmark", "junction_view", "new_address", "rdf", "speed_camera", "toll_cost"];
var kwargs={"partly": "partly"};
