var regions_series=[{"data": [31355887170, 26257948177, 1499314076, 2692641733, 4060358], "type": "bar", "name": "KOR"}];
var table_title="KOR#15Q4 Components Statistic";
var regions_legend=["KOR"];
var regions_x=["3D_landmark", "junction_view", "new_address", "rdf", "speed_camera"];
var kwargs={"partly": "partly"};
