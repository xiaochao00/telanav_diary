var regions_series=[{"data": [61809851514, 28082035891, 0, 29387124720, 55196459, 32265294625, 38810817239], "type": "bar", "name": "KOR", "stack": "stack"}];
var table_title="Raw Data Space Statistic";
var regions_legend=["KOR"];
var regions_x=["15Q4", "16Q3", "16Q4", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={"jump_rule": "series_name"};
