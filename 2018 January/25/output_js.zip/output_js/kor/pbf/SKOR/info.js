var regions_series=[{"data": [4752685412, 5429046823], "type": "line", "name": "DEV"}, {"data": [6753022502, 5574444948], "type": "line", "name": "RC"}];
var table_title="PBF Region:SKOR Space Statistic";
var regions_legend=["DEV", "RC"];
var regions_x=["15Q4", "16Q3"];
var kwargs={"jump_rule": "name"};
