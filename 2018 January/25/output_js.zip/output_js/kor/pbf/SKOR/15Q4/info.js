var regions_series=[{"data": [1439419326, 1948057578, 1713545961, 2041747237, 4684947771, 4752685412, 0, 0], "type": "bar", "name": "DEV", "stack": "stack"}, {"data": [0, 0, 0, 0, 0, 0, 5124868741, 6753022502], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[SKOR#15Q4] Detail Space Statistic";
var regions_legend=["DEV", "RC"];
var regions_x=["20160301022850", "20160301104655", "20160303145335", "20160303174233", "20160307150841", "20160315110559", "20160817115136", "20160819155341"];
var kwargs={};
