var regions_series=[{"data": [5639800174, 6794575706], "type": "line", "name": "DEV"}, {"data": [5631714477, 8647430927], "type": "line", "name": "RC"}];
var table_title="PBF Region:KOR Space Statistic";
var regions_legend=["DEV", "RC"];
var regions_x=["17Q1", "17Q4"];
var kwargs={"jump_rule": "name"};
