var regions_series=[{"data": [6794575706, 0], "type": "bar", "name": "DEV", "stack": "stack"}, {"data": [0, 8647430927], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[KOR#17Q4] Detail Space Statistic";
var regions_legend=["DEV", "RC"];
var regions_x=["20171215193725", "20180109121111"];
var kwargs={};
