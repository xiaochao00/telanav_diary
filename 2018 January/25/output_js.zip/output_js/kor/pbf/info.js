var regions_series=[{"data": [0, 0, 5639800174, 8647430927], "type": "bar", "name": "KOR", "stack": "stack"}, {"data": [6753022502, 5574444948, 0, 0], "type": "bar", "name": "SKOR", "stack": "stack"}];
var table_title="PBF All Region Space Statistic";
var regions_legend=["KOR", "SKOR"];
var regions_x=["15Q4", "16Q3", "17Q1", "17Q4"];
var kwargs={"jump_rule": "series_name"};
