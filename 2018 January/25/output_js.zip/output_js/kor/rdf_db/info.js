var regions_series=[{"data": [43559453188, 44093784580, 46231219988, 56007266068], "type": "bar", "name": "KOR", "stack": "stack"}];
var table_title="RDF Database Statistic";
var regions_legend=["KOR"];
var regions_x=["15Q4", "16Q3", "17Q1", "17Q4"];
var kwargs={"jump_rule": "series_name"};
