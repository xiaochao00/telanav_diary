var regions_series=[{"data": [0, 0, 44729208596, 51307794196], "type": "line", "name": "DEV", "stack": "stack"}, {"data": [82042552836, 43041169924, 49318686484, 51254832916], "type": "line", "name": "RC", "stack": "stack"}];
var table_title="Region:KOR Unidb Database Statistic";
var regions_legend=["DEV", "RC"];
var regions_x=["15Q4", "16Q3", "17Q1", "17Q4"];
var kwargs={};
