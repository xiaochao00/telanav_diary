var regions_series=[{"data": [82042552836, 43041169924, 49318686484, 51307794196], "type": "bar", "name": "KOR", "stack": "stack"}];
var table_title="Unidb Database Statistic";
var regions_legend=["KOR"];
var regions_x=["15Q4", "16Q3", "17Q1", "17Q4"];
var kwargs={"jump_rule": "series_name"};
