var regions_series=[{"data": [37581750788, 38119801348, 40788656644, 41290072580, 42456613380], "type": "line", "name": "ANZ", "stack": "stack"}];
var table_title="Region:ANZ RDF Database Statistic";
var regions_legend=["ANZ"];
var regions_x=["16Q4", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
