var regions_series=[{"data": [825700403384, 1014906724044, 977855422156, 1028434845388, 1050980622028, 1056604430028], "type": "line", "name": "EU", "stack": "stack"}];
var table_title="Region:EU RDF Database Statistic";
var regions_legend=["EU"];
var regions_x=["14Q4", "16Q4", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
