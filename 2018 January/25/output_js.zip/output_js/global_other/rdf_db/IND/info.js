var regions_series=[{"data": [172477252100], "type": "line", "name": "IND", "stack": "stack"}];
var table_title="Region:IND RDF Database Statistic";
var regions_legend=["IND"];
var regions_x=["17Q1"];
var kwargs={};
