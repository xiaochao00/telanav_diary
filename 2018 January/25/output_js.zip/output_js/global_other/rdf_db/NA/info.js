var regions_series=[{"data": [484758127108, 487568343556, 511974507012, 517628577976, 518528172548], "type": "line", "name": "NA", "stack": "stack"}];
var table_title="Region:NA RDF Database Statistic";
var regions_legend=["NA"];
var regions_x=["16Q4", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
