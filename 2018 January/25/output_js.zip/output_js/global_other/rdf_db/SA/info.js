var regions_series=[{"data": [154559676932, 160992199172, 167256556036, 172289950212], "type": "line", "name": "SA", "stack": "stack"}];
var table_title="Region:SA RDF Database Statistic";
var regions_legend=["SA"];
var regions_x=["17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
