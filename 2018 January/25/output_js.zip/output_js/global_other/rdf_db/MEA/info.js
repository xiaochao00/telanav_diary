var regions_series=[{"data": [142941127172, 154083099140, 157046964740, 162547859972], "type": "line", "name": "MEA", "stack": "stack"}];
var table_title="Region:MEA RDF Database Statistic";
var regions_legend=["MEA"];
var regions_x=["17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
