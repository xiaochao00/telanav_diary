var regions_series=[{"data": [47850947076, 81962598916, 86378480132, 87737238020, 90780762628], "type": "line", "name": "SEA", "stack": "stack"}];
var table_title="Region:SEA RDF Database Statistic";
var regions_legend=["SEA"];
var regions_x=["16Q2", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
