var regions_series=[{"data": [19254379012, 19885490692, 19920945668, 19546046980], "type": "line", "name": "TWN", "stack": "stack"}];
var table_title="Region:TWN RDF Database Statistic";
var regions_legend=["TWN"];
var regions_x=["16Q4", "17Q2", "17Q3", "17Q4"];
var kwargs={};
