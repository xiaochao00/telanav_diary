var regions_series=[{"data": [4494278135], "type": "line", "name": "RC"}];
var table_title="PBF Region:MEA Space Statistic";
var regions_legend=["RC"];
var regions_x=["15Q1"];
var kwargs={"jump_rule": "name"};
