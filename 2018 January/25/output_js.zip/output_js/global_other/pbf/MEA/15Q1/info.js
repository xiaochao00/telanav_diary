var regions_series=[{"data": [4426906211, 4428830617, 4494278135], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[MEA#15Q1] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20150713191552", "20150714224504", "20150805024954"];
var kwargs={};
