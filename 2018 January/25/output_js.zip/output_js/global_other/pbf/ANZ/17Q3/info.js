var regions_series=[];
var table_title="PBF Data[ANZ#17Q3] Detail Space Statistic";
var regions_legend=[];
var regions_x=[];
var kwargs={};
