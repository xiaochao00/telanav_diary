var regions_series=[{"data": [380616823, 3780112075, 3780115772, 3936420163, 3953747972, 3621781965], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[ANZ#16Q1] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20160410234454", "20160411235031", "20160413014551", "20160915171725", "20161116033457", "20161123001223"];
var kwargs={};
