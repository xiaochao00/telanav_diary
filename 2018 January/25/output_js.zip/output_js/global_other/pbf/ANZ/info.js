var regions_series=[{"data": [0, 0], "type": "line", "name": "test"}, {"data": [3663109097, 3936069768], "type": "line", "name": "RC"}];
var table_title="PBF Region:ANZ Space Statistic";
var regions_legend=["test", "RC"];
var regions_x=["15Q1", "16Q1"];
var kwargs={"jump_rule": "name"};
