var regions_series=[{"data": [0, 1711111185, 0, 0, 0, 1899816464, 0, 3382135641, 2876872668], "type": "bar", "name": "TWN", "stack": "stack"}, {"data": [8131642809, 0, 0, 10637899317, 10411230429, 0, 15491880064, 17648835322, 0], "type": "bar", "name": "SA", "stack": "stack"}, {"data": [4494278135, 0, 0, 0, 0, 0, 0, 0, 0], "type": "bar", "name": "MEA", "stack": "stack"}, {"data": [0, 0, 8064687531, 0, 0, 0, 0, 0, 0], "type": "bar", "name": "TUR", "stack": "stack"}, {"data": [3663109097, 0, 0, 3936069768, 0, 0, 0, 0, 0], "type": "bar", "name": "ANZ", "stack": "stack"}];
var table_title="PBF All Region Space Statistic";
var regions_legend=["TWN", "SA", "MEA", "TUR", "ANZ"];
var regions_x=["15Q1", "15Q3", "15Q4", "16Q1", "16Q2", "16Q4", "17Q1", "17Q2", "17Q4"];
var kwargs={"jump_rule": "series_name"};
