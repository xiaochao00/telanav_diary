var regions_series=[{"data": [1711111185, 1899816464, 3382135641, 2876872668], "type": "line", "name": "RC"}];
var table_title="PBF Region:TWN Space Statistic";
var regions_legend=["RC"];
var regions_x=["15Q3", "16Q4", "17Q2", "17Q4"];
var kwargs={"jump_rule": "name"};
