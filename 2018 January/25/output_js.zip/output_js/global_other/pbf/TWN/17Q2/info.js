var regions_series=[{"data": [3382135641], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[TWN#17Q2] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170723183459"];
var kwargs={};
