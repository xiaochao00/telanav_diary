var regions_series=[{"data": [2876872668], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[TWN#17Q4] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20171220035701"];
var kwargs={};
