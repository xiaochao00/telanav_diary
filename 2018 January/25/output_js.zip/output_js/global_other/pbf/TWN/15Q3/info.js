var regions_series=[{"data": [1711111185, 1404586636], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[TWN#15Q3] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20160125230535", "20160224215303"];
var kwargs={};
