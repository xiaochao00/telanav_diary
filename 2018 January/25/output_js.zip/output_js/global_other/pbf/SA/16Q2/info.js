var regions_series=[{"data": [10411230429, 10365932796], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[SA#16Q2] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20160713042128", "20160722011352"];
var kwargs={};
