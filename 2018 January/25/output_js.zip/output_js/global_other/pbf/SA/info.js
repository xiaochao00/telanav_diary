var regions_series=[{"data": [8131642809, 10637899317, 10411230429, 15491880064, 17648835322], "type": "line", "name": "RC"}];
var table_title="PBF Region:SA Space Statistic";
var regions_legend=["RC"];
var regions_x=["15Q1", "16Q1", "16Q2", "17Q1", "17Q2"];
var kwargs={"jump_rule": "name"};
