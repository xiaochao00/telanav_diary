var regions_series=[{"data": [17648835322], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[SA#17Q2] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170824014653"];
var kwargs={};
