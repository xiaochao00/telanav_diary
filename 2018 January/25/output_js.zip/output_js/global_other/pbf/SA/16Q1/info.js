var regions_series=[{"data": [10071587171, 10072050320, 10071940841, 10637899317], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[SA#16Q1] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20160411211741", "20160412011234", "20160413014651", "20160917182724"];
var kwargs={};
