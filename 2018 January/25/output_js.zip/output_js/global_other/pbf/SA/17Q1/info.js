var regions_series=[{"data": [15249766008, 15491880064], "type": "bar", "name": "RC", "stack": "stack"}];
var table_title="PBF Data[SA#17Q1] Detail Space Statistic";
var regions_legend=["RC"];
var regions_x=["20170323191801", "20170822193311"];
var kwargs={};
