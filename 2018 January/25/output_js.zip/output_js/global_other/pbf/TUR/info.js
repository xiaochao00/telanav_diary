var regions_series=[{"data": [8064687531], "type": "line", "name": "RC"}];
var table_title="PBF Region:TUR Space Statistic";
var regions_legend=["RC"];
var regions_x=["15Q4"];
var kwargs={"jump_rule": "name"};
