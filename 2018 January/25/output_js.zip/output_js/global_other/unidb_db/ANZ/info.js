var regions_series=[{"data": [32581779972, 38180014264, 36612080132, 37090886148, 38341018116], "type": "line", "name": "RC", "stack": "stack"}];
var table_title="Region:ANZ Unidb Database Statistic";
var regions_legend=["RC"];
var regions_x=["16Q4", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
