var regions_series=[{"data": [34859206840, 37275533828, 37752162488, 38442223800], "type": "line", "name": "RC", "stack": "stack"}];
var table_title="Region:SEA Unidb Database Statistic";
var regions_legend=["RC"];
var regions_x=["17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
