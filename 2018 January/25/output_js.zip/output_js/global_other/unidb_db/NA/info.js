var regions_series=[{"data": [416761727160, 521517990404, 513255622840, 436119488696, 547259959480, 445239576760], "type": "line", "name": "RC", "stack": "stack"}];
var table_title="Region:NA Unidb Database Statistic";
var regions_legend=["RC"];
var regions_x=["16Q2", "16Q4", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
