var regions_series=[{"data": [685803364044, 657650147020, 670735916748, 800595664588, 779304618168, 722090444984, 783894683340, 760482946764], "type": "line", "name": "RC", "stack": "stack"}];
var table_title="Region:EU Unidb Database Statistic";
var regions_legend=["RC"];
var regions_x=["16Q1", "16Q2", "16Q3", "16Q4", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
