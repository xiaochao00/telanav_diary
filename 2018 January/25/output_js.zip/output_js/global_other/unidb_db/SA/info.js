var regions_series=[{"data": [81616863748, 130286471352, 109277872644, 121860489732, 127417156100], "type": "line", "name": "RC", "stack": "stack"}];
var table_title="Region:SA Unidb Database Statistic";
var regions_legend=["RC"];
var regions_x=["16Q2", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
