var regions_series=[{"data": [11876205060, 13756924420, 13866059960, 13832225284], "type": "line", "name": "RC", "stack": "stack"}];
var table_title="Region:TWN Unidb Database Statistic";
var regions_legend=["RC"];
var regions_x=["16Q4", "17Q2", "17Q3", "17Q4"];
var kwargs={};
