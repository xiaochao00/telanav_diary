var regions_series=[{"data": [26173932036, 29562969804, 29858382340, 30378352332, 31064770744, 33166295556, 33625546444, 35209699020], "type": "line", "name": "RC", "stack": "stack"}];
var table_title="Region:TUR Unidb Database Statistic";
var regions_legend=["RC"];
var regions_x=["16Q1", "16Q2", "16Q3", "16Q4", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
