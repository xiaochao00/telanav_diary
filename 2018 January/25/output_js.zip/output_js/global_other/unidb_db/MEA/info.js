var regions_series=[{"data": [48862069252, 66575550648, 72715502084, 73512714756, 76487721476], "type": "line", "name": "RC", "stack": "stack"}];
var table_title="Region:MEA Unidb Database Statistic";
var regions_legend=["RC"];
var regions_x=["16Q1", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={};
