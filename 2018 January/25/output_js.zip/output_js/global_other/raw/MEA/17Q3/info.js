var regions_series=[{"data": [1154860703, 2092584, 1027809280, 14801152000, 1616129, 1132878957, 38021120], "type": "bar", "name": "MEA"}];
var table_title="MEA#17Q3 Components Statistic";
var regions_legend=["MEA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
