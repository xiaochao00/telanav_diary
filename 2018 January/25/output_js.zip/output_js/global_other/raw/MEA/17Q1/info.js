var regions_series=[{"data": [2241382540, 1980422, 1013760000, 13202053120, 4300689, 1364930118], "type": "bar", "name": "MEA"}];
var table_title="MEA#17Q1 Components Statistic";
var regions_legend=["MEA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern"];
var kwargs={"partly": "partly"};
