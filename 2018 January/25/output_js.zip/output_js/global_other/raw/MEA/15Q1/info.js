var regions_series=[{"data": [1048262513, 1119795200, 6938148023, 0], "type": "bar", "name": "MEA"}];
var table_title="MEA#15Q1 Components Statistic";
var regions_legend=["MEA"];
var regions_x=["3D_landmark", "junction_view", "rdf", "speed_camera"];
var kwargs={"partly": "partly"};
