var regions_series=[{"data": [1050839040, 278364160, 0, 0], "type": "bar", "name": "MEA"}];
var table_title="MEA#15Q2 Components Statistic";
var regions_legend=["MEA"];
var regions_x=["3D_landmark", "junction_view", "rdf", "speed_camera"];
var kwargs={"partly": "partly"};
