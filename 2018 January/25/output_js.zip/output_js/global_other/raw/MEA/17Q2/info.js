var regions_series=[{"data": [1121038131, 2075702, 1007431680, 14411634364, 1653893, 1369220353, 36454400], "type": "bar", "name": "MEA"}];
var table_title="MEA#17Q2 Components Statistic";
var regions_legend=["MEA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
