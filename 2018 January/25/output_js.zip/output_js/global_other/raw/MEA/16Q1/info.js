var regions_series=[{"data": [2199611305, 228126016, 1107855360, 8857497600, 380865, 307957760], "type": "bar", "name": "MEA"}];
var table_title="MEA#16Q1 Components Statistic";
var regions_legend=["MEA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern"];
var kwargs={"partly": "partly"};
