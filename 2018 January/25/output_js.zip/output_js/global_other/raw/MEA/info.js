var regions_series=[{"data": [9106205736, 1329203200, 1336729600, 12701428906, 0, 17828406889, 17949508523, 18158430773, 18087721216], "type": "line", "name": "MEA"}];
var table_title="Raw Data Region:MEA Space Statistic";
var regions_legend=["MEA"];
var regions_x=["15Q1", "15Q2", "15Q3", "16Q1", "16Q3", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={"jump_rule": "name"};
