var regions_series=[{"data": [1058887680, 277841920], "type": "bar", "name": "MEA"}];
var table_title="MEA#15Q3 Components Statistic";
var regions_legend=["MEA"];
var regions_x=["3D_landmark", "junction_view"];
var kwargs={"partly": "partly"};
