var regions_series=[{"data": [1119332141, 2148660, 1033707520, 15550398966, 1590049, 340454280, 40089600], "type": "bar", "name": "MEA"}];
var table_title="MEA#17Q4 Components Statistic";
var regions_legend=["MEA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
