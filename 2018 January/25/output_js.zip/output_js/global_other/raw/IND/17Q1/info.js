var regions_series=[{"data": [6347758176, 1054531, 548055040, 13051740160, 3470733494, 11202560], "type": "bar", "name": "IND"}];
var table_title="IND#17Q1 Components Statistic";
var regions_legend=["IND"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
