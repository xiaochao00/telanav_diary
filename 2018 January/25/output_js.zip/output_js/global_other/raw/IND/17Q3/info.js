var regions_series=[{"data": [3345280162, 1162954, 534384640, 13019987230, 0, 514429871, 11335680], "type": "bar", "name": "IND"}];
var table_title="IND#17Q3 Components Statistic";
var regions_legend=["IND"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
