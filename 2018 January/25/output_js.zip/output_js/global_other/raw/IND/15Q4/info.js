var regions_series=[{"data": [10958909440], "type": "bar", "name": "IND"}];
var table_title="IND#15Q4 Components Statistic";
var regions_legend=["IND"];
var regions_x=["rdf"];
var kwargs={"partly": "partly"};
