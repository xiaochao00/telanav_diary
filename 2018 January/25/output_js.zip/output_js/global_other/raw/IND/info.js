var regions_series=[{"data": [1493518899, 10958909440, 23430543961, 17426580537], "type": "line", "name": "IND"}];
var table_title="Raw Data Region:IND Space Statistic";
var regions_legend=["IND"];
var regions_x=["13Q2", "15Q4", "17Q1", "17Q3"];
var kwargs={"jump_rule": "name"};
