var regions_series=[{"data": [1448424335, 45094564], "type": "bar", "name": "IND"}];
var table_title="IND#13Q2 Components Statistic";
var regions_legend=["IND"];
var regions_x=["3D_landmark", "speed_pattern"];
var kwargs={"partly": "partly"};
