var regions_series=[{"data": [15131003064, 11675825, 5815992320, 117843245, 67231764480, 5654511, 9003731941, 2258288221], "type": "bar", "name": "EU"}];
var table_title="EU#17Q1 Components Statistic";
var regions_legend=["EU"];
var regions_x=["3D_landmark", "GJV", "junction_view", "post_code", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
