var regions_series=[{"data": [7698332740, 14168397, 5845288960, 274245699, 71047020812, 5487684, 6836127089, 1660475259], "type": "bar", "name": "EU"}];
var table_title="EU#17Q3 Components Statistic";
var regions_legend=["EU"];
var regions_x=["3D_landmark", "GJV", "junction_view", "post_code", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
