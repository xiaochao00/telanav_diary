var regions_series=[{"data": [7678696427, 14248587, 5825310720, 273782806, 70156734764, 5490918, 6749630302, 1658453551], "type": "bar", "name": "EU"}];
var table_title="EU#17Q2 Components Statistic";
var regions_legend=["EU"];
var regions_x=["3D_landmark", "GJV", "junction_view", "post_code", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
