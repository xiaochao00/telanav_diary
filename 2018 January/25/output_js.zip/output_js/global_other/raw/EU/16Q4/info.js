var regions_series=[{"data": [7486251729, 11588287, 5791918080, 272957202, 66218362880, 5331072, 7520279681, 1666316869], "type": "bar", "name": "EU"}];
var table_title="EU#16Q4 Components Statistic";
var regions_legend=["EU"];
var regions_x=["3D_landmark", "GJV", "junction_view", "post_code", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
