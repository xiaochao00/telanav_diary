var regions_series=[{"data": [88973005800, 99575953607, 92362348075, 93381146640, 89041883306, 0], "type": "line", "name": "EU"}];
var table_title="Raw Data Region:EU Space Statistic";
var regions_legend=["EU"];
var regions_x=["16Q4", "17Q1", "17Q2", "17Q3", "17Q4", "18Q1"];
var kwargs={"jump_rule": "name"};
