var regions_series=[{"data": [7610268663, 14306718, 5836544000, 549688825, 72079543203, 6865268, 1919007847, 1025658782], "type": "bar", "name": "EU"}];
var table_title="EU#17Q4 Components Statistic";
var regions_legend=["EU"];
var regions_x=["3D_landmark", "GJV", "junction_view", "post_code", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
