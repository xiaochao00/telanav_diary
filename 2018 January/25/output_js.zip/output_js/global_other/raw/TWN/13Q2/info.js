var regions_series=[{"data": [1127201446, 1788187], "type": "bar", "name": "TWN"}];
var table_title="TWN#13Q2 Components Statistic";
var regions_legend=["TWN"];
var regions_x=["3D_landmark", "speed_camera"];
var kwargs={"partly": "partly"};
