var regions_series=[{"data": [1348284162, 267707, 780738560, 1220348971, 1343596, 18703235, 6625280], "type": "bar", "name": "TWN"}];
var table_title="TWN#17Q4 Components Statistic";
var regions_legend=["TWN"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
