var regions_series=[{"data": [1098244685, 251889, 832824320, 995167744, 186999], "type": "bar", "name": "TWN"}];
var table_title="TWN#15Q3 Components Statistic";
var regions_legend=["TWN"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera"];
var kwargs={"partly": "partly"};
