var regions_series=[{"data": [1351432207, 267981, 773294080, 1210943117, 1342213, 89921767, 6604800], "type": "bar", "name": "TWN"}];
var table_title="TWN#17Q3 Components Statistic";
var regions_legend=["TWN"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
