var regions_series=[{"data": [1355294710, 269969, 768911360, 1210697357, 1846010, 101214919, 6625280], "type": "bar", "name": "TWN"}];
var table_title="TWN#17Q2 Components Statistic";
var regions_legend=["TWN"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
