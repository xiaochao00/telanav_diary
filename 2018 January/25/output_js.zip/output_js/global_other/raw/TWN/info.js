var regions_series=[{"data": [1128989633, 2926675637, 4784958106, 3444859605, 3433806165, 3376311511], "type": "line", "name": "TWN"}];
var table_title="Raw Data Region:TWN Space Statistic";
var regions_legend=["TWN"];
var regions_x=["13Q2", "15Q3", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={"jump_rule": "name"};
