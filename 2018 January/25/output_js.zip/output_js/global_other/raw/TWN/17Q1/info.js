var regions_series=[{"data": [2718360987, 259176, 767057920, 1191464960, 3439948, 104375115], "type": "bar", "name": "TWN"}];
var table_title="TWN#17Q1 Components Statistic";
var regions_legend=["TWN"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern"];
var kwargs={"partly": "partly"};
