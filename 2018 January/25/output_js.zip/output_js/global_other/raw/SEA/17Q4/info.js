var regions_series=[{"data": [2123330998, 1072907, 1224765440, 8900999540, 1208171, 220487535, 55428951], "type": "bar", "name": "SEA"}];
var table_title="SEA#17Q4 Components Statistic";
var regions_legend=["SEA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
