var regions_series=[{"data": [1088208861], "type": "bar", "name": "SEA"}];
var table_title="SEA#12Q1 Components Statistic";
var regions_legend=["SEA"];
var regions_x=["3D_landmark"];
var kwargs={"partly": "partly"};
