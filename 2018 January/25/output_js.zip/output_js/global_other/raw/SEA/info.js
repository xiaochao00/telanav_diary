var regions_series=[{"data": [1088208861, 7941632015, 10778951264, 12341688178, 11619787165, 12527293542], "type": "line", "name": "SEA"}];
var table_title="Raw Data Region:SEA Space Statistic";
var regions_legend=["SEA"];
var regions_x=["12Q1", "16Q2", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={"jump_rule": "name"};
