var regions_series=[{"data": [2121932457, 1005672, 1215754240, 7440258895, 0, 0, 0], "type": "bar", "name": "SEA"}];
var table_title="SEA#17Q1 Components Statistic";
var regions_legend=["SEA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
