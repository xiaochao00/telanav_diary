var regions_series=[{"data": [2122015980, 1053146, 1224263680, 7927522908, 1199869, 1044988755, 20643840], "type": "bar", "name": "SEA"}];
var table_title="SEA#17Q2 Components Statistic";
var regions_legend=["SEA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
