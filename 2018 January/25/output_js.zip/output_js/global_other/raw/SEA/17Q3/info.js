var regions_series=[{"data": [2123456051, 1068068, 1226311680, 8015419934, 1204467, 209724943, 42602022], "type": "bar", "name": "SEA"}];
var table_title="SEA#17Q3 Components Statistic";
var regions_legend=["SEA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
