var regions_series=[{"data": [479245207, 885526, 1142466560, 5630453760, 1695750, 686885212], "type": "bar", "name": "SEA"}];
var table_title="SEA#16Q2 Components Statistic";
var regions_legend=["SEA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern"];
var kwargs={"partly": "partly"};
