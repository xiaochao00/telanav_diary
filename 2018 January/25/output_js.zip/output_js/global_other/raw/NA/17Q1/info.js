var regions_series=[{"data": [5952028104, 15657372, 6349004800, 35810836480, 3997137, 3939859515, 75509760], "type": "bar", "name": "NA"}];
var table_title="NA#17Q1 Components Statistic";
var regions_legend=["NA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
