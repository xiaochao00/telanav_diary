var regions_series=[{"data": [5950341977, 15426439, 7671852240, 29569485824, 4368342, 2403481065, 198364058], "type": "bar", "name": "NA"}];
var table_title="NA#15Q3 Components Statistic";
var regions_legend=["NA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
