var regions_series=[{"data": [2976371787, 15550050, 6574915469, 34773068288, 4325006, 1701467778, 154100755], "type": "bar", "name": "NA"}];
var table_title="NA#16Q2 Components Statistic";
var regions_legend=["NA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
