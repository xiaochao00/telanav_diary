var regions_series=[{"data": [5950082927, 15470421, 7442495488, 29901744128, 4369051, 5111291113, 210377363], "type": "bar", "name": "NA"}];
var table_title="NA#15Q4 Components Statistic";
var regions_legend=["NA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
