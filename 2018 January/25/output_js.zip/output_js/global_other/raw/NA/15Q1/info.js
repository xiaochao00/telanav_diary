var regions_series=[{"data": [2968079353, 7487231828, 29083931136, 2092140, 775586347, 287857070], "type": "bar", "name": "NA"}];
var table_title="NA#15Q1 Components Statistic";
var regions_legend=["NA"];
var regions_x=["3D_landmark", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
