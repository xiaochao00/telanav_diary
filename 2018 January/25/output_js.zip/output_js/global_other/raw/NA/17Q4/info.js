var regions_series=[{"data": [2927747340, 16383407, 6500311040, 38534136183, 1600316, 922682632, 86384640], "type": "bar", "name": "NA"}];
var table_title="NA#17Q4 Components Statistic";
var regions_legend=["NA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
