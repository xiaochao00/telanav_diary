var regions_series=[{"data": [5945384454, 15594189, 6400808960, 35150520320, 4680849, 1702945076, 76851200], "type": "bar", "name": "NA"}];
var table_title="NA#16Q3 Components Statistic";
var regions_legend=["NA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
