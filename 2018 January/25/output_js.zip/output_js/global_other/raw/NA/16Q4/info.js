var regions_series=[{"data": [5955077564, 15623346, 6442106880, 35528069120, 3964202, 3808258477, 76595200], "type": "bar", "name": "NA"}];
var table_title="NA#16Q4 Components Statistic";
var regions_legend=["NA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
