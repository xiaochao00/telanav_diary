var regions_series=[{"data": [40604777874, 41570891802, 45813319945, 48635830491, 41890671138, 46199799133, 49296785048, 51829694789, 52146893168, 51021201755, 51441522263, 48989245558], "type": "line", "name": "NA"}];
var table_title="Raw Data Region:NA Space Statistic";
var regions_legend=["NA"];
var regions_x=["15Q1", "15Q2", "15Q3", "15Q4", "16Q1", "16Q2", "16Q3", "16Q4", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={"jump_rule": "name"};
