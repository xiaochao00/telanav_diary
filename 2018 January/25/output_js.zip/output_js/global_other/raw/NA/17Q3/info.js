var regions_series=[{"data": [2946988783, 16321199, 6642493440, 38399293923, 1602418, 3348673380, 86149120], "type": "bar", "name": "NA"}];
var table_title="NA#17Q3 Components Statistic";
var regions_legend=["NA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
