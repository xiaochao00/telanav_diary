var regions_series=[{"data": [2964640615, 16287984, 6457610240, 38181592669, 1614184, 3323639103, 75816960], "type": "bar", "name": "NA"}];
var table_title="NA#17Q2 Components Statistic";
var regions_legend=["NA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
