var regions_series=[{"data": [2966532987, 15527177, 7448847360, 29391924224, 2168570, 1648559260, 97332224], "type": "bar", "name": "NA"}];
var table_title="NA#15Q2 Components Statistic";
var regions_legend=["NA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
