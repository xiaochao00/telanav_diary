var regions_series=[{"data": [0], "type": "line", "name": "TUR"}];
var table_title="Raw Data Region:TUR Space Statistic";
var regions_legend=["TUR"];
var regions_x=["15Q4"];
var kwargs={"jump_rule": "name"};
