var regions_series=[{"data": [1097321026, 3539641, 1056296960, 12070033783, 0, 291420101, 23009280], "type": "bar", "name": "SA"}];
var table_title="SA#17Q4 Components Statistic";
var regions_legend=["SA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
