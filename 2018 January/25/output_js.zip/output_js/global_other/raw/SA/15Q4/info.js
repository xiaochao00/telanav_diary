var regions_series=[{"data": [0, 0, 0, 0], "type": "bar", "name": "SA"}];
var table_title="SA#15Q4 Components Statistic";
var regions_legend=["SA"];
var regions_x=["3D_landmark", "GJV", "rdf", "speed_camera"];
var kwargs={"partly": "partly"};
