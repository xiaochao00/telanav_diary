var regions_series=[{"data": [1077736101, 3152898, 1030850560, 8343654400], "type": "bar", "name": "SA"}];
var table_title="SA#16Q2 Components Statistic";
var regions_legend=["SA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf"];
var kwargs={"partly": "partly"};
