var regions_series=[{"data": [2204576938, 3288556, 1056481280, 10697068089, 1310720330], "type": "bar", "name": "SA"}];
var table_title="SA#17Q1 Components Statistic";
var regions_legend=["SA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_pattern"];
var kwargs={"partly": "partly"};
