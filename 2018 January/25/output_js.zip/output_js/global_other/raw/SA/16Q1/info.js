var regions_series=[{"data": [2143000129, 3121018, 1155938816, 8216912896, 294050304], "type": "bar", "name": "SA"}];
var table_title="SA#16Q1 Components Statistic";
var regions_legend=["SA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_pattern"];
var kwargs={"partly": "partly"};
