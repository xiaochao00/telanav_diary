var regions_series=[{"data": [8700435729, 0, 11813023163, 10455393959, 15272135193, 14679857775, 14894153845, 14541620791], "type": "line", "name": "SA"}];
var table_title="Raw Data Region:SA Space Statistic";
var regions_legend=["SA"];
var regions_x=["15Q1", "15Q4", "16Q1", "16Q2", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={"jump_rule": "name"};
