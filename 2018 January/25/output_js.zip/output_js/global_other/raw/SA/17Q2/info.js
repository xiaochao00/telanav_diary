var regions_series=[{"data": [1097335323, 3458633, 1056256000, 11416132081, 0, 1085397018, 21278720], "type": "bar", "name": "SA"}];
var table_title="SA#17Q2 Components Statistic";
var regions_legend=["SA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
