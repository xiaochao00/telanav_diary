var regions_series=[{"data": [1031645019, 2995126, 1169103872, 6496691712], "type": "bar", "name": "SA"}];
var table_title="SA#15Q1 Components Statistic";
var regions_legend=["SA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf"];
var kwargs={"partly": "partly"};
