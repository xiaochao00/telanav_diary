var regions_series=[{"data": [1097321026, 3509594, 1051136000, 11614490892, 0, 1104564173, 23132160], "type": "bar", "name": "SA"}];
var table_title="SA#17Q3 Components Statistic";
var regions_legend=["SA"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
