var regions_series=[{"data": [3498154541, 3106122093, 2181734400, 3908044472, 4765845885, 5488354188, 4560391917, 4135691766, 4290614430, 4944381481], "type": "line", "name": "ANZ"}];
var table_title="Raw Data Region:ANZ Space Statistic";
var regions_legend=["ANZ"];
var regions_x=["15Q1", "15Q3", "15Q4", "16Q1", "16Q3", "16Q4", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={"jump_rule": "name"};
