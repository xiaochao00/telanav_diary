var regions_series=[{"data": [1390382945, 226244895, 802304000, 2733107200, 29819575, 295190613, 11304960], "type": "bar", "name": "ANZ"}];
var table_title="ANZ#16Q4 Components Statistic";
var regions_legend=["ANZ"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
