var regions_series=[{"data": [693525707, 475922, 249712640, 3062032652, 15286408, 259105581, 10475520], "type": "bar", "name": "ANZ"}];
var table_title="ANZ#17Q3 Components Statistic";
var regions_legend=["ANZ"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
