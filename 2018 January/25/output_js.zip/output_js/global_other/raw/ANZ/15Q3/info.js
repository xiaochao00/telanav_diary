var regions_series=[{"data": [651389534, 438986, 2149336576, 14029689, 268839628, 22087680], "type": "bar", "name": "ANZ"}];
var table_title="ANZ#15Q3 Components Statistic";
var regions_legend=["ANZ"];
var regions_x=["3D_landmark", "GJV", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
