var regions_series=[{"data": [651511626, 445090, 883245568, 2290041856, 14292634, 50943760, 22089728], "type": "bar", "name": "ANZ"}];
var table_title="ANZ#16Q1 Components Statistic";
var regions_legend=["ANZ"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
