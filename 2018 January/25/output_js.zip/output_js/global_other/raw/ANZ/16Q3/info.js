var regions_series=[{"data": [1388619044, 0, 796815360, 2276741120, 0, 281203801, 22466560], "type": "bar", "name": "ANZ"}];
var table_title="ANZ#16Q3 Components Statistic";
var regions_legend=["ANZ"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
