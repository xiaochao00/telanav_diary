var regions_series=[{"data": [693520903, 0, 0, 3007776335, 0, 423683488, 10711040], "type": "bar", "name": "ANZ"}];
var table_title="ANZ#17Q2 Components Statistic";
var regions_legend=["ANZ"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
