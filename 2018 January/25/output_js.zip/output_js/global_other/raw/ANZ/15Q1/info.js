var regions_series=[{"data": [654078187, 435784, 676217344, 2084316160, 14002358, 46935620, 22169088], "type": "bar", "name": "ANZ"}];
var table_title="ANZ#15Q1 Components Statistic";
var regions_legend=["ANZ"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
