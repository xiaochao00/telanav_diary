var regions_series=[{"data": [687327600, 478441, 800491520, 3164392501, 15693825, 264866714, 11130880], "type": "bar", "name": "ANZ"}];
var table_title="ANZ#17Q4 Components Statistic";
var regions_legend=["ANZ"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
