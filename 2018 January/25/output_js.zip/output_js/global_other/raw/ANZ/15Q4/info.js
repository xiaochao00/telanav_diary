var regions_series=[{"data": [0, 0, 2181734400, 0, 0], "type": "bar", "name": "ANZ"}];
var table_title="ANZ#15Q4 Components Statistic";
var regions_legend=["ANZ"];
var regions_x=["3D_landmark", "GJV", "rdf", "speed_camera", "speed_pattern"];
var kwargs={"partly": "partly"};
