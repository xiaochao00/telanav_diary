var regions_series=[{"data": [693907977, 454730, 803921920, 2782924800, 14926169, 253053761, 11202560], "type": "bar", "name": "ANZ"}];
var table_title="ANZ#17Q1 Components Statistic";
var regions_legend=["ANZ"];
var regions_x=["3D_landmark", "GJV", "junction_view", "rdf", "speed_camera", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
