var regions_series=[{"data": [592297711, 313457690, 8775999172, 8726657195, 166632427612, 25836512852, 24445361420, 21356831175, 41460613633], "type": "line", "name": "CN"}];
var table_title="Raw Data Region:CN Space Statistic";
var regions_legend=["CN"];
var regions_x=["15Q4", "16Q1", "16Q2", "16Q3", "16Q4", "17Q1", "17Q2", "17Q3", "17Q4"];
var kwargs={"jump_rule": "name"};
