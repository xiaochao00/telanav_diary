var regions_series=[{"data": [274765789, 7264112367, 33921735477], "type": "bar", "name": "CN"}];
var table_title="CN#17Q4 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "junction_view", "speed_pattern"];
var kwargs={"partly": "partly"};
