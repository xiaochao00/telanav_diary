var regions_series=[{"data": [313457470, 0, 152, 68], "type": "bar", "name": "CN"}];
var table_title="CN#16Q1 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "junction_view", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
