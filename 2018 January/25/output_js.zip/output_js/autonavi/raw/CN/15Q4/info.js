var regions_series=[{"data": [313781013, 0, 272546516, 5970182], "type": "bar", "name": "CN"}];
var table_title="CN#15Q4 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "junction_view", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
