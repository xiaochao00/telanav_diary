var regions_series=[{"data": [3180905073], "type": "bar", "name": "CN"}];
var table_title="CN#16Q3 Components Statistic";
var regions_legend=["CN"];
var regions_x=["speed_pattern"];
var kwargs={"partly": "partly"};
