var regions_series=[{"data": [313819161, 7639129027, 16486760680, 5652552], "type": "bar", "name": "CN"}];
var table_title="CN#17Q2 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "junction_view", "speed_pattern", "traffic_location"];
var kwargs={"partly": "partly"};
