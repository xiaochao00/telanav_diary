var regions_series=[{"data": [274730160, 7290162240, 13791938775], "type": "bar", "name": "CN"}];
var table_title="CN#17Q3 Components Statistic";
var regions_legend=["CN"];
var regions_x=["3D_landmark", "junction_view", "speed_pattern"];
var kwargs={"partly": "partly"};
