var regions_series=[];
var table_title="RDF Database Statistic";
var regions_legend=[];
var regions_x=[];
var kwargs={"jump_rule": "series_name"};
