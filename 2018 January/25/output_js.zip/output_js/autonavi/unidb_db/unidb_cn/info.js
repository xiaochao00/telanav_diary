var regions_series=[{"data": [116811943700, 122864930580, 0, 130869202708, 0, 0, 0], "type": "line", "name": "RC", "stack": "stack"}, {"data": [0, 0, 128475565844, 0, 138723561236, 192274239252, 154291212052], "type": "line", "name": "rc", "stack": "stack"}];
var table_title="Region:unidb_cn Unidb Database Statistic";
var regions_legend=["RC", "rc"];
var regions_x=["16q2", "16q3", "16q4", "17q1", "17q2", "17q3", "17q4"];
var kwargs={};
