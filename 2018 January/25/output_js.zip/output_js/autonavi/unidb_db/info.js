var regions_series=[{"data": [116811943700, 122864930580, 128475565844, 130869202708, 138723561236, 192274239252, 154291212052], "type": "bar", "name": "unidb_cn", "stack": "stack"}];
var table_title="Unidb Database Statistic";
var regions_legend=["unidb_cn"];
var regions_x=["16q2", "16q3", "16q4", "17q1", "17q2", "17q3", "17q4"];
var kwargs={"jump_rule": "series_name"};
