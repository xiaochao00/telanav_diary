var regions_series=[{"data": [135925926, 761094918, 0], "type": "line", "name": "TEST"}, {"data": [0, 0, 29616317642], "type": "line", "name": "RC"}];
var table_title="PBF Region:CN Space Statistic";
var regions_legend=["TEST", "RC"];
var regions_x=["17Q1", "17Q2", "17Q4"];
var kwargs={"jump_rule": "name"};
